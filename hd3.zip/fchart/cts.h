 
/*      cts.h := header file for CTOOLSET system
 
        Copyright (C) 1984, 1985 by Solution Systems
 
*/
 
/*      #define REDIRECT if you have an operating system that
        supports redirection of stdin/stdout.
 
        UNIX, DOS, XENIX, etc. support this.
        VAX/VMS does not.
 
*/
#define REDIRECT        		/* redirection is available in OS */
 
/* CTS.H */
 
/*
   definition of where error messages are displayed 
   define one or the other
*/
 
#define errmsg stderr 
/* #define errmsg stdout */
 
#define VERSION "2.00B" 
 
 
#define bits	ushort
#define bool	  int
#define metachar short
#define tbool	 char
#define ushort	unsigned
 
#define forever for(;;)         	/* infinite loop */
 
#define NO	    0
#define YES	    1
 
#define TRUE        1
#define FALSE       0
 
#define ERROR      -1
 
#define OK          0
#define FAIL	    1
 
#define FF       0x0c
#define NL	 '\n'
#define BELL     0x07
#define CPMEOF   0x1A
 
#ifndef EOS
#define EOS       '\0'			/* STANDARD END OF STRING */
#endif
 
 
#define MAXLINE    134
#define KEY_STAT  0X0B   	/* BDOS FUNCTION 11 : CHECK KEYBOARD STATUS*/
#define KEY_IN    0X01   	/* BDOS FCN 1 : GET A CHARACTER */
 
#define unless(e)       if(!(e))
#define getln(s, n)	((fgets((s), (n), stdin) == NULL) ? EOF : strlen(s))
#define ABS(x)		(((x) < 0) ? -(x) : (x))
#define MAX(x, y)	(((x) < (y)) ? (y) : (x))
#define MIN(x, y)	(((x) < (y)) ? (x) : (y))
 
 
#define UCHAR unsigned char
 

