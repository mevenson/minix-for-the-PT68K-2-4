
/*
 *		FCHART C function Call Plotter
 *
 *		for MS-DOS and Computer Innovations C86 
 *
 *		Copyright (c) 1983,84 Solution Systems
 *
 *			  May 1984
 *
 *
 */
 
/*  Revisions:	   August 1985 by Jon Chappell
   1.  Changed copyright messages
   2.  Changed version number to 2.0
   3.  Cleaned up flags, other stuff
   4.  -> microsoft 3.00
   5. misc. mods
*/
 
 
#include <stdio.h>
#include <ctype.h>
 
#include "cts.h"	      /* C toolset header file */
 
 
#define CTRL_D 004
#define ATOMLENGTH 30
#define MAXNAME 300
#define MAXINST 1000
#define MAXDEPTH 75
#define MAXSEEN 300
#define PAPERWIDTH 78
 
int	bracket = 0,
	linect = 0,
	terse = 1,
	ntabs = (PAPERWIDTH - 20)/8,
	lastchar = 0;
 
UCHAR aseen[MAXSEEN][ATOMLENGTH] =
{
	'\0'
};
 
UCHAR *sysword[] =	 /* reserved words for C */
{
	"if",
	"while",
	"for",
	"else",
	"return",
	"switch",
	"do",
	"sizeof",
	0
};
 
struct rname
{
	UCHAR namer[ATOMLENGTH];
	int rnamecalled;
	int rnameout;
	struct rinst *dlistp;
}
namelist[MAXNAME], *actvlist[MAXDEPTH];
 
int activep = 0;
 
struct rinst
{
	struct rname *namep;
	struct rinst *calls;
}
dlist[MAXINST], *frp = dlist;
 
static UCHAR *startfunc = "main";
 
void initfree();		/* initialize */
void banner();			/* print copyright, etc */
void getflag(); 	       /* process command line flags */
void fnf();			/* file not found message */
void help_msg();		/* help message */
void quit();			/* abnormal termination */
void scan();			/* scan atom */
 
FILE *fopen(), *fp;
 
/*  fchart */
main(argc, argv)
int argc;
UCHAR *argv[];
{
	int atoi();
	UCHAR *lcstr();
	struct rinst *newproc(), *add2call();
	struct rname *lookfor();
 
	int gf, ok;
	UCHAR atom[ATOMLENGTH];
	struct rname *startp;
	struct rinst *curproc = NULL;
 
	register int i;
 
 
	initfree();
 
	banner();	/* print copyright message */
 
	if (argc<2) quit();
 
	for(i = 1; (i < argc) && (*argv[i] == '-'); i++)
	    getflag(argv[i]+1);     /* process flag */
 
	if(i == argc) quit();	/* no real args */
 
	/* last name on command line is the input file */
	if ((fp=fopen(argv[argc-1], "r"))==NULL)
		fnf(argv[argc-1]);
 
	fprintf(errmsg
	  ,"fchart: plotting function calls for file: %s\n",argv[argc-1]);
 
	while ((gf = getfunc(atom)) != -1 && ok )
		{
		if (gf) ok = (int)(add2call(atom, curproc));
		else ok = (int)(curproc = newproc(atom));
		}
 
	if( i < argc-1) 
	   {
	   while( i < argc-1)
	     {
	     startfunc = lcstr(argv[i]);
	     if (startp = lookfor(startfunc))
		{
		(void) output(startp, 0);
		(void) printf("\n\n");
		}
	     else (void) printf("*** error *** function %s not found\n", startfunc);
	     }
	  }
	else
	   {
	   for (startp = namelist; startp && startp->namer[0]; startp++)
		{
		if (!(startp->rnamecalled))
			{
			(void) output(startp, 0);
			(void) printf("\n\n");
			}
		}
	  }
}
 
/*
	get command line flags
*/
void getflag(s)
register UCHAR *s;
{
 
   for(;*s;++s) {
       switch(tolower(*s)) {
	default:
	      fprintf(errmsg,"fchart: unknown flag %c\n",*s);
	case 'h':
	case '?':
		quit(); break;
	case 't': terse = 1; break;
	case 'v': terse = 0; break;
	case 'w': ntabs = (atoi(s+1) - 20)/8;
		  return;
       }
  }
}
 
 
/*	get a function
*/
 
int getfunc(atom)
register UCHAR atom[];
{
	register int c;
	register int ss;
 
	for(;;) 
		{
		c = get_char();
		if (isalpha(c) || (c=='_'))
			{
			lastchar = c;
			(void) scan(atom);
			continue;
			}
		else
			{
			switch(c)
				{
			case '\t':
			case ' ':
				continue;
 
			case '\n':
				if ((c = get_char()) == '#')
					while ((c = get_char()) != '\n')
						;
				lastchar = c;
				continue;
 
			case '\'':
				while ((c = get_char()) != '\'')
					if (c == '\\')
						(void) get_char();
				atom[0] = '\0';
				continue;
 
			case '\"':
				while (( c = get_char()) != '\"')
					if (c == '\\')
						(void) get_char();
				continue;
 
			case '{':
				bracket++;
				atom[0] = '\0';
				continue;
			case '}':
				--bracket;
				if (bracket < 0)
					(void) printf("bracket underflow");
				atom[0] = '\0';
				continue;
 
			case '(':
				if(!atom[0])
					continue;
				if (!checksys(atom))
					{
					if (!bracket)
						return(0);
					if ((ss = seen(atom)) == -1)
						(void) printf("aseen overflow");
					if (bracket && !ss)
						return(1);
					}
				atom[0] = '\0';
				continue;
 
			case CTRL_D:
			case EOF:
				return(-1);
 
			case '/':
				if ((c = get_char()) == '*')
					for (;;)
						{
						while (get_char() != '*')
							;
						if ((c = get_char()) == '/')
							break;
						lastchar = c;
						}
				else
					lastchar = c;
				continue;
 
			case '\\':
				(void) get_char();
				/* drop through */
 
			default:
				atom[0] = '\0';
				continue;
				}
			}
		}
}
 
/* scan atom */
void scan(atom)
UCHAR atom[];
{
	register int c;
	register int i;
 
	c = lastchar;
	for(i = 0; isalnum(c) || c=='_'; i++)
		{
		atom[i] = (UCHAR) (c = get_char());
		if (i > ATOMLENGTH) break;
		}
	atom[i-1] = '\0';
	lastchar = c;
}
 
int checksys(atom)
UCHAR atom[];
{
	register int i;
 
	for (i = 0; sysword[i]; i++)
		if (match(atom, sysword[i]))
			return(1);
	return(0);
}
 
int seen(atom)
UCHAR *atom;
{
	register int i,j;
	for (i = 0; aseen[i][0] && i < MAXSEEN; i++)
		if (match(atom, aseen[i]))
			return(1);
	if (i >= MAXSEEN)
		return(-1);
	for (j = 0; (aseen[i][j] = atom[j]) != '\0' && j < ATOMLENGTH; j++)
		;
	aseen[i+1][0] = '\0';
	return(0);
}
 
int match(atom, name)
register UCHAR *name;
register UCHAR *atom;
{
      return (strcmp(atom,name) ? (0) : (1));
 
#if	0	/* old code */
	for (; *atom == *name; ++atom, ++name)
		if (!*atom)
			return(1);
	return(0);
#endif
}
 
int get_char()
{
	register int c;
 
	if(!lastchar)
		c = fgetc(fp);
	else
		{
		c = lastchar;
		lastchar = 0;
		}
	return(c);
}
 
struct rinst *newproc(name)
UCHAR name[];
{
	struct rinst *install();
	struct rname *place();
 
	aseen[0][0] = '\0';
	return(install(place(name), (struct rinst *)NULL));
}
 
struct rinst *add2call(name,curp)
UCHAR name[];
struct rinst *curp;
{
	register struct rinst *ip;
	register struct rname *p;
	struct rinst *install();
	struct rname *place();
 
	ip = install(p = place(name), curp);
	if (p)
		++(p->rnamecalled);
	return(ip);
}
 
struct rname *place(name)
UCHAR name[];
{
	register int i;
	register struct rname *npt;
	UCHAR *strcpy();
 
	for (i = 0 ; (npt = &namelist[i])->namer[0] && i < MAXNAME ; i++)
		if (match(name, npt->namer))
			return(npt);
 
	if (i >= MAXNAME)
		{
		(void) printf("namelist overflown");
		return((struct rname *)NULL);
		}
 
	/* name was not on list, so put it on */
	strcpy(npt->namer, name);
	(npt+1)->namer[0] = '\0';
	npt->rnamecalled = 0;
	npt->rnameout = 0;
	return(npt);
}
 
struct rinst *install(np, rp)
struct rname *np;
struct rinst *rp;
{
	register struct rinst *newp;
	register struct rinst *op;
	struct rinst *getfree();
 
	if (!np)
		return((struct rinst *)NULL);
	if (!(newp = getfree()))
		return((struct rinst *)NULL);
	newp->namep = np;
	newp->calls = 0;
	if (rp) 
		{
		op = rp;
		while (op->calls)
			op = op->calls;
		op->calls = newp;
		}
	else
		np->dlistp = newp;
 
	return(newp);
}
 
struct rinst *getfree()
{
	register struct rinst *ret;
 
	if (!(ret = frp))
		(void) printf("out of instance blocks\n");
	frp = frp->calls;
	return(ret);
}
 
void initfree()
{
	register int i;
 
	for (i = 0 ; i < (MAXINST - 2); i++)
		{
		frp->namep = 0;
		frp->calls = frp+1;
		frp++;
		}
	frp->namep = 0;
	frp->calls = 0;
	frp= dlist;
}
 
output(func, tabc)
struct rname *func;
int tabc;
{
	register struct rinst *nextp;
	register int i, tabd, tabstar, tflag;
 
	++linect;
	(void) printf("\n%d  ", linect);
	if (!(makeactive(func)))
		(void) putchar('*');	/* calls nested too deep */
	else
		{
		tabstar = 0;
		tabd = tabc;
		for (;tabd > ntabs; tabstar++)
			tabd = tabd-ntabs;
		for (i = 0 ; i < tabstar; i++ )
			(void) putchar('<');
		(void) putchar(' ');
		for (i = 0 ; i < tabd ; i++ )
			(void) putchar('\t');
		if (active(func))
			(void) printf("^ %s ^", func->namer); /* recursive call */
		else
			{
			if (func->dlistp)
				{
				(void) printf("%s", func->namer);
				nextp = func->dlistp->calls;
				if (!terse ||
					!func->rnameout)
					{
					++tabc;
					if (!func->rnameout)
						func->rnameout = linect;
					if (tabc > ntabs && (tabc % ntabs) == 1 && nextp)
						{
						(void) printf("\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
						tflag = 1;
						}
					else
						tflag = 0;
					for (; nextp; nextp = nextp->calls)
						output(nextp->namep, tabc);
					if (tflag)
						{
						(void) printf("\n- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -");
						tflag = 0;
						}
					}
				else if (nextp)
					(void) printf(" ... [see line %d]", func->rnameout);
				}
			else
				(void) printf("%s [ext]", func->namer); /* library or external call */
			}
		(void) backup();
		}
}
 
struct rname *lookfor(name)
UCHAR *name;
{
	register struct rname *np;
 
	for (np = namelist; np->namer[0]; np++)
		if (match(name, np->namer))
			return(np);
	return((struct rname *)NULL);
}
 
 
 
/*	translate string to lower case
	and return a pointer to it
*/
UCHAR *lcstr(s)
UCHAR *s;
{
#ifdef	MSC
	extern UCHAR *strlwr();
	return strlwr(s);
#else
	register UCHAR *sp;
 
	for (sp = s; *sp = tolower(*sp); ++sp)
		;
	return(s);
#endif
}
 
int makeactive(func)
struct rname *func;
{
	if (activep < MAXDEPTH) 
		{
		actvlist[activep] = func;
		activep++;
		return(1);
		}
	return(0);
}
 
int backup()
{
	if (activep)
		{
		actvlist[activep--] = 0;
		return(1);
		}
	return(-1);
}
 
int active(func)
struct rname *func;
{
	register int i;
 
	for (i = 0; i < (activep - 1); i++)
		{
		if (func == actvlist[i])
			return(1);
		}
	return(0);
}
 
void help_msg()
{
	fprintf(errmsg,
	"\n\tusage: fchart [-flag(s)] [func_name(s)] infile [>outfile]\n\n");
 
	fprintf(errmsg,"\t-t\t\tterse form (default)\n");
	fprintf(errmsg,"\t-v\t\tverbose form\n");
	fprintf(errmsg,"\t-wnn\tdisplay width is nn (default 78)\n");
	fprintf(errmsg,"\t-h\t\thelp\n");
	fprintf(errmsg,"\tname\t\tfunction to start from\n\n");
}
 
void quit()
{
 
	help_msg();
	exit(1);
}
 
/*	report file not found
*/
void fnf(s)
UCHAR *s;
{
 
	fprintf(errmsg,"\nfchart: File not found: %s\n",s);
	exit(1);
}
 
/*	print copyright message
*/
void banner()
{
   fprintf(errmsg
	  ,"fchart -  C function flow-charter v. %s\n",VERSION);
   fprintf(errmsg
	  ,"Copyright (c) 1983,84,85 Solution Systems ALL RIGHTS RESERVED\n");
}

