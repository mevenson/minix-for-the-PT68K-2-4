#include <stdio.h>

main()
{
    char* clrScreen = "\033[H\033[J";
    printf (clrScreen);
}

