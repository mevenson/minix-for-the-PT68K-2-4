\This has been bubbling away now for some time, but I've got all the bugs I
could find out. Now could somebody tell me why the 1.5.0 dir(3) functions
don't work with this?
 
	Warren Toomey		wkt@csadfa.oz.au@munnari.oz[@uunet]
 
--------------------------- unshar from here -----------------------------
echo x - Readme
sed '/^X/s///' > Readme << '/'
XHere are versions of dump(8) and restore(8) that I've been writing for
Xthe past few months. They are similar to the BSD commands, but written
Xspecifically for Minix. Features are:
X
X	- can do multi-volume backups, specifying
X	  the size of the dump device
X	- incremental backups
X	- an interactive restore
X	- the header of a dump is in human-readable form
X
XAlso included is a small shell script, dumper, which does incremental
Xbackups of certain directories to a dump directory. Done at regular
Xintervals, you shouldn't lose many files. Please note a) I only wrote
Xthe script yesterday, b) I can't shell program, so don't flame back,
Xfix it!
X
XI hope all of this is useful :-) Bug reports, comments etc to
X
X	Warren Toomey		wkt@csadfa.oz.au@munnari.oz[@uunet]
X
/
echo x - Makefile
sed '/^X/s///' > Makefile << '/'
XCFLAGS= -DMINIX
XLIBS= -ldir
XO= .s
X
Xall: dump restore
X
Xdump: dump$(O) global$(O)
X	cc -o dump $(CFLAGS) $(DEBUG) dump$(O) global$(O) $(LIBS)
X
Xrestore: restore$(O) global$(O)
X	cc -o restore $(CFLAGS) $(DEBUG) restore$(O) global$(O) $(LIBS)
X
Xdump$(O): dump.c header.h
X	cc -c $(CFLAGS) $(DEBUG) dump.c
X
Xglobal$(O): global.c header.h
X	cc -c $(CFLAGS) $(DEBUG) global.c
X
Xrestore$(O): restore.c header.h
X	cc -c $(CFLAGS) $(DEBUG) restore.c
X
X
Xclr:
X	- rm *$(O) dump restore dumpdates
X
Xshar:	Readme Makefile dump.c dump.8 restore.c restore.8 header.h global.c dumper dumpdirs
X	shar Readme Makefile dump.c dump.8 restore.c restore.8 \
X 	header.h global.c dumper dumpdirs > dump.shar
/
echo x - dump.c
sed '/^X/s///' > dump.c << '/'
X#include "header.h"
X
X	/* Dump: Dump files to device or file. Does incrementals */
X	/*	 and multi-volume dumps as well.		 */
X
X	/* Written by Warren Toomey - 1989,1990		         */
X	/* You may freely copy or give away this source as       */
X	/* long as this notice remains intact.		         */
X
X
Xvoid usage()				/* Print out the usage line */
X {
X  fprintf(stderr,"Usage: dump [-0123456789] [-V] [-q] [-f dumpfile] [-v vol] directory\n");
X  exit(0);
X }
X
X
Xlong getlast(level,device)		/* Get last dump date from file */
X int level;
X char *device;
X {
X  FILE *dumpfile;
X  long tim,lastdump[10];
X  char dev[80],dummy1[6],dummy2[5],dummy3[3];
X  int i,lev;
X
X  if ((dumpfile=fopen(DUMPFILE,"r"))==NULL)
X    return(0L);
X
X  for (i=0;i<10;i++) lastdump[i]=0L;
X  while (!feof(dumpfile))		/* Get a dump line from file */
X   {
X    fscanf(dumpfile,"%ld %s %d %s %s %s",&tim,dummy1,&lev,dummy2,dummy3,dev);
X    while (((i=fgetc(dumpfile))!='\n') && (i!=EOF));
X
X    if (!strcmp(device,dev))		/* If the same device */
X      lastdump[lev]=tim;		/* save the time */
X   }
X  fclose(dumpfile);
X
X  tim=0L;
X  for (i=0;i<level+1;i++)		/* Now get the last dump of our level */
X     if (lastdump[i]!=0) tim=lastdump[i];
X
X  return(tim);				/* and return it */
X }
X    
X
Xvoid savedate(level,device)		/* Save this dump's date to a file */
X int level;
X char *device;
X {
X  FILE *dumpfile;
X  extern long curtim;
X
X  if ((dumpfile=fopen(DUMPFILE,"a"))==NULL)
X    perror("savedate");
X
X  time(&curtim);	/* Get the current time */
X			/* and append line to dump file */
X
X  fprintf(dumpfile,"%ld Level %d dump of %s on %s",curtim,level,device,
X	  ctime(&curtim));
X }
X
X  
Xint getinfo(file)		/* Get stat info about given file */
X char *file;
X {
X  extern struct stat buff;
X
X  if (stat(file,&buff)!=0) return(1);
X  else return(0);
X }
X 
X
Xvoid search(directory,lvl) /* Find every file in the given directory */
X char *directory;
X int lvl;
X {
X  extern struct stat buff;
X  extern long lastim;
X  extern char *dirlist[];
X  extern INODE inolist[];
X  extern int aindex;
X  DIR *dir;
X#ifdef MINIX
X  struct dirent *dinfo;
X#else
X  struct direct *dinfo;
X#endif
X  char name[80];
X
X  strcat(directory,"/");
X  if ((dir=opendir(directory))==NULL)
X    {
X     fprintf(stderr,"Couldn't open %s\n",directory);
X     return;
X    }
X
X  readdir(dir);
X  readdir(dir);		/* Skip . and .. */
X
X  for (dinfo=readdir(dir);dinfo!=NULL;dinfo=readdir(dir))
X     {
X      strcpy(name,directory); 	/* Use full path name */
X      strcat(name,dinfo->d_name);
X      if (getinfo(name)) continue;	/* If bad, skip it */
X      if ((lvl==0) || (buff.st_mtime>lastim))
X        {			/* else dump it */
X	 if ((dirlist[aindex]=(char *)malloc(strlen(name)+1))==0)
X	   perror("search"); 
X	 strcpy(dirlist[aindex],name); 
X	 inolist[aindex].inode=buff.st_ino;
X	 inolist[aindex].mode=buff.st_mode;
X	 inolist[aindex].links=buff.st_nlink;
X	 inolist[aindex].uid=buff.st_uid;
X	 inolist[aindex].gid=buff.st_gid;
X	 inolist[aindex].size=buff.st_size;
X	 inolist[aindex].atime=buff.st_atime;
X	 inolist[aindex].mtime=buff.st_mtime;
X#ifndef MINIX
X	 inolist[aindex].blocks=buff.st_blocks;
X#endif
X	 aindex++;
X        }
X      if ((buff.st_mode & S_IFMT)==S_IFDIR) search(name,lvl);
X     }
X  closedir(dir);
X  }
X
X
Xvoid dumpit(dname,lvl,dev,vol,verb)	/* Dump everything to file */
X char *dname;
X int lvl;
X char *dev;
X int vol;
X int verb;
X {
X  extern long curtim;
X  extern int volnum;
X  extern char buffer[];
X#ifdef LOWIO
X  int dfile, infile;
X#else
X  FILE *dfile, *infile;				/* Firstly dump date etc */
X#endif
X  int c,i,j,k;
X  long posn,numblks;
X
X  volnum=1;
X#ifdef LOWIO
X  if ((dfile=creat(dname,0700))==-1)
X    perror("dumpit1");
X#else
X  if ((dfile=fopen(dname,"w"))==NULL)
X    perror("dumpit2");
X#endif
X
X#ifdef LOWIO
X  sprintf(buffer,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
X	  ctime(&curtim));
X  write(dfile,buffer,strlen(buffer));
X  sprintf(buffer,"Volume %d ",volnum);
X  write(dfile,buffer,strlen(buffer));
X  sprintf(buffer,"Size %d K\n",vol);
X  write(dfile,buffer,strlen(buffer));
X  sprintf(buffer,"%d files\n",aindex);
X  write(dfile,buffer,strlen(buffer));
X
X  for (i=0;i<aindex;i++)		/* Now dump the file names */
X   {					/* and the inode list */
X    sprintf(buffer,"%s\n",dirlist[i]);
X    write(dfile,buffer,strlen(buffer));
X   }
X
X  if ((i=write(dfile,inolist,sizeof(INODE)*aindex))!=sizeof(INODE)*aindex)	
X     printf("dumpit3: write wrote only %d bytes\n",aindex);
X
X  posn=lseek(dfile,0L,1);		/* Get current posn */
X  numblks=posn/BLKSIZE +1L;
X  posn=BLKSIZE * numblks;
X  if ((lseek(dfile,posn,0))==-1)	/* and seek to next block */
X    perror("dumpit4");
X
X#else
X  fprintf(dfile,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
X	  ctime(&curtim));
X  fprintf(dfile,"Volume %d Size %d K\n",volnum,vol);
X  fprintf(dfile,"%d files\n",aindex);
X
X  for (i=0;i<aindex;i++)		/* Now dump the file names */
X   fprintf(dfile,"%s\n",dirlist[i]);	/* and the inode list */
X
X  if ((i=fwrite(inolist,sizeof(INODE),aindex,dfile))!=aindex)	
X     printf("dumpit5: fwrite wrote only %d of %d inodes\n",i,aindex);
X
X  posn=ftell(dfile);			/* Get current posn */
X  numblks=posn/BLKSIZE +1L;
X  posn=BLKSIZE * numblks;
X  if ((fseek(dfile,posn,0))==-1)	/* and seek to next block */
X    perror("dumpit6");
X#endif
X					/* Finally dump the blocks */
X  for (i=0;i<aindex;i++)		/* except dirs & null files */
X   {
X    if (verb) printf("%s\n",dirlist[i]);
X#ifdef DEBUG
X# ifdef MINIX
X  printf("Inode:  %x\n",inolist[i].inode);
X  printf("Mode:   %x		Links:   %x\n",inolist[i].mode,inolist[i].links);
X  printf("Uid:    %x		Gid:     %x\n",inolist[i].uid,inolist[i].gid);
X  printf("Size:   %lx\n",inolist[i].size);
X  printf("Atime:  %lx\n",inolist[i].atime);
X  printf("Mtime:  %lx\n",inolist[i].mtime);
X# else
X  printf("Inode:   %ld\n",inolist[i].inode);
X  printf("Mode:   %o		Links:   %d\n",inolist[i].mode,inolist[i].links);
X  printf("Uid:    %d		Gid:     %d\n",inolist[i].uid,inolist[i].gid);
X  printf("Size:   %ld\n",inolist[i].size);
X  printf("Atime:  %ld\n",inolist[i].atime);
X  printf("Mtime:  %ld\n",inolist[i].mtime);
X# endif
X  printf("\n\n");
X#endif
X    if ((inolist[i].mode & S_IFMT)==S_IFDIR) continue;
X    if (inolist[i].size==0) continue;
X#ifdef LOWIO
X    if ((infile=open(dirlist[i],O_RDONLY))==-1)
X      perror("dumpit7");
X#else
X    if ((infile=fopen(dirlist[i],"r"))==NULL)
X      perror("dumpit8");
X#endif
X
X    while(1)
X       {
X        for (k=0;k<BLKSIZE;k++) buffer[k]=' ';	/* May not be needed */
X#ifdef LOWIO
X	j=read(infile,buffer,sizeof(char)*BLKSIZE);
X        write(dfile,buffer,sizeof(char)*BLKSIZE);
X#else
X	j=fread(buffer,sizeof(char),BLKSIZE,infile);
X        fwrite(buffer,sizeof(char),BLKSIZE,dfile);
X#endif
X	if ((vol) && (++numblks==vol))		/* Swap disks */
X          {
X#ifdef LOWIO
X	   close(dfile);
X	   printf("Remove disk & insert disk %d\n",++volnum);
X	   while ((c=getchar())!='\n');
X  	   if ((dfile=creat(dname,0700))==-1)
X    	     perror("dumpit9a");
X	   if ((dfile=open(dname,O_WRONLY))==-1)
X	     perror("dumpit9b");
X  	   sprintf(buffer,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
X	  		 ctime(&curtim));
X	   write(dfile,buffer,strlen(buffer));
X  	   sprintf(buffer,"Volume %d\n",volnum);
X	   write(dfile,buffer,strlen(buffer));
X  	   posn=lseek(dfile,0L,1);			/* Get current posn */
X  	   numblks=posn/BLKSIZE +1L;
X  	   posn=BLKSIZE * numblks;
X  	   if ((lseek(dfile,posn,0))==-1)	/* and seek to next block */
X	     perror("dumpitA");
X#else
X	   fclose(dfile);
X	   printf("Remove disk & insert disk %d\n",++volnum);
X	   while ((c=getchar())!='\n');
X	   if ((dfile=fopen(dname,"w"))==NULL)
X	     perror("dumpitB");
X  	   fprintf(dfile,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
X	  		 ctime(&curtim));
X  	   fprintf(dfile,"Volume %d\n",volnum);
X  	   posn=ftell(dfile);			/* Get current posn */
X  	   numblks=posn/BLKSIZE +1L;
X  	   posn=BLKSIZE * numblks;
X  	   if ((fseek(dfile,posn,0))==-1)	/* and seek to next block */
X	     perror("dumpitC");
X#endif
X	  }
X   /*   if (j<BLKSIZE) printf("dumpitD: fread short %d\n",j); */
X        if (j<BLKSIZE) break;
X       }
X
X#ifdef LOWIO
X    close(infile);
X#else
X    fclose(infile);
X#endif
X   }
X    
X
X#ifdef LOWIO
X    close(dfile);
X#else
X    fclose(dfile);
X#endif
X }
X
X
X
Xmain(argc,argv)				/* Set up dir name & call search */
X int argc;
X char *argv[];
X {
X  extern int optind;
X  extern char *optarg;
X  extern long lastim;			/* Last dump time */
X  extern int aindex;
X  extern int volnum;
X  extern struct stat buff;
X  extern char *dirlist[];
X  extern INODE inolist[];
X  int c,verbose;
X
X  int vol,level;		/* Volume of dump device, and dump level */
X  char dumpdev[80];		/* Dump device's name */
X  char dumpfrom[80];		/* Dump from this directory */
X  int quick;			/* To dump, or just lie */
X
X
X  level=0; vol=DEFVOL;
X  aindex=0; verbose=0;
X  quick=0;
X  strcpy(dumpdev,DEFDEVICE);	/* Set up default values */
X
X  if (argc==1) usage();
X
X  while ((c=getopt(argc,argv,"0123456789Vqf:v:"))!=EOF)
X    switch(c)
X     {
X      case '0' : level=0;	/* Get the various options */
X		 break;
X      case '1' : level=1;
X		 break;
X      case '2' : level=2;
X		 break;
X      case '3' : level=3;
X		 break;
X      case '4' : level=4;
X		 break;
X      case '5' : level=5;
X		 break;
X      case '6' : level=6;
X		 break;
X      case '7' : level=7;
X		 break;
X      case '8' : level=8;
X		 break;
X      case '9' : level=9;
X		 break;
X      case 'V' : verbose=1;
X		 break;
X      case 'f' : strcpy(dumpdev,optarg);
X		 break;
X      case 'v' : vol=atoi(optarg);
X		 break;
X      case 'q' : quick=1;
X		 break;
X      default  : usage();
X     }
X
X  strcpy(dumpfrom,argv[argc-1]);	/* Finally get where to dump from */
X
X					/* Quick mode - don't dump :-) */
X  if (quick) { savedate(level,dumpfrom);
X	       exit(0);
X	     }
X
X#ifdef DEBUG
X  printf("Vol:   %d Device: %s\n",vol,dumpdev);
X  printf("Level: %d Dump from: %s\n",level,dumpfrom);
X#endif
X
X  lastim=getlast(level,dumpfrom);
X  printf("Last dump time of level %d for %s was %s",level,dumpfrom,
X          ctime(&lastim));
X  savedate(level,dumpfrom);
X  printf("Searching directory tree...\n");
X
X  if (getinfo(dumpfrom))
X    perror("main");
X  if ((dirlist[aindex]=(char *)malloc(strlen(dumpfrom)+1))==0)
X    perror("search"); 
X  strcpy(dirlist[aindex],dumpfrom); 
X  inolist[aindex].inode=buff.st_ino;	/* Yes, all of this is  */
X  inolist[aindex].mode=buff.st_mode;	/* kludgy and should be */
X  inolist[aindex].links=buff.st_nlink;	/* done in search()     */
X  inolist[aindex].uid=buff.st_uid;
X  inolist[aindex].gid=buff.st_gid;
X  inolist[aindex].size=buff.st_size;
X  inolist[aindex].atime=buff.st_atime;
X  inolist[aindex].mtime=buff.st_mtime;
X#ifndef MINIX
X  inolist[aindex].blocks=buff.st_blocks;
X#endif
X  aindex++;
X
X  search(dumpfrom,level);		/* Now search for files to dump */
X  if (aindex!=1)
X    {
X     printf("Dumping files...\n");		
X     dumpit(dumpdev,level,dumpfrom,vol,verbose);	/* and dump them */
X    }
X  exit(0);
X }
/
echo x - dump.8
sed '/^X/s///' > dump.8 << '/'
X.TH dump 8
X.SH NAME
Xdump \- dump whole directories
X.SH SYNTAX
Xdump [\-0123456789V] [\-V] [\-q] [\-f filename] [\-v vol] directory
X.SH OPTIONS
XOptions are processed by
X.B getopts(3).
X.TP 8
X.B \-#   
X(where # is a single digit). Describes the level of
Xthis dump. All files/directories in the named directory
Xthat are younger than the last dump of this level will be
Xbacked up.
X.TP
X.B \-V
XVerbose mode.
X.I Dump
Xprints a list of files that are being backed up.
X.TP
X.B \-q
XQuick mode.
XA dump is not done; however,
X.B /usr/adm/dumpdates
Xis updated as if a dump was done.
XThis is so incrementals can be done without ever
Xhaving done a full dump.
X.TP
X.B \-f filename
XIf
X.I dump
Xis not told, it will write to the default output file.
XFor Minix, this is /dev/fd0. If this option is used,
X.I dump
Xwill write to the named file instead.
X.TP
X.B \-v vol
X.I Dump
Xbreaks its output up into default units of 360K. The volume
Xoption causes
X.I dump
Xto break the output up into `vol' K.
XNote that a volume of 0 tells
X.I dump
Xto write its output with
X.I no
Xbreaks.
X.SH DESCRIPTION
X.I Dump
Xbacks up files and directories within the named
X.B directory.
XThese files can be retrieved with
X.I restore(8).
X.I Dump
Xstores all of the attributes of the files/directories dumped;
Xthis includes the protection bits, the owner & group, and the
Xdates of last modification and last access. These are returned
Xwhen the files are restored.
X.PP
X.I Dump
Xprovides ten levels of dumping. Level 0 (the default) is a full backup.
XAll files within the named directory are dumped. Levels 1 to 9
Xare incremental backups; only those files/directories younger than
Xthe last dump of this level are dumped. This allows a redundant
Xmethod of backing up, such as the `Towers of Hanoi'.
X.PP
XBefore doing a dump (especially a full dump), do a
X.B du
Xof the directory that you want to dump. This will give you an idea
Xof the number of disks you will need. Of course you will need much
Xless if you are doing an incremental dump.
X.I Dump
Xprompts you at the end of each volume to stick a new disk in. It
Xthen waits for you to press return, telling it to continue with
Xthe dump.
X.SH EXAMPLES
XTo make a backup of /usr, onto 360K floppies, do
X.TP
X.B dump /usr
X.PP
XTo do an incremental dump at a later date, do
X.TP
X.B dump -9 /usr
X.PP
XFor 720K disks, alter the volume size & the dump file, such as
X.TP
X.B dump -f/dev/at0 -v720 /usr
X.SH SPECIAL CONSIDERATIONS
X.I Dump
Xmaintains a list of dumpdates in
X.B /usr/adm/dumpdates.
XIt also notes the name of the directory being dumped, so that
Xa level 7 dump of /usr won't dump files younger than the last
Xlevel 7 dump of /user.
X.PP
XNote that files will be restored to the directory you gave to
X.I dump.
XSo, to make a relative dump of /usr, cd to /usr and do
X.TP
X.B dump \.
X.PP
XThis will allow you to restore these files to another directory,
Xsuch as /usr/old, by cd'ing to /usr/old, and running
X.I restore.
XDoing a
X.TP
X.B dump /usr
X.PP
Xwill only allow the dumped files to be restored to /usr.
X.PP
XCurrently
X.I dump
Xwill only dump directories and normal files; it will probably
Xhave a hernia on device files. Also, links are not taken into
Xaccount. Two linked files will be dumped twice. This should not
Xbe a great problem. Finally, there is a static limit to the
Xnumber of files that can be dumped at any one time; at the moment
Xthis is 1000 files.
X
X.SH FILES
X /usr/adm/dumpdates     Dates of file dumps.
X /dev/fd0               Default dump device.
X.SH SEE ALSO
Xrestore(8), du(1).
/
echo x - restore.c
sed '/^X/s///' > restore.c << '/'
X#include <stdio.h>
X#include <ctype.h>
X#ifdef MINIX
X#include <string.h>
X#else
X#include <strings.h>
X#endif
X#include "header.h"
X
X	/* Restore: Restore files from a dump made by dump(8) */
X
X	/* Written by Warren Toomey - 1989		      */
X	/* You may freely copy or give away this source as    */
X	/* long as this notice remains intact.		      */
X
X
Xchar fgetarg(stream,cbuf)		/* Get next arg from file into cbuf, */
X FILE *stream;				/* returning the character that      */
X char *cbuf;				/* terminated it. Cbuf returns NULL  */
X {					/* if no arg. EOF is returned if no  */
X  char ch;				/* args left in file.                */
X  int i;
X
X  i=0; cbuf[i]=NULL;
X
X  while (((ch=fgetc(stream))==' ') || (ch=='\t') || (ch=='\n'))
X    if (ch=='\n') return(ch);				/* Bypass leading */
X							/* whitespace     */
X  if (feof(stream)) return(EOF);
X  
X  cbuf[i++]=ch;
X
X  while (((ch=fgetc(stream))!=' ') && (ch!='\t') && (ch!='\n'))
X    cbuf[i++]=ch;					/* Get the argument */
X
X  cbuf[i]=NULL;
X  return(ch);
X }
X
X
X
X#ifdef MINIX
Xint mkdir(path,mode)		/* Make directory */
X char *path;
X int mode;
X {
X  char cmd[80];
X  int i;
X
X  sprintf(cmd,"/usr/bin/mkdir %s",path);
X  i=system(cmd);
X  if (i==0) return(chmod(path,mode));
X  else return(-1);
X }
X
X
Xint rmdir(path)			/* Delete directory */
X char *path;
X {
X  char cmd[80];
X  int i;
X
X  sprintf(cmd,"/usr/bin/rmdir %s",path);
X  i=system(cmd);
X  return(i);
X }
X#endif
X
X
Xls(i,j)				/* List file i; long if j==1 */
X int i,j;
X {
X  extern char *dirlist[];	/* Some of the code stolen from */
X  extern INODE inolist[];	/* Andy Tanenbaum's ls program  */
X  extern char resflag[];
X  extern char *strrchr();
X
X  static char *rwx[] =	{"---", "--x", "-w-", "-wx", "r--", "r-x", "rw-", "rwx",
X		 	"--s", "--s", "-ws", "-ws", "r-s", "r-s", "rws", "rws"};
X  int m,prot;
X  char *p1, *p2, *p3, c;
X  char ch,tstrng[26];
X
X  if (resflag[i]==1) ch='*'; else ch=' ';
X  if (j)
X    {
X        switch (inolist[i].mode & S_IFMT)	/* Set directory, char    */
X	  {					/* special, block special */
X	   case S_IFDIR : c='d';		/* or none of the above   */
X			  break;
X	   case S_IFBLK : c='b';
X			  break;
X	   case S_IFCHR : c='c';
X			  break;
X	   default      : c='-';
X	  }
X
X	m = inolist[i].mode & 07777;
X	prot = (m >> 6) & 07;		/* Get the user protection */
X	if (m & S_ISUID) prot += 8;
X	p1 = rwx[prot];
X
X	prot = (m >> 3) & 07;
X	if (m & S_ISGID) prot += 8;	/* Get the group protection */
X	p2 = rwx[prot];
X
X	prot = m & 07;			/* & the other protection */
X	p3 = rwx[prot];
X
X	printf("%c %c%s%s%s %2d ",ch,c, p1, p2, p3, inolist[i].links);
X
X	/* Print owner & group as decimal numbers, as the restore */
X	/* may be very out of date				  */
X
X        printf("%6d %6d ",inolist[i].uid,inolist[i].gid);
X
X       strcpy(tstrng,ctime(&inolist[i].mtime)); tstrng[24]=0;
X       printf("%8ld %s ",inolist[i].size,&tstrng[4]);
X       if ((p1=strrchr(dirlist[i],'/'))==NULL)
X	 printf("%s\n",dirlist[i]);
X       else printf("%s\n",p1+1);	/* Finally the size, date & */
X    }					/* filename */
X  else
X    printf("%c  %s\n",ch,dirlist[i]);
X }
X
X
X
Xchar *cd(pre,post)		/* Add post to pre & form full */
X char *pre, *post;		/* path name */
X {
X  extern char *strchr();
X  extern size_t strcspn();
X  char full[100],temp[100];
X  char *p1, *p2;
X  int i;
X
X  p1=post;
X  strcpy(full,pre);			/* Get first part of pathname */
X  while ((i=strcspn(p1,"/"))!=0)
X   {
X    strncpy(temp,p1,i);			/* Get next part of pathname */
X    temp[i++]=NULL;
X
X    if (strcmp(temp,"."))		/* Ignore . */
X     if (!strcmp(temp,".."))		/* Reduce full */
X      {
X	if ((p2=strrchr(full,'/'))!=NULL)
X	   *p2=NULL;
X	else return(NULL);		/* Err if can't reduce */
X      }
X     else
X      { strcat(full,"/");
X        strcat(full,temp);		/* Else just add on */
X      }
X
X    if (i>strlen(p1)) break;		/* If last bit, break out */
X    p1+=i;				/* else move pointer up */
X   }
X  return(full);
X }
X  
X
X
X
Xint strnum(s1,ch)		/* Get no. of ch's in s1 */
X char *s1;
X char ch;
X {
X  int i,cnt=0;
X
X  for (i=0;s1[i]!=0;i++)
X    cnt += (s1[i]==ch) ? 1 : 0;
X  return(cnt);
X }
X  
X
Xint getinfo(file)		/* Get stat info about given file */
X char *file;
X {
X  extern struct stat buff;
X
X  if (stat(file,&buff)!=0)
X    return(0);
X  else return(1);
X }
X 
X
XFILE *gethdr(device,mode,vol)		 /* Get the list of files & inodes */
X char *device;				 /* If mode == 0, just get header  */
X int mode, *vol;
X {
X  extern char *dirlist[];
X  extern INODE inolist[];
X  extern int volnum;
X  extern int nfiles[];
X  extern char header[];
X
X  FILE *fd;
X  int c,i,thisvol;
X  char dummy[80];
X
X  i=0;
X  if ((fd=fopen(device,"r"))==NULL)
X    perror("gethdr");		/* Open the dump file */
X
X  while ((c=fgetc(fd))!='\n') header[i++]=c;	/* Get first line */
X  header[i]=NULL;
X
X  fscanf(fd,"%s %d",dummy,&thisvol);
X
X  if (thisvol!=volnum)
X   { fprintf(stderr,"Wrong volume! %d instead of %d\n",thisvol,volnum);
X     fclose(fd);
X     return(NULL);
X   }
X
X  if (mode!=0) fscanf(fd, "%s %d", dummy, vol);	/* Get disk size */
X
X  while ((c=fgetc(fd))!='\n');			/* Get rest of line */
X
X  if (mode==0) return(fd);		/* Only get file names once */
X  fscanf(fd,"%d %s\n",&i,dummy);
X  nfiles[0]=i;
X
X  for (i=0;i<*nfiles;i++)
X   {
X    fscanf(fd,"%s\n",dummy);		/* Read in the file names */
X    dirlist[i]=(char *)malloc(strlen(dummy)+1);
X    strcpy(dirlist[i],dummy);
X   }
X#ifdef MINIX			/* For some reason, Minix doesn't get */
X  c=fgetc(fd);			/* the last \n ; this caused several  */
X#endif				/* hours of frustration. Aaaarrggh!   */
X
X  fread(inolist,sizeof(INODE),*nfiles,fd);	/* And get the inodes */
X  return(fd);
X }
X
X
Xprinttable(verb)		/* Print out a table of dumped files */
X int verb;
X {
X  extern FILE *dumpfile;
X  extern int nfiles[];
X  int i;
X
X  fclose(dumpfile);			/* Close the file */
X
X  for (i=0;i<*nfiles;i++)
X   {
X    printf("%s\n",dirlist[i]);		/* and print filenames */ 
X    if (verb)
X      {
X#ifdef MINIX
X       printf("\tInode:  %d\t\tSize:    %ld\n",inolist[i].inode,inolist[i].size);
X       printf("\tMode:   %o\t\tLinks:   %d\n",inolist[i].mode,inolist[i].links);
X       printf("\tUid:    %d\t\tGid:     %d\n",inolist[i].uid,inolist[i].gid);
X       printf("\tAtime:  %ld\tMtime:   %ld\n\n",inolist[i].atime,inolist[i].mtime);
X#else
X       printf("\tInode:  %ld\t\tSize:    %ld\n",inolist[i].inode,inolist[i].size);
X       printf("\tMode:   %o\t\tLinks:   %d\n",inolist[i].mode,inolist[i].links);
X       printf("\tUid:    %d\t\tGid:     %d\n",inolist[i].uid,inolist[i].gid);
X       printf("\tAtime:  %ld\tMtime:   %ld\n\n",inolist[i].atime,inolist[i].mtime);
X#endif
X      }
X   }
X }
X
X
X
Xint getresfils()			/* Get list of files to restore */
X {					/* Interactively */
X  extern char resflag[];
X  static char *cmd[10] = { "add","cd","del","get","help",
X			  "ls","pwd","quit","show","?" };
X  char cmdline[100];
X  char origcwd[100],cwd[100];
X  char ch;
X  int cwdslash,ourslash;
X  int i,j,quit;				/* Quit = 0 to loop */
X					/*	= 1 to exit */
X					/*	= 2 to get  */
X
X  quit=0; j=0;
X  printf("%s\n\n",header);		/* Print the header out */
X  for (i=0;i<*nfiles;i++) resflag[i]=0;	/* No files selected yet */
X  for (i=26;header[i]!=' ';cwd[j++]=header[i++]);	/* Get cwd */
X  cwd[j]=NULL;
X  if (lastchar(cwd)=='/') lastchar(cwd)=NULL;
X  strcpy(origcwd,cwd);			/* & make it the original */
X  while (quit==0)
X   {
X    if (lastchar(cwd)=='/') lastchar(cwd)=NULL;
X    cwdslash=strnum(cwd,'/')+1;		/* Count # of slashes in cwd */
X    printf("Restore> ");
X    ch=getarg(cmdline);			/* Get the command */
X    for (i=0;i<9;i++)
X     if (!strncmp(cmd[i],cmdline,strlen(cmdline)))
X       break;
X    switch(i)
X     {
X      case 0  : if (ch=='\n')			/* Add */
X		  strcpy(cmdline,cwd);
X		else				/* Get file/directory */
X		  { ch=getarg(cmdline);
X		    if (cmdline[0]=='/')
X		      strcpy(cmdline,cd(origcwd,&cmdline[1]));
X		    else
X		      strcpy(cmdline,cd(cwd,cmdline));
X		    if (cmdline[0]==NULL)
X		     {
X		      printf("Bad directory name\n");
X		      break;
X		     }
X		  }
X
X    		ourslash=strnum(cmdline,'/');	/* Count # of slashes */
X	        for (i=0;i<*nfiles;i++)
X		  if ((strnum(dirlist[i],'/')>=ourslash))
X		    if (!strncmp(cmdline,dirlist[i],strlen(cmdline)))
X		       resflag[i]=1;
X
X		for (;ch!='\n';ch=getarg(cmdline));
X		break;
X      case 1  : if (ch=='\n')			/* Cd */
X		 {
X		  strcpy(cwd,origcwd);		/* If no arg, set to */
X		  break;			/* origcwd */
X		 }
X		ch=getarg(cmdline);		/* Get arg */
X		if (!strcmp(cmdline,"/"))
X		 {
X		  strcpy(cwd,origcwd);		/* If /, set to */
X		  break;			/* origcwd */
X		 }
X		if (cmdline[0]=='/')
X		  strcpy(cmdline,cd(origcwd,&cmdline[1]));	/* Now get */
X		else
X		  strcpy(cmdline,cd(cwd,cmdline));	/* full pathname */
X		if (cmdline[0]==NULL)
X		  printf("Bad directory name\n");
X		else strcpy(cwd,cmdline);
X		for (;ch!='\n';ch=getarg(cmdline));
X		break;
X      case 2  : if (ch=='\n')			/* Del */
X		  strcpy(cmdline,cwd);
X		else				/* Get file/directory */
X		  { ch=getarg(cmdline);
X		    if (cmdline[0]=='/')
X		      strcpy(cmdline,cd(origcwd,&cmdline[1]));
X		    else
X		      strcpy(cmdline,cd(cwd,cmdline));
X		    if (cmdline[0]==NULL)
X		     {
X		      printf("Bad directory name\n");
X		      break;
X		     }
X		  }
X
X    		ourslash=strnum(cmdline,'/');	/* Count # of slashes */
X	        for (i=0;i<*nfiles;i++)
X		  if ((strnum(dirlist[i],'/')==ourslash) ||
X		      (strnum(dirlist[i],'/')==ourslash+1))
X		    if (!strncmp(cmdline,dirlist[i],strlen(cmdline)))
X		       resflag[i]=0;
X
X		for (;ch!='\n';ch=getarg(cmdline));
X		break;
X      case 3  : if (ch!='\n') { printf("get takes no args!\n");
X				for (;ch!='\n';ch=getarg(cmdline));
X				break;
X			      }
X		j=0;
X		for (i=0;i<*nfiles;i++)
X		 j+= resflag[i];
X		if (j!=0) quit=2;		/* Get */
X 		else printf("No files to get!\n");
X		for (;ch!='\n';ch=getarg(cmdline));
X		break;
X      case 5  : j=0;				/* Ls */
X		printf("%s:\n",cwd);
X		if (ch==' ')
X		  { ch=getarg(cmdline);
X		    if (!strcmp(cmdline,"-l")) j=1;
X		  }
X	        for (i=0;i<*nfiles;i++)
X		   if ((strnum(dirlist[i],'/')==cwdslash))
X		     if (!strncmp(cwd,dirlist[i],strlen(cwd)))
X		       ls(i,j);
X		for (;ch!='\n';ch=getarg(cmdline));
X		break;
X      case 6  : printf("%s\n",cwd);		/* Pwd */
X		break;
X      case 7  : quit=1;				/* Quit */
X		break;
X      case 8  : for (i=0;i<*nfiles;i++)		/* Show */
X		  if (resflag[i])
X		   printf("%s\n",dirlist[i]);
X		break;
X      case 4  :
X      case 9  :					/* Help */
X      default : printf("\nCommands are:\n");
X		printf("\tadd  - Add a file/directory to restore list\n");
X		printf("\tcd   - Change to another directory\n");
X		printf("\tdel  - Delete a file/dir from the restore list\n");
X		printf("\tget  - Restore the list of files\n");
X		printf("\thelp - Display this message\n");
X		printf("\tls   - List the current directory\n");
X		printf("\tpwd  - Print the working directory\n");
X		printf("\tquit - Quit from restore\n");
X		printf("\tshow - Show the file that will be restored\n");
X		printf("\t?    - Display this message\n\n");
X		for (;ch!='\n';ch=getarg(cmdline));
X		break;
X     }
X   }
X  return(quit);
X }
X
X
Xrestore(dev,vol,mode,verb)			/* Restore the dumped files */
X char *dev;
X int vol;
X RESMODE mode;
X int verb;
X {
X  extern char *dirlist[];
X  extern INODE inolist[];
X  extern int volnum;
X  extern char buffer[];
X
X  extern FILE *dumpfile;
X  extern char header[];
X  FILE *newfile;
X  int c,exists,i,j,notdone,ouruid;
X  long numblocks,posn,size;
X  time_t timep[2];
X
X  umask(000);			/* Allow us to create any files */
X  ouruid=getuid();		/* Get our uid */
X
X  printf("%s\n",header);		/* Print the header */
X  printf("Restoring files...\n");
X
X  posn=ftell(dumpfile);		/* Move to start of dumped files */
X  numblocks= posn/BLKSIZE + 1L;
X  posn=BLKSIZE * numblocks;
X  if ((fseek(dumpfile,posn,0))==-1)
X    perror("restore");
X  
X  for (i=0;i<*nfiles;i++)	/* Print filename if verbose, and */
X   {				/* don't restore if not root & wrong uid */
X
X    if ((inolist[i].mode & S_IFMT)==S_IFDIR)	/* If a directory */
X     {						/* set dummy mode */
X      mkdir(dirlist[i],0700);			/* and fix later  */
X#ifdef DEBUG
X      printf("    is a directory\n");
X#endif
X      continue;					/* Always restore dirs */
X     }
X
X#ifdef DEBUG
X    printf("%s %d\n",dirlist[i],resflag[i]);
X#endif
X    exists=getinfo(dirlist[i]);			/* Get info on file */
X
X						/* Here are the many */
X						/* conditions that a */
X						/* file should be skipped */
X    if (  (resflag[i]==0) ||
X          ((ouruid!=0) && (inolist[i].uid!=ouruid)) ||
X          ((exists) && (mode==DIFF) && (buff.st_mtime>=inolist[i].mtime))  )
X      {
X	numblocks += inolist[i].size/BLKSIZE +1L;	/* Add on size */
X	if ((vol==0) || (numblocks<vol))
X	 {
X	  posn=numblocks*BLKSIZE;
X	  if ((fseek(dumpfile,posn,0))==-1)
X	    perror("restore");
X	 }
X      continue;						/* Skip to next file */
X     }
X
X    if (verb) printf("%s\n",dirlist[i]);
X    if (exists) chmod(dirlist[i],0700);
X    newfile=fopen(dirlist[i],"w");		/* else restore it ! */
X    size=0;
X    notdone=1;
X    if (inolist[i].size!=0)
X      while(notdone)
X       {
X	if ((vol!=0) && (numblocks>=vol))
X	  {
X	   fclose(dumpfile);
X	   j= numblocks/vol;			/* Calc next volume */
X	   volnum +=j;
X	   do {
X	       printf("Remove disk and insert disk %d\n",volnum);
X	       while((c=getchar())!='\n');
X	       dumpfile=gethdr(dev,0,&vol);		/* Reopen device */
X	      } while (dumpfile==NULL);
X	   numblocks=numblocks%vol + j;			/* Add enough to */
X	   posn=numblocks*BLKSIZE;			/* bypass header */
X	   if ((fseek(dumpfile,posn,0))==-1)
X	     perror("restore");
X	  }
X
X        j=fread(buffer,sizeof(char),BLKSIZE,dumpfile);
X
X        if (j<BLKSIZE) 
X         { printf("fread ran short on %s\n",dirlist[i]);
X           exit(1);
X         }
X
X	numblocks++;
X        size+= BLKSIZE;
X
X        if (size<=inolist[i].size)
X          fwrite(buffer,sizeof(char),BLKSIZE,newfile);
X        else
X	 {
X	  size=inolist[i].size-size+BLKSIZE;
X#ifdef MINIX
X					/* It appears that there is a large */
X					/* bug in Minix fwrite, because the */
X					/* line after the #else refuses to  */
X					/* work.			    */
X	  for (j=0;j<size;j++) fputc(buffer[j],newfile);
X#else
X          fwrite(buffer,sizeof(char),size,newfile);
X#endif
X	  notdone=0;
X   	 }				/* Close the file & set */ 
X       }				/* up it's attributes */
X      fclose(newfile);		
X      chmod(dirlist[i],inolist[i].mode);
X      timep[0]=inolist[i].atime;
X      timep[1]=inolist[i].mtime;
X      utime(dirlist[i],timep);
X      chown(dirlist[i],inolist[i].uid,inolist[i].gid);
X   }
X  fclose(dumpfile);
X
X  for (i= *nfiles;i> -1;i--)
X    if ((inolist[i].mode & S_IFMT)==S_IFDIR)	/* Now reset the */
X     if (resflag[i]==0)
X       rmdir(dirlist[i]);			/* directory values, */
X     else					/* deleting unwanted */
X      {						/* directories */
X       chmod(dirlist[i],inolist[i].mode);
X       timep[0]=inolist[i].atime;
X       timep[1]=inolist[i].mtime;
X       utime(dirlist[i],timep);
X       chown(dirlist[i],inolist[i].uid,inolist[i].gid);
X      }
X }
X
X
Xusage()
X {
X  fprintf(stderr,"Usage: restore [-Vodit] [-f dumpfile]\n");
X  exit(0);
X }
X
X
Xmain(argc,argv)
X int argc;
X char *argv[];
X {
X  extern int optind;
X  extern char *optarg;
X  extern FILE *dumpfile;	/* Dump file stream pointer */
X  extern int nfiles[];
X  extern char header[];
X  extern char resflag[];	/* `Restore yes?' flag for each file */
X  int c,verbose,interact;
X
X  int vol;			/* Volume of dump device */
X  char dumpdev[80];		/* Dump device's name */
X  RESMODE mode;			/* Mode of the restore */
X  int i;
X
X
X  strcpy(dumpdev,DEFDEVICE);	/* Set up default values */
X  mode=OVWRITE;
X  verbose=0;
X  interact=0;
X  volnum=1;
X  i=0;
X  vol=360;
X
X  while ((c=getopt(argc,argv,"Voditf:v:"))!=EOF)
X    switch(c)
X     {
X      case 'V' : verbose=1;	/* Get the various options */
X		 break;
X      case 'o' : mode=OVWRITE;
X		 break;
X      case 'd' : mode=DIFF;
X		 break;
X      case 't' : mode=TABLE;
X		 break;
X      case 'i' : interact=1;
X		 break;
X      case 'f' : strcpy(dumpdev,optarg);
X		 break;
X      default  : usage();
X     }
X
X
X#ifdef DEBUG
X  printf("Vol:   %d Device: %s\n",vol,dumpdev);
X#endif
X						/* Get the list of files */
X  dumpfile=gethdr(dumpdev,1,&vol);
X
X  for (i=0;i<*nfiles;i++) resflag[i]=1;		/* Assume we want all files */
X
X  if (interact)
X   if (getresfils()==1)	exit(0);		/* Interactively get files */
X						/* to restore		   */
X
X  switch(mode)
X   {
X    case TABLE :   printtable(verbose);		/* Give a table of files */
X		   break;
X    case OVWRITE :				/* Restore all files */
X    case DIFF :    restore(dumpdev,vol,mode,verbose);
X		   break;
X   }
X }
/
echo x - restore.8
sed '/^X/s///' > restore.8 << '/'
X.TH restore 8
X.SH NAME
Xrestore\- restore whole directories from backup disks
X.SH SYNTAX
Xrestore [-Vodit] [-f filename]
X.SH OPTIONS
XOptions are processed by
X.B getopts(3).
X.TP 8
X.B \-V
XVerbose mode.
X.I Restore
Xprints a list of files that are being restored.
X.TP
X.B \-o
XOverwrite mode (the default). Files will be restored regardless of
Xif they already exist.
X.TP
X.B \-d
XDifferential mode. Files will only be restored if they don't exist, or
Xare newer than the existing ones.
X.TP
X.B \-i
XInteractive mode. This allows you to list the files on the backup, select
Xthe ones you want to restore, and restore them.
X.TP
X.B \-t
XPrints a list of the files on the backup,
X.I without
Xrestoring them. If the
X.B \-V
Xoption is also on, a list of the attributes of each file will also
Xbe printed.
X.TP
X.B \-f filename
XIf
X.I restore
Xis not told, it will read from the default restore file.
XFor Minix, this is /dev/fd0. If this option is used,
X.I restore
Xwill read from the named file instead.
X.SH DESCRIPTION
X.I Restore
Xrestores files and directories from a backup done by
X.I dump(8).
XAll of the attributes of the files/directories dumped are restored;
Xthis includes the protection bits, the owner & group, and the
Xdates of last modification and last access.
X.PP
X.I Restore
Xprovides several modes of restoral.
X.I Overwrite
Xmode will restore the files dumped, regardless of their current
Xexistence.
X.I Differential
Xmode only returns files if newer instances of the files do not exist.
X.I Interactive
Xmode allows selection of the files to be restored (see below).
X.PP
XThe default dumpfile is /dev/fd0. This can be altered with the
X.B \-f
Xoption.
X.SH INTERACTIVE MODE
XInteractive mode provides a command line interface which allows you
Xto select files to be restored. Filenames may be relative or absolute,
Xand include . and .. ; however, metacharacters are not supported.
XThe commands available are:
X.TP 8
X.B add [filename]
XAdds the argument to the list of files to be restored. If the argument
Xis a directory, all of the files in that directory will be restored.
XIf no argument, the current directory is assumed.
X.TP
X.B cd [directory]
XMove to the directory specified.
X.I Restore
Xdoes not check to see if the new directory is in the dump. The root
Xdirectory is taken to be the top directory in the dump.
X.TP
X.B del [filename]
XDeletes the argument, with the same assumptions as
X.I add.
X.TP
X.B get
XProceeds to do the backup, with the requested files. If no files are
Xselected,
X.I restore
Xwill complain.
X.TP
X.B help
XDisplays a short message listing the commands available.
X.TP
X.B ls [-l]
XGives a listing of the files in the current directory, with an asterisk
Xmarking those to be restored. If the
X.I -l
Xoption is given, a long listing is given. Currently, files are listed
Xin ascending inode number, not alphabetically.
X.TP
X.B pwd
XPrints the current working directory. Note that this is
X.I not
Xthe same as the working directory under your shell. It is the `directory'
Xyou are in on the restore file.
X.I Restore
Xwill bring back files/directories in the real current working directory
Xthat you are in. I hope this isn't too confusing!
X.TP
X.B quit
XQuit from
X.I restore,
Xwithout restoring any files.
X.TP
X.B show
XShow a list of files that will be restored.
X.TP
X.B ?
XGives the help message.
X.SH SPECIAL CONSIDERATIONS
XNote that files are returned with the protection bits that they had
Xwhen thet were dumped, and also with the same uid and gid as at
Xdump time. This may be a security hole if uids/gid have changed on
Xyour system, or if you have backed up suid programs owned by root.
X.PP
XIf you are not root, you will only be able to restore files that you
Xhave dumped. You will not be able to restore files owned by someone
Xelse.
X.PP
XFiles will be restored in the directory they were dumped from. This is
Xno problem if they were dumped from
X.B \.
XHowever files dumped from an absolute path (such as
X.B /usr/local
X) will be returned to that directory.
X.PP
XAll directories are created during the dump, and those not needed are
Xdeleted. This may cause some empty directories to disappear. Also, since
Xan incremental dump does not contain the whole file structure,
X.I restore
Xmay have trouble returning files to subdirectories that don't
Xcurrently exist.
X.SH FILES
X /usr/adm/dumpdates     Dates of file dumps.
X /dev/fd0               Default restore device.
X.SH SEE ALSO
Xdump(8).
/
echo x - header.h
sed '/^X/s///' > header.h << '/'
X#define LOWIO		/* Uses open(), read() etc for dumping */
X#include <stdio.h>
X#include <sys/types.h>
X#include <sys/dir.h>
X#include <sys/stat.h>
X#ifdef MINIX
X# include <dirent.h>
X#endif
X#ifdef LOWIO
X# include <fcntl.h>
X#endif
X
X#ifndef BLKSIZE
X# define BLKSIZE 1024
X#endif
X
X#ifdef MINIX
X# define DEFDEVICE "/dev/fd0"		/* Default values */
X# define DUMPFILE "/usr/adm/dumpdates"
X#else
X# define DEFDEVICE "/usr/tmp/fd0"
X# define DUMPFILE "/usr/tmp/dumpdates"
X#endif
X
X#define DEFVOL 360
X#define ARYSIZE 1000			/* Arrays size */
X#define lastchar(x) x[strlen(x)-1]
X#define getarg(x) fgetarg(stdin,x)
X
X#ifdef MINIX
Xtypedef struct i_dumm { unsigned short inode;
X			unsigned short mode;
X			short int links;
X			short int uid;
X			short int gid;
X			long size;
X			long atime;
X			long mtime;
X		      } INODE;		/* My i-node structure */
X#else
Xtypedef struct i_dumm { int inode;
X			int mode;
X			int links;
X			int uid;
X			int gid;
X			long size;
X			long atime;
X			long mtime;
X			long blocks;
X		      } INODE;		/* My i-node structure */
X#endif
X
Xtypedef enum { DIFF, OVWRITE, TABLE } RESMODE;	/* Restore modes */
/
echo x - global.c
sed '/^X/s///' > global.c << '/'
X#include "header.h"
Xstruct stat buff;		/* Stat buffer */
Xlong lastim;			/* Time of last dump */
Xlong curtim;			/* Current time */
Xchar *dirlist[ARYSIZE];		/* List of files to dump */
XINODE inolist[ARYSIZE];		/* List of inodes to dump */
Xchar resflag[ARYSIZE];		/* Restore flag for each file */
Xint aindex;			/* Index into above arrays */
Xchar buffer[BLKSIZE];		/* A one-block buffer */
Xint volnum;			/* Volume number (one for each disk) */
XFILE *dumpfile;			/* Stream ptr for dump file */
Xchar header[80];		/* Header of dump file */
Xint nfiles[1];			/* Number of dumped files */
/
echo x - dumper
sed '/^X/s///' > dumper << '/'
X#!/bin/sh
X#
X# This short shell script is designed to do incremental backups of certain
X# directories, and would usually be run evry day or few days. It provides
X# a form of protection against accidental loss.
X#
X# Dumper gets pairs of `from' `to' strings from /usr/adm/dumpdirs, and
X# proceeds to do an incremental dump of the `from' directory to the `to'
X# file, with the date tacked on. Thus you end up with a lot of dumps if
X# you do not regularly remove old incrementals. Note that the `from'
X# directories should be relative to root, and not absolute - this is so
X# restore can bring them back anywhere.
X#
X# The first time you run this, dump will do full backups as you haven't
X# done backups before. You probably don't want this, so run dumper with
X# any argument. It will alter /usr/adm/dumpdates as if a full dump had
X# been done.
X# Alternatively, if you have enough floppy/harddisk/tape space, do a full
X# dump and run dumper later as normal :-)
X#
X#	Warren Toomey
X#
X# P.S Can anybody tell me why the "cd /" command doesn't work?
X
Xif $1
Xthen cd /
X     set `date`
X     DATE=$2$3
X     echo Dumper running on $DATE
X     set `cat /usr/adm/dumpdirs`
X     while true
X     do echo "/usr/local/bin/dump -9 -V -v0 -f" $2$DATE $1
X        /usr/local/bin/dump -9 -V -v0 -f $2$DATE $1
X        shift ; shift
X     done
Xelse cd /
X     echo Dumper pretending to full-dump
X     set `cat /usr/adm/dumpdirs`
X     while true
X     do echo "/usr/local/bin/dump -q" $1
X        /usr/local/bin/dump -q $1
X        shift ; shift
X     done
Xfi
/
echo x - dumpdirs
sed '/^X/s///' > dumpdirs << '/'
Xetc			/tmp/dump/etc
Xusr/local/src		/tmp/dump/locsrc
Xusr/minix/kernel	/tmp/dump/kern
Xusr/minix/fs		/tmp/dump/fs
Xusr/minix/mm		/tmp/dump/mm
Xusr/minix/lib		/tmp/dump/lib
Xusr/tools		/tmp/dump/tool
Xusr/test		/tmp/dump/test
Xusr/u1			/tmp/dump/u1
Xusr/root		/tmp/dump/root
/
