#include "header.h"

	/* Dump: Dump files to device or file. Does incrementals */
	/*	 and multi-volume dumps as well.		 */

	/* Written by Warren Toomey - 1989,1990		         */
	/* You may freely copy or give away this source as       */
	/* long as this notice remains intact.		         */


void usage()				/* Print out the usage line */
 {
  fprintf(stderr,"Usage: dump [-0123456789] [-V] [-q] [-f dumpfile] [-v vol] directory\n");
  exit(0);
 }


long getlast(level,device)		/* Get last dump date from file */
 int level;
 char *device;
 {
  FILE *dumpfile;
  long tim,lastdump[10];
  char dev[80],dummy1[6],dummy2[5],dummy3[3];
  int i,lev;

  if ((dumpfile=fopen(DUMPFILE,"r"))==NULL)
    return(0L);

  for (i=0;i<10;i++) lastdump[i]=0L;
  while (!feof(dumpfile))		/* Get a dump line from file */
   {
    fscanf(dumpfile,"%ld %s %d %s %s %s",&tim,dummy1,&lev,dummy2,dummy3,dev);
    while (((i=fgetc(dumpfile))!='\n') && (i!=EOF));

    if (!strcmp(device,dev))		/* If the same device */
      lastdump[lev]=tim;		/* save the time */
   }
  fclose(dumpfile);

  tim=0L;
  for (i=0;i<level+1;i++)		/* Now get the last dump of our level */
     if (lastdump[i]!=0) tim=lastdump[i];

  return(tim);				/* and return it */
 }
    

void savedate(level,device)		/* Save this dump's date to a file */
 int level;
 char *device;
 {
  FILE *dumpfile;
  extern long curtim;

  if ((dumpfile=fopen(DUMPFILE,"a"))==NULL)
    perror("savedate");

  time(&curtim);	/* Get the current time */
			/* and append line to dump file */

  fprintf(dumpfile,"%ld Level %d dump of %s on %s",curtim,level,device,
	  ctime(&curtim));
 }

  
int getinfo(file)		/* Get stat info about given file */
 char *file;
 {
  extern struct stat buff;

  if (stat(file,&buff)!=0) return(1);
  else return(0);
 }
 

void search(directory,lvl) /* Find every file in the given directory */
 char *directory;
 int lvl;
 {
  extern struct stat buff;
  extern long lastim;
  extern char *dirlist[];
  extern INODE inolist[];
  extern int aindex;
  DIR *dir;
#ifdef MINIX
  struct dirent *dinfo;
#else
  struct direct *dinfo;
#endif
  char name[80];

  strcat(directory,"/");
  if ((dir=opendir(directory))==NULL)
    {
     fprintf(stderr,"Couldn't open %s\n",directory);
     return;
    }

  readdir(dir);
  readdir(dir);		/* Skip . and .. */

  for (dinfo=readdir(dir);dinfo!=NULL;dinfo=readdir(dir))
     {
      strcpy(name,directory); 	/* Use full path name */
      strcat(name,dinfo->d_name);
      if (getinfo(name)) continue;	/* If bad, skip it */
      if ((lvl==0) || (buff.st_mtime>lastim))
        {			/* else dump it */
	 if ((dirlist[aindex]=(char *)malloc(strlen(name)+1))==0)
	   perror("search"); 
	 strcpy(dirlist[aindex],name); 
	 inolist[aindex].inode=buff.st_ino;
	 inolist[aindex].mode=buff.st_mode;
	 inolist[aindex].links=buff.st_nlink;
	 inolist[aindex].uid=buff.st_uid;
	 inolist[aindex].gid=buff.st_gid;
	 inolist[aindex].size=buff.st_size;
	 inolist[aindex].atime=buff.st_atime;
	 inolist[aindex].mtime=buff.st_mtime;
#ifndef MINIX
	 inolist[aindex].blocks=buff.st_blocks;
#endif
	 aindex++;
        }
      if ((buff.st_mode & S_IFMT)==S_IFDIR) search(name,lvl);
     }
  closedir(dir);
  }


void dumpit(dname,lvl,dev,vol,verb)	/* Dump everything to file */
 char *dname;
 int lvl;
 char *dev;
 int vol;
 int verb;
 {
  extern long curtim;
  extern int volnum;
  extern char buffer[];
#ifdef LOWIO
  int dfile, infile;
#else
  FILE *dfile, *infile;				/* Firstly dump date etc */
#endif
  int c,i,j,k;
  long posn,numblks;

  volnum=1;
#ifdef LOWIO
  if ((dfile=creat(dname,0700))==-1)
    perror("dumpit1");
#else
  if ((dfile=fopen(dname,"w"))==NULL)
    perror("dumpit2");
#endif

#ifdef LOWIO
  sprintf(buffer,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
	  ctime(&curtim));
  write(dfile,buffer,strlen(buffer));
  sprintf(buffer,"Volume %d ",volnum);
  write(dfile,buffer,strlen(buffer));
  sprintf(buffer,"Size %d K\n",vol);
  write(dfile,buffer,strlen(buffer));
  sprintf(buffer,"%d files\n",aindex);
  write(dfile,buffer,strlen(buffer));

  for (i=0;i<aindex;i++)		/* Now dump the file names */
   {					/* and the inode list */
    sprintf(buffer,"%s\n",dirlist[i]);
    write(dfile,buffer,strlen(buffer));
   }

  if ((i=write(dfile,inolist,sizeof(INODE)*aindex))!=sizeof(INODE)*aindex)	
     printf("dumpit3: write wrote only %d bytes\n",aindex);

  posn=lseek(dfile,0L,1);		/* Get current posn */
  numblks=posn/BLKSIZE +1L;
  posn=BLKSIZE * numblks;
  if ((lseek(dfile,posn,0))==-1)	/* and seek to next block */
    perror("dumpit4");

#else
  fprintf(dfile,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
	  ctime(&curtim));
  fprintf(dfile,"Volume %d Size %d K\n",volnum,vol);
  fprintf(dfile,"%d files\n",aindex);

  for (i=0;i<aindex;i++)		/* Now dump the file names */
   fprintf(dfile,"%s\n",dirlist[i]);	/* and the inode list */

  if ((i=fwrite(inolist,sizeof(INODE),aindex,dfile))!=aindex)	
     printf("dumpit5: fwrite wrote only %d of %d inodes\n",i,aindex);

  posn=ftell(dfile);			/* Get current posn */
  numblks=posn/BLKSIZE +1L;
  posn=BLKSIZE * numblks;
  if ((fseek(dfile,posn,0))==-1)	/* and seek to next block */
    perror("dumpit6");
#endif
					/* Finally dump the blocks */
  for (i=0;i<aindex;i++)		/* except dirs & null files */
   {
    if (verb) printf("%s\n",dirlist[i]);
#ifdef DEBUG
# ifdef MINIX
  printf("Inode:  %x\n",inolist[i].inode);
  printf("Mode:   %x		Links:   %x\n",inolist[i].mode,inolist[i].links);
  printf("Uid:    %x		Gid:     %x\n",inolist[i].uid,inolist[i].gid);
  printf("Size:   %lx\n",inolist[i].size);
  printf("Atime:  %lx\n",inolist[i].atime);
  printf("Mtime:  %lx\n",inolist[i].mtime);
# else
  printf("Inode:   %ld\n",inolist[i].inode);
  printf("Mode:   %o		Links:   %d\n",inolist[i].mode,inolist[i].links);
  printf("Uid:    %d		Gid:     %d\n",inolist[i].uid,inolist[i].gid);
  printf("Size:   %ld\n",inolist[i].size);
  printf("Atime:  %ld\n",inolist[i].atime);
  printf("Mtime:  %ld\n",inolist[i].mtime);
# endif
  printf("\n\n");
#endif
    if ((inolist[i].mode & S_IFMT)==S_IFDIR) continue;
    if (inolist[i].size==0) continue;
#ifdef LOWIO
    if ((infile=open(dirlist[i],O_RDONLY))==-1)
      perror("dumpit7");
#else
    if ((infile=fopen(dirlist[i],"r"))==NULL)
      perror("dumpit8");
#endif

    while(1)
       {
        for (k=0;k<BLKSIZE;k++) buffer[k]=' ';	/* May not be needed */
#ifdef LOWIO
	j=read(infile,buffer,sizeof(char)*BLKSIZE);
        write(dfile,buffer,sizeof(char)*BLKSIZE);
#else
	j=fread(buffer,sizeof(char),BLKSIZE,infile);
        fwrite(buffer,sizeof(char),BLKSIZE,dfile);
#endif
	if ((vol) && (++numblks==vol))		/* Swap disks */
          {
#ifdef LOWIO
	   close(dfile);
	   printf("Remove disk & insert disk %d\n",++volnum);
	   while ((c=getchar())!='\n');
  	   if ((dfile=creat(dname,0700))==-1)
    	     perror("dumpit9a");
	   if ((dfile=open(dname,O_WRONLY))==-1)
	     perror("dumpit9b");
  	   sprintf(buffer,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
	  		 ctime(&curtim));
	   write(dfile,buffer,strlen(buffer));
  	   sprintf(buffer,"Volume %d\n",volnum);
	   write(dfile,buffer,strlen(buffer));
  	   posn=lseek(dfile,0L,1);			/* Get current posn */
  	   numblks=posn/BLKSIZE +1L;
  	   posn=BLKSIZE * numblks;
  	   if ((lseek(dfile,posn,0))==-1)	/* and seek to next block */
	     perror("dumpitA");
#else
	   fclose(dfile);
	   printf("Remove disk & insert disk %d\n",++volnum);
	   while ((c=getchar())!='\n');
	   if ((dfile=fopen(dname,"w"))==NULL)
	     perror("dumpitB");
  	   fprintf(dfile,"%ld Level %d dump of %s on %s",curtim,lvl,dev,
	  		 ctime(&curtim));
  	   fprintf(dfile,"Volume %d\n",volnum);
  	   posn=ftell(dfile);			/* Get current posn */
  	   numblks=posn/BLKSIZE +1L;
  	   posn=BLKSIZE * numblks;
  	   if ((fseek(dfile,posn,0))==-1)	/* and seek to next block */
	     perror("dumpitC");
#endif
	  }
   /*   if (j<BLKSIZE) printf("dumpitD: fread short %d\n",j); */
        if (j<BLKSIZE) break;
       }

#ifdef LOWIO
    close(infile);
#else
    fclose(infile);
#endif
   }
    

#ifdef LOWIO
    close(dfile);
#else
    fclose(dfile);
#endif
 }



main(argc,argv)				/* Set up dir name & call search */
 int argc;
 char *argv[];
 {
  extern int optind;
  extern char *optarg;
  extern long lastim;			/* Last dump time */
  extern int aindex;
  extern int volnum;
  extern struct stat buff;
  extern char *dirlist[];
  extern INODE inolist[];
  int c,verbose;

  int vol,level;		/* Volume of dump device, and dump level */
  char dumpdev[80];		/* Dump device's name */
  char dumpfrom[80];		/* Dump from this directory */
  int quick;			/* To dump, or just lie */


  level=0; vol=DEFVOL;
  aindex=0; verbose=0;
  quick=0;
  strcpy(dumpdev,DEFDEVICE);	/* Set up default values */

  if (argc==1) usage();

  while ((c=getopt(argc,argv,"0123456789Vqf:v:"))!=EOF)
    switch(c)
     {
      case '0' : level=0;	/* Get the various options */
		 break;
      case '1' : level=1;
		 break;
      case '2' : level=2;
		 break;
      case '3' : level=3;
		 break;
      case '4' : level=4;
		 break;
      case '5' : level=5;
		 break;
      case '6' : level=6;
		 break;
      case '7' : level=7;
		 break;
      case '8' : level=8;
		 break;
      case '9' : level=9;
		 break;
      case 'V' : verbose=1;
		 break;
      case 'f' : strcpy(dumpdev,optarg);
		 break;
      case 'v' : vol=atoi(optarg);
		 break;
      case 'q' : quick=1;
		 break;
      default  : usage();
     }

  strcpy(dumpfrom,argv[argc-1]);	/* Finally get where to dump from */

					/* Quick mode - don't dump :-) */
  if (quick) { savedate(level,dumpfrom);
	       exit(0);
	     }

#ifdef DEBUG
  printf("Vol:   %d Device: %s\n",vol,dumpdev);
  printf("Level: %d Dump from: %s\n",level,dumpfrom);
#endif

  lastim=getlast(level,dumpfrom);
  printf("Last dump time of level %d for %s was %s",level,dumpfrom,
          ctime(&lastim));
  savedate(level,dumpfrom);
  printf("Searching directory tree...\n");

  if (getinfo(dumpfrom))
    perror("main");
  if ((dirlist[aindex]=(char *)malloc(strlen(dumpfrom)+1))==0)
    perror("search"); 
  strcpy(dirlist[aindex],dumpfrom); 
  inolist[aindex].inode=buff.st_ino;	/* Yes, all of this is  */
  inolist[aindex].mode=buff.st_mode;	/* kludgy and should be */
  inolist[aindex].links=buff.st_nlink;	/* done in search()     */
  inolist[aindex].uid=buff.st_uid;
  inolist[aindex].gid=buff.st_gid;
  inolist[aindex].size=buff.st_size;
  inolist[aindex].atime=buff.st_atime;
  inolist[aindex].mtime=buff.st_mtime;
#ifndef MINIX
  inolist[aindex].blocks=buff.st_blocks;
#endif
  aindex++;

  search(dumpfrom,level);		/* Now search for files to dump */
  if (aindex!=1)
    {
     printf("Dumping files...\n");		
     dumpit(dumpdev,level,dumpfrom,vol,verbose);	/* and dump them */
    }
  exit(0);
 }
