#define LOWIO		/* Uses open(), read() etc for dumping */
#include <stdio.h>
#include <sys/types.h>
#include <sys/dir.h>
#include <sys/stat.h>
#ifdef MINIX
# include <dirent.h>
#endif
#ifdef LOWIO
# include <fcntl.h>
#endif

#ifndef BLKSIZE
# define BLKSIZE 1024
#endif

#ifdef MINIX
# define DEFDEVICE "/dev/fd0"		/* Default values */
# define DUMPFILE "/usr/adm/dumpdates"
#else
# define DEFDEVICE "/usr/tmp/fd0"
# define DUMPFILE "/usr/tmp/dumpdates"
#endif

#define DEFVOL 360
#define ARYSIZE 1000			/* Arrays size */
#define lastchar(x) x[strlen(x)-1]
#define getarg(x) fgetarg(stdin,x)

#ifdef MINIX
typedef struct i_dumm { unsigned short inode;
			unsigned short mode;
			short int links;
			short int uid;
			short int gid;
			long size;
			long atime;
			long mtime;
		      } INODE;		/* My i-node structure */
#else
typedef struct i_dumm { int inode;
			int mode;
			int links;
			int uid;
			int gid;
			long size;
			long atime;
			long mtime;
			long blocks;
		      } INODE;		/* My i-node structure */
#endif

typedef enum { DIFF, OVWRITE, TABLE } RESMODE;	/* Restore modes */
