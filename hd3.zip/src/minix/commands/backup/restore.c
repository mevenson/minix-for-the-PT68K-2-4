#include <stdio.h>
#include <ctype.h>
#ifdef MINIX
#include <string.h>
#else
#include <strings.h>
#endif
#include "header.h"

	/* Restore: Restore files from a dump made by dump(8) */

	/* Written by Warren Toomey - 1989		      */
	/* You may freely copy or give away this source as    */
	/* long as this notice remains intact.		      */


char fgetarg(stream,cbuf)		/* Get next arg from file into cbuf, */
 FILE *stream;				/* returning the character that      */
 char *cbuf;				/* terminated it. Cbuf returns NULL  */
 {					/* if no arg. EOF is returned if no  */
  char ch;				/* args left in file.                */
  int i;

  i=0; cbuf[i]=NULL;

  while (((ch=fgetc(stream))==' ') || (ch=='\t') || (ch=='\n'))
    if (ch=='\n') return(ch);				/* Bypass leading */
							/* whitespace     */
  if (feof(stream)) return(EOF);
  
  cbuf[i++]=ch;

  while (((ch=fgetc(stream))!=' ') && (ch!='\t') && (ch!='\n'))
    cbuf[i++]=ch;					/* Get the argument */

  cbuf[i]=NULL;
  return(ch);
 }



#ifdef MINIX
int mkdir(path,mode)		/* Make directory */
 char *path;
 int mode;
 {
  char cmd[80];
  int i;

  sprintf(cmd,"/usr/bin/mkdir %s",path);
  i=system(cmd);
  if (i==0) return(chmod(path,mode));
  else return(-1);
 }


int rmdir(path)			/* Delete directory */
 char *path;
 {
  char cmd[80];
  int i;

  sprintf(cmd,"/usr/bin/rmdir %s",path);
  i=system(cmd);
  return(i);
 }
#endif


ls(i,j)				/* List file i; long if j==1 */
 int i,j;
 {
  extern char *dirlist[];	/* Some of the code stolen from */
  extern INODE inolist[];	/* Andy Tanenbaum's ls program  */
  extern char resflag[];
  extern char *strrchr();

  static char *rwx[] =	{"---", "--x", "-w-", "-wx", "r--", "r-x", "rw-", "rwx",
		 	"--s", "--s", "-ws", "-ws", "r-s", "r-s", "rws", "rws"};
  int m,prot;
  char *p1, *p2, *p3, c;
  char ch,tstrng[26];

  if (resflag[i]==1) ch='*'; else ch=' ';
  if (j)
    {
        switch (inolist[i].mode & S_IFMT)	/* Set directory, char    */
	  {					/* special, block special */
	   case S_IFDIR : c='d';		/* or none of the above   */
			  break;
	   case S_IFBLK : c='b';
			  break;
	   case S_IFCHR : c='c';
			  break;
	   default      : c='-';
	  }

	m = inolist[i].mode & 07777;
	prot = (m >> 6) & 07;		/* Get the user protection */
	if (m & S_ISUID) prot += 8;
	p1 = rwx[prot];

	prot = (m >> 3) & 07;
	if (m & S_ISGID) prot += 8;	/* Get the group protection */
	p2 = rwx[prot];

	prot = m & 07;			/* & the other protection */
	p3 = rwx[prot];

	printf("%c %c%s%s%s %2d ",ch,c, p1, p2, p3, inolist[i].links);

	/* Print owner & group as decimal numbers, as the restore */
	/* may be very out of date				  */

        printf("%6d %6d ",inolist[i].uid,inolist[i].gid);

       strcpy(tstrng,ctime(&inolist[i].mtime)); tstrng[24]=0;
       printf("%8ld %s ",inolist[i].size,&tstrng[4]);
       if ((p1=strrchr(dirlist[i],'/'))==NULL)
	 printf("%s\n",dirlist[i]);
       else printf("%s\n",p1+1);	/* Finally the size, date & */
    }					/* filename */
  else
    printf("%c  %s\n",ch,dirlist[i]);
 }



char *cd(pre,post)		/* Add post to pre & form full */
 char *pre, *post;		/* path name */
 {
  extern char *strchr();
  extern size_t strcspn();
  char full[100],temp[100];
  char *p1, *p2;
  int i;

  p1=post;
  strcpy(full,pre);			/* Get first part of pathname */
  while ((i=strcspn(p1,"/"))!=0)
   {
    strncpy(temp,p1,i);			/* Get next part of pathname */
    temp[i++]=NULL;

    if (strcmp(temp,"."))		/* Ignore . */
     if (!strcmp(temp,".."))		/* Reduce full */
      {
	if ((p2=strrchr(full,'/'))!=NULL)
	   *p2=NULL;
	else return(NULL);		/* Err if can't reduce */
      }
     else
      { strcat(full,"/");
        strcat(full,temp);		/* Else just add on */
      }

    if (i>strlen(p1)) break;		/* If last bit, break out */
    p1+=i;				/* else move pointer up */
   }
  return(full);
 }
  



int strnum(s1,ch)		/* Get no. of ch's in s1 */
 char *s1;
 char ch;
 {
  int i,cnt=0;

  for (i=0;s1[i]!=0;i++)
    cnt += (s1[i]==ch) ? 1 : 0;
  return(cnt);
 }
  

int getinfo(file)		/* Get stat info about given file */
 char *file;
 {
  extern struct stat buff;

  if (stat(file,&buff)!=0)
    return(0);
  else return(1);
 }
 

FILE *gethdr(device,mode,vol)		 /* Get the list of files & inodes */
 char *device;				 /* If mode == 0, just get header  */
 int mode, *vol;
 {
  extern char *dirlist[];
  extern INODE inolist[];
  extern int volnum;
  extern int nfiles[];
  extern char header[];

  FILE *fd;
  int c,i,thisvol;
  char dummy[80];

  i=0;
  if ((fd=fopen(device,"r"))==NULL)
    perror("gethdr");		/* Open the dump file */

  while ((c=fgetc(fd))!='\n') header[i++]=c;	/* Get first line */
  header[i]=NULL;

  fscanf(fd,"%s %d",dummy,&thisvol);

  if (thisvol!=volnum)
   { fprintf(stderr,"Wrong volume! %d instead of %d\n",thisvol,volnum);
     fclose(fd);
     return(NULL);
   }

  if (mode!=0) fscanf(fd, "%s %d", dummy, vol);	/* Get disk size */

  while ((c=fgetc(fd))!='\n');			/* Get rest of line */

  if (mode==0) return(fd);		/* Only get file names once */
  fscanf(fd,"%d %s\n",&i,dummy);
  nfiles[0]=i;

  for (i=0;i<*nfiles;i++)
   {
    fscanf(fd,"%s\n",dummy);		/* Read in the file names */
    dirlist[i]=(char *)malloc(strlen(dummy)+1);
    strcpy(dirlist[i],dummy);
   }
#ifdef MINIX			/* For some reason, Minix doesn't get */
  c=fgetc(fd);			/* the last \n ; this caused several  */
#endif				/* hours of frustration. Aaaarrggh!   */

  fread(inolist,sizeof(INODE),*nfiles,fd);	/* And get the inodes */
  return(fd);
 }


printtable(verb)		/* Print out a table of dumped files */
 int verb;
 {
  extern FILE *dumpfile;
  extern int nfiles[];
  int i;

  fclose(dumpfile);			/* Close the file */

  for (i=0;i<*nfiles;i++)
   {
    printf("%s\n",dirlist[i]);		/* and print filenames */ 
    if (verb)
      {
#ifdef MINIX
       printf("\tInode:  %d\t\tSize:    %ld\n",inolist[i].inode,inolist[i].size);
       printf("\tMode:   %o\t\tLinks:   %d\n",inolist[i].mode,inolist[i].links);
       printf("\tUid:    %d\t\tGid:     %d\n",inolist[i].uid,inolist[i].gid);
       printf("\tAtime:  %ld\tMtime:   %ld\n\n",inolist[i].atime,inolist[i].mtime);
#else
       printf("\tInode:  %ld\t\tSize:    %ld\n",inolist[i].inode,inolist[i].size);
       printf("\tMode:   %o\t\tLinks:   %d\n",inolist[i].mode,inolist[i].links);
       printf("\tUid:    %d\t\tGid:     %d\n",inolist[i].uid,inolist[i].gid);
       printf("\tAtime:  %ld\tMtime:   %ld\n\n",inolist[i].atime,inolist[i].mtime);
#endif
      }
   }
 }



int getresfils()			/* Get list of files to restore */
 {					/* Interactively */
  extern char resflag[];
  static char *cmd[10] = { "add","cd","del","get","help",
			  "ls","pwd","quit","show","?" };
  char cmdline[100];
  char origcwd[100],cwd[100];
  char ch;
  int cwdslash,ourslash;
  int i,j,quit;				/* Quit = 0 to loop */
					/*	= 1 to exit */
					/*	= 2 to get  */

  quit=0; j=0;
  printf("%s\n\n",header);		/* Print the header out */
  for (i=0;i<*nfiles;i++) resflag[i]=0;	/* No files selected yet */
  for (i=26;header[i]!=' ';cwd[j++]=header[i++]);	/* Get cwd */
  cwd[j]=NULL;
  if (lastchar(cwd)=='/') lastchar(cwd)=NULL;
  strcpy(origcwd,cwd);			/* & make it the original */
  while (quit==0)
   {
    if (lastchar(cwd)=='/') lastchar(cwd)=NULL;
    cwdslash=strnum(cwd,'/')+1;		/* Count # of slashes in cwd */
    printf("Restore> ");
    ch=getarg(cmdline);			/* Get the command */
    for (i=0;i<9;i++)
     if (!strncmp(cmd[i],cmdline,strlen(cmdline)))
       break;
    switch(i)
     {
      case 0  : if (ch=='\n')			/* Add */
		  strcpy(cmdline,cwd);
		else				/* Get file/directory */
		  { ch=getarg(cmdline);
		    if (cmdline[0]=='/')
		      strcpy(cmdline,cd(origcwd,&cmdline[1]));
		    else
		      strcpy(cmdline,cd(cwd,cmdline));
		    if (cmdline[0]==NULL)
		     {
		      printf("Bad directory name\n");
		      break;
		     }
		  }

    		ourslash=strnum(cmdline,'/');	/* Count # of slashes */
	        for (i=0;i<*nfiles;i++)
		  if ((strnum(dirlist[i],'/')>=ourslash))
		    if (!strncmp(cmdline,dirlist[i],strlen(cmdline)))
		       resflag[i]=1;

		for (;ch!='\n';ch=getarg(cmdline));
		break;
      case 1  : if (ch=='\n')			/* Cd */
		 {
		  strcpy(cwd,origcwd);		/* If no arg, set to */
		  break;			/* origcwd */
		 }
		ch=getarg(cmdline);		/* Get arg */
		if (!strcmp(cmdline,"/"))
		 {
		  strcpy(cwd,origcwd);		/* If /, set to */
		  break;			/* origcwd */
		 }
		if (cmdline[0]=='/')
		  strcpy(cmdline,cd(origcwd,&cmdline[1]));	/* Now get */
		else
		  strcpy(cmdline,cd(cwd,cmdline));	/* full pathname */
		if (cmdline[0]==NULL)
		  printf("Bad directory name\n");
		else strcpy(cwd,cmdline);
		for (;ch!='\n';ch=getarg(cmdline));
		break;
      case 2  : if (ch=='\n')			/* Del */
		  strcpy(cmdline,cwd);
		else				/* Get file/directory */
		  { ch=getarg(cmdline);
		    if (cmdline[0]=='/')
		      strcpy(cmdline,cd(origcwd,&cmdline[1]));
		    else
		      strcpy(cmdline,cd(cwd,cmdline));
		    if (cmdline[0]==NULL)
		     {
		      printf("Bad directory name\n");
		      break;
		     }
		  }

    		ourslash=strnum(cmdline,'/');	/* Count # of slashes */
	        for (i=0;i<*nfiles;i++)
		  if ((strnum(dirlist[i],'/')==ourslash) ||
		      (strnum(dirlist[i],'/')==ourslash+1))
		    if (!strncmp(cmdline,dirlist[i],strlen(cmdline)))
		       resflag[i]=0;

		for (;ch!='\n';ch=getarg(cmdline));
		break;
      case 3  : if (ch!='\n') { printf("get takes no args!\n");
				for (;ch!='\n';ch=getarg(cmdline));
				break;
			      }
		j=0;
		for (i=0;i<*nfiles;i++)
		 j+= resflag[i];
		if (j!=0) quit=2;		/* Get */
 		else printf("No files to get!\n");
		for (;ch!='\n';ch=getarg(cmdline));
		break;
      case 5  : j=0;				/* Ls */
		printf("%s:\n",cwd);
		if (ch==' ')
		  { ch=getarg(cmdline);
		    if (!strcmp(cmdline,"-l")) j=1;
		  }
	        for (i=0;i<*nfiles;i++)
		   if ((strnum(dirlist[i],'/')==cwdslash))
		     if (!strncmp(cwd,dirlist[i],strlen(cwd)))
		       ls(i,j);
		for (;ch!='\n';ch=getarg(cmdline));
		break;
      case 6  : printf("%s\n",cwd);		/* Pwd */
		break;
      case 7  : quit=1;				/* Quit */
		break;
      case 8  : for (i=0;i<*nfiles;i++)		/* Show */
		  if (resflag[i])
		   printf("%s\n",dirlist[i]);
		break;
      case 4  :
      case 9  :					/* Help */
      default : printf("\nCommands are:\n");
		printf("\tadd  - Add a file/directory to restore list\n");
		printf("\tcd   - Change to another directory\n");
		printf("\tdel  - Delete a file/dir from the restore list\n");
		printf("\tget  - Restore the list of files\n");
		printf("\thelp - Display this message\n");
		printf("\tls   - List the current directory\n");
		printf("\tpwd  - Print the working directory\n");
		printf("\tquit - Quit from restore\n");
		printf("\tshow - Show the file that will be restored\n");
		printf("\t?    - Display this message\n\n");
		for (;ch!='\n';ch=getarg(cmdline));
		break;
     }
   }
  return(quit);
 }


restore(dev,vol,mode,verb)			/* Restore the dumped files */
 char *dev;
 int vol;
 RESMODE mode;
 int verb;
 {
  extern char *dirlist[];
  extern INODE inolist[];
  extern int volnum;
  extern char buffer[];

  extern FILE *dumpfile;
  extern char header[];
  FILE *newfile;
  int c,exists,i,j,notdone,ouruid;
  long numblocks,posn,size;
  time_t timep[2];

  umask(000);			/* Allow us to create any files */
  ouruid=getuid();		/* Get our uid */

  printf("%s\n",header);		/* Print the header */
  printf("Restoring files...\n");

  posn=ftell(dumpfile);		/* Move to start of dumped files */
  numblocks= posn/BLKSIZE + 1L;
  posn=BLKSIZE * numblocks;
  if ((fseek(dumpfile,posn,0))==-1)
    perror("restore");
  
  for (i=0;i<*nfiles;i++)	/* Print filename if verbose, and */
   {				/* don't restore if not root & wrong uid */

    if ((inolist[i].mode & S_IFMT)==S_IFDIR)	/* If a directory */
     {						/* set dummy mode */
      mkdir(dirlist[i],0700);			/* and fix later  */
#ifdef DEBUG
      printf("    is a directory\n");
#endif
      continue;					/* Always restore dirs */
     }

#ifdef DEBUG
    printf("%s %d\n",dirlist[i],resflag[i]);
#endif
    exists=getinfo(dirlist[i]);			/* Get info on file */

						/* Here are the many */
						/* conditions that a */
						/* file should be skipped */
    if (  (resflag[i]==0) ||
          ((ouruid!=0) && (inolist[i].uid!=ouruid)) ||
          ((exists) && (mode==DIFF) && (buff.st_mtime>=inolist[i].mtime))  )
      {
	numblocks += inolist[i].size/BLKSIZE +1L;	/* Add on size */
	if ((vol==0) || (numblocks<vol))
	 {
	  posn=numblocks*BLKSIZE;
	  if ((fseek(dumpfile,posn,0))==-1)
	    perror("restore");
	 }
      continue;						/* Skip to next file */
     }

    if (verb) printf("%s\n",dirlist[i]);
    if (exists) chmod(dirlist[i],0700);
    newfile=fopen(dirlist[i],"w");		/* else restore it ! */
    size=0;
    notdone=1;
    if (inolist[i].size!=0)
      while(notdone)
       {
	if ((vol!=0) && (numblocks>=vol))
	  {
	   fclose(dumpfile);
	   j= numblocks/vol;			/* Calc next volume */
	   volnum +=j;
	   do {
	       printf("Remove disk and insert disk %d\n",volnum);
	       while((c=getchar())!='\n');
	       dumpfile=gethdr(dev,0,&vol);		/* Reopen device */
	      } while (dumpfile==NULL);
	   numblocks=numblocks%vol + j;			/* Add enough to */
	   posn=numblocks*BLKSIZE;			/* bypass header */
	   if ((fseek(dumpfile,posn,0))==-1)
	     perror("restore");
	  }

        j=fread(buffer,sizeof(char),BLKSIZE,dumpfile);

        if (j<BLKSIZE) 
         { printf("fread ran short on %s\n",dirlist[i]);
           exit(1);
         }

	numblocks++;
        size+= BLKSIZE;

        if (size<=inolist[i].size)
          fwrite(buffer,sizeof(char),BLKSIZE,newfile);
        else
	 {
	  size=inolist[i].size-size+BLKSIZE;
#ifdef MINIX
					/* It appears that there is a large */
					/* bug in Minix fwrite, because the */
					/* line after the #else refuses to  */
					/* work.			    */
	  for (j=0;j<size;j++) fputc(buffer[j],newfile);
#else
          fwrite(buffer,sizeof(char),size,newfile);
#endif
	  notdone=0;
   	 }				/* Close the file & set */ 
       }				/* up it's attributes */
      fclose(newfile);		
      chmod(dirlist[i],inolist[i].mode);
      timep[0]=inolist[i].atime;
      timep[1]=inolist[i].mtime;
      utime(dirlist[i],timep);
      chown(dirlist[i],inolist[i].uid,inolist[i].gid);
   }
  fclose(dumpfile);

  for (i= *nfiles;i> -1;i--)
    if ((inolist[i].mode & S_IFMT)==S_IFDIR)	/* Now reset the */
     if (resflag[i]==0)
       rmdir(dirlist[i]);			/* directory values, */
     else					/* deleting unwanted */
      {						/* directories */
       chmod(dirlist[i],inolist[i].mode);
       timep[0]=inolist[i].atime;
       timep[1]=inolist[i].mtime;
       utime(dirlist[i],timep);
       chown(dirlist[i],inolist[i].uid,inolist[i].gid);
      }
 }


usage()
 {
  fprintf(stderr,"Usage: restore [-Vodit] [-f dumpfile]\n");
  exit(0);
 }


main(argc,argv)
 int argc;
 char *argv[];
 {
  extern int optind;
  extern char *optarg;
  extern FILE *dumpfile;	/* Dump file stream pointer */
  extern int nfiles[];
  extern char header[];
  extern char resflag[];	/* `Restore yes?' flag for each file */
  int c,verbose,interact;

  int vol;			/* Volume of dump device */
  char dumpdev[80];		/* Dump device's name */
  RESMODE mode;			/* Mode of the restore */
  int i;


  strcpy(dumpdev,DEFDEVICE);	/* Set up default values */
  mode=OVWRITE;
  verbose=0;
  interact=0;
  volnum=1;
  i=0;
  vol=360;

  while ((c=getopt(argc,argv,"Voditf:v:"))!=EOF)
    switch(c)
     {
      case 'V' : verbose=1;	/* Get the various options */
		 break;
      case 'o' : mode=OVWRITE;
		 break;
      case 'd' : mode=DIFF;
		 break;
      case 't' : mode=TABLE;
		 break;
      case 'i' : interact=1;
		 break;
      case 'f' : strcpy(dumpdev,optarg);
		 break;
      default  : usage();
     }


#ifdef DEBUG
  printf("Vol:   %d Device: %s\n",vol,dumpdev);
#endif
						/* Get the list of files */
  dumpfile=gethdr(dumpdev,1,&vol);

  for (i=0;i<*nfiles;i++) resflag[i]=1;		/* Assume we want all files */

  if (interact)
   if (getresfils()==1)	exit(0);		/* Interactively get files */
						/* to restore		   */

  switch(mode)
   {
    case TABLE :   printtable(verbose);		/* Give a table of files */
		   break;
    case OVWRITE :				/* Restore all files */
    case DIFF :    restore(dumpdev,vol,mode,verbose);
		   break;
   }
 }
