#include "header.h"
struct stat buff;		/* Stat buffer */
long lastim;			/* Time of last dump */
long curtim;			/* Current time */
char *dirlist[ARYSIZE];		/* List of files to dump */
INODE inolist[ARYSIZE];		/* List of inodes to dump */
char resflag[ARYSIZE];		/* Restore flag for each file */
int aindex;			/* Index into above arrays */
char buffer[BLKSIZE];		/* A one-block buffer */
int volnum;			/* Volume number (one for each disk) */
FILE *dumpfile;			/* Stream ptr for dump file */
char header[80];		/* Header of dump file */
int nfiles[1];			/* Number of dumped files */
