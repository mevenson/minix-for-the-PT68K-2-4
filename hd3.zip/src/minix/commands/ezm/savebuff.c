save_buf()
{
    char *i, answer[20];
    int *fd;

    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Save capture buffer? ", answer, 20);
    close_window();
    if ((toupper(answer[0]) == 'N') || (answer[0] == '\0'))
        return;
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter filename: ",filename, 32);
    close_window();
    if (filename[0] == '\0')
        return;

    /* try to open the save file */

    if ((fd = fopen(filename,"w")) == ERROR)
    {
        fprintf(stderr, "Can't open %s for write\n\7",filename);
        return;
    }
    i = buf_base;
    while (i < buf_ptr)
        fwrite(i++, 1, 1, fd);
    buf_ptr = buf_base;
    fclose(fd);
}

