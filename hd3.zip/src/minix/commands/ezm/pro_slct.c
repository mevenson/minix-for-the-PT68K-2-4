pro_select()
{
    char c;

    open_window(PROTOCOL - 1, SCROFFSET - 1, 20, 14);
    gotorc(PROTOCOL, SCROFFSET);
    fprintf(stderr, "1)   XMODEM");
    gotorc(PROTOCOL+1, SCROFFSET);
    fprintf(stderr, "2)   YMODEM");
    gotorc(PROTOCOL+2, SCROFFSET);
    fprintf(stderr, "3)   YMODEM Batch");
    gotorc(PROTOCOL+3, SCROFFSET);
    fprintf(stderr, "4)   Kermit");
    gotorc(PROTOCOL+4, SCROFFSET);
    fprintf(stderr, "5)   Telink");
    gotorc(PROTOCOL+5, SCROFFSET);
    fprintf(stderr, "6)   MODEM7");
    gotorc(PROTOCOL+6, SCROFFSET);
    fprintf(stderr, "7)   ASCII");
    gotorc(PROTOCOL+7, SCROFFSET);
    fprintf(stderr, "8)   COMPUSERVE B");
    gotorc(PROTOCOL+8, SCROFFSET);
    fprintf(stderr, "9)   WXMODEM");
    gotorc(PROTOCOL+9, SCROFFSET);
    fprintf(stderr, "ESC  Cancel");
    gotorc(PROTOCOL+11, SCROFFSET);
    fprintf(stderr, "Protocol: ");
    c = rawget();
    close_window();
    switch (c)
    {
        case '1':
            protocol = XMODEM;
            proto_string = x_protocol;
            break;
        case '2':
            protocol = YMODEM;
            proto_string = y_protocol;
            recv_size = 1024;
            recv_mode = CRC; 
            break;
        case '3':
            protocol = YMODEMBATCH;
            proto_string = ybatch_protocol;
            recv_size = 1024;
            recv_mode = CRC;
            break;
        case '8':
            protocol = COMPUSERVE;
            proto_string = cis_b_protocol;
            break;
        case '4':
        case '5':
        case '6':
        case '7':
        case '9':
            gotorc(PROTOCOL+11, SCROFFSET);
            fprintf(stderr, "\7\7Not yet implemented");
            getanykey();
            break;
        default:
            return(0);
            break;
    }
    return(1);
}

