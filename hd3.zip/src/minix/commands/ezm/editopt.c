#include <stdio.h>
#include "ezm.h"

int edit_options()
{
    char string[32];
    int dflt_changed;

    open_window(0, 8, 60, 16);
    gotorc(2,23);
    fprintf(stderr, "O P T I O N S   S E L E C T I O N");
    gotorc(6, 10);
    fprintf(stderr, "1. Modem Dial String:   %s", mod_dial_str);
    gotorc(7, 10);
    fprintf(stderr, "2. Dial Command Suffix: %s", dial_cmd_suff);
    gotorc(8, 10);
    fprintf(stderr, "3. Connect String:      %s", connect_str);
    gotorc(9, 10);
    fprintf(stderr, "4. Connect Wait Time:   %s", connect_wait);
    gotorc(10, 10);
    fprintf(stderr, "5. Redial Pause Time:   %s", redial_pause);
    gotorc(11, 10);
    fprintf(stderr, "6. Device Name:         %s", device_name);
    gotorc(12, 10);
    fprintf(stderr, "7. Printer Device:      %s", printer);
    dflt_changed = 0;
    while(1)
    {
        gotorc(14, 10);
        fprintf(stderr, "Enter option number to change (ESC to exit): ");
        if (getstr(string, 1) <= 0)
        {
            if (dflt_changed)
                save_dflt();
            return(0);
        }
        switch (string[0])
        {
        case '1':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter modem dial string: ");
            if (getstr(string, 20) <= 0)
                break;
            strcpy(mod_dial_str, string);
            dflt_changed = 1;
            clr_line(6, 10, 57);
            fprintf(stderr, "1. Modem Dial String:   %s", mod_dial_str);
            break;
        case '2':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter dial command suffix: ");
            if (getstr(string, 14) <= 0)
                break;
            strcpy(dial_cmd_suff, string);
            dflt_changed = 1;
            clr_line(7, 10, 57);
            fprintf(stderr, "2. Dial Command Suffix: %s", dial_cmd_suff);
            break;
        case '3':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter connect string: ");
            if (getstr(string, 31) <= 0)
                break;
            strcpy(connect_str, string);
            dflt_changed = 1;
            clr_line(8, 10, 57);
            fprintf(stderr, "3. Connect String:      %s", connect_str);
            break;
        case '4':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter connect wait time: ");
            if (getstr(string, 9) <= 0)
                break;
            strcpy(connect_wait, string);
            dflt_changed = 1;
            clr_line(9, 10, 57);
            fprintf(stderr, "4. Connect Wait Time:   %s", connect_wait);
            break;
        case '5':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter redial pause: ");
            if (getstr(string, 9) <= 0)
                break;
            strcpy(redial_pause, string);
            dflt_changed = 1;
            clr_line(10, 10, 57);
            fprintf(stderr, "5. Redial Pause Time:   %s", redial_pause);
            break;
        case '6':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter modem device name: ");
            if (getstr(string, 4) <= 0)
                break;
            strcpy(device_name, string);
            dflt_changed = 1;
            clr_line(11, 10, 57);
            fprintf(stderr, "6. Device Name:         %s", device_name);
            break;
        case '7':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter printer device number: ");
            if (getstr(string, 1) <= 0)
                break;
            strcpy(printer, string);
            print_dev = atoi(string);
            dflt_changed = 1;
            clr_line(12, 10, 57);
            fprintf(stderr, "7. Printer Device:      %s", printer);
            break;
        case 0x1b:
            if (dflt_changed)
                save_dflt();
            return(0);
            break;
        default:
            break;
        }
    }
}

