speed_select()
{
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter speed factor: ", ascii_sa, 20);
    close_window();
    if (ascii_sa[0] == '\0')
        return();
    speed_adj = atoi(ascii_sa);
}

