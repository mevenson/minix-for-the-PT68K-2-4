/*
 * prepare sector to send header for YMODEMBATCH
 */

sendhdr()
{
    int i;

    for (i = 0; i < 128; i++)
        hdr_block[i] = 0;
    strcpy(hdr_block, filename);
    sendfile(1);
}

