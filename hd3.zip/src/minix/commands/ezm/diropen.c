#include <stdio.h>
#include "ezm.h"

/*
*** Open Disk Directory
*/

unsigned char diropen(mask)
unsigned char *mask;
{
    static  D_drive;
    char    drv[3];

    drv[0] = 0;
    drv[1] = 0;
    drv[2] = 0;

    D_drive = fndwrkdv();
    if (strlen(mask) == 1 && isdigit(*mask))
        strcat(mask, ".*");
    if ((mask[1] == '.') && isdigit(*mask))
    {
        D_drive = *mask - '0';
        strcpy(mask, mask + 2);
    }
    if (D_drive < 0 || D_drive > 9)
        return(0);
    sprintf(drv,"%ld",D_drive);
    if ((dir_fd = open(drv,7)) == -1)
        return(0);
    return(D_drive + '0');
}

