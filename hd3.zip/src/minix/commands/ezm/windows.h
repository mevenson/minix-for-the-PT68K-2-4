/*
    windows.h
    
        .h file for windows driver for herc board
    
*/

#define NORMAL         0x00000007
#define BLINK          0x00000080
#define HIGH_INTENSITY 0x00000008
#define UNDERLINE      0x00000001
#define REVERSE_VIDEO  0x00000070

int window_level = 0;
int window_array[32];

