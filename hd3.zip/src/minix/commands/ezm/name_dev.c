name_device()
{
    char temp[32];
    int i;

    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter device name: ", temp, 32);
    close_window();
    if (temp[0] == '\0')
        return();
    str_upper(temp);
    temp[4] = '\0';

    for (i = 0; i < 8; i++)
    {
        if (strncmp(temp, uvtable->device[i].devnam, 4) == 0)
        {
            modem_dev = i;
            break;
        }
    }
    if (i != 8)
    {
        strcpy(device_name, temp);
        dvr_init(modem_dev);
    }
    else
    {
        open_window(GFN - 1, 9, 50, 3);
        gotorc(GFN, 10);
        fprintf(stderr, "Device not found - nothing changed");
        getanykey();
        close_window();
    }
}

