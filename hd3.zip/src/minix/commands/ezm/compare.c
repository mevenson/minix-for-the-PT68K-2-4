/*
*    compare a string against a mask
*
*    returns 1 if successfull
*            0 if fails
*
*    Mask can contain any of the following elements:
*
*    c          literal character
*    ?          any character match except endstring null
*    [..]       character class (all of these characters)
*    [^..]      negated character class (all but these characters)
*    ^c         negated character (all but this character)
*    *          zone (match zero or more occurences)
*
*    A character class consists of zero or more of the following
*    surrounded by [ and ]:
*
*    c1-c2      range of ASCII characters
*    c1-c2..c1-c3 multiple ranges
*
*
*/

mask_compare(string, m)
unsigned char *string, *m;
{
    int    k;
    unsigned char *sp, *sav, string2[128];

    strcpy(sp = string2, string);
    for (k = 0; k < 11; k++)
        if(string2[k] == ' ')
            string2[k] = '\0';
    str_upper(m);
    while (*m) 
    {
        if (*m == '*') 
        {
            sav = sp;
            if (!*++m)
                return(1);
            while (*sp && !mask_compare(sp, m))
                ++sp;
            if (*sp)
                continue;
            sp = sav;
        }
        else if (!(k = onecmp(*sp, m)))
            return(0);
        else
            m += k;
        if (*sp)
            ++sp;
    }
    return(!*sp);
}

/*
*** Compare Only One Character (for mask_compare)
*/

onecmp(s, m)
unsigned char s, *m;
{
    unsigned char    c, setfind, setflag;
    unsigned char    *mp;

    if ((c = *(mp = m)) == '?' && s)      /* okay as is */
        ;
    else if (c == '[') 
    {
        setfind = setflag = 0;
        if (*++mp == '^') 
        {
            setflag = 1;
            ++mp;
        }
        for (; (c = *mp) && c != ']'; ++mp)
            if (*mp=='-' && s>=*(mp - 1) && s<=*(mp+1) && *(mp-1)<=*(mp+1)) 
            {
                while ((c = *(mp + 1)) && c != ']')  /* skip to trailing ']'*/
                    ++mp;
                setfind = 1;
            }
        if (setfind == setflag)
            return(0);
        else
            return(mp - m + 1);
    }
    else if (c == '^' && *(mp + 1) != s)
        return(2);
    else if (c != s)
        return(0);
    return(1);
}
