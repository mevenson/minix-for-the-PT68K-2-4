left_copystr(s1, s2, len)
char *s1, *s2;
int len;
{
    while ((*s1++ = *s2++) && --len);
    if (len)
    {
        --s1;
        while (len)
        {
            *s1++ = 0x20;
            len--;
        }
        *s1 = 0x00;
    }
}

right_copystr(s1, s2, len)
char *s1, *s2;
int len;
{
    int diff;

    diff = len > strlen(s2) ? len - strlen(s2) : 0;
    if (diff)
    {
        while (diff)
        {
            *s1++ = ' ';
            diff--;
        }
        while(*s1++ = *s2++);
    }
    else
        left_copystr(s1, s2, len);
}

