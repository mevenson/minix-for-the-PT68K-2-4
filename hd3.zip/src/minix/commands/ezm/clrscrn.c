#include <stdio.h>

clrscrn()
{
    putc(27, stderr);
    putc('*', stderr);
}

