/*
    windows.c
    
*/

#define NORMAL         0x00000007
#define BLINK          0x00000080
#define HIGH_INTENSITY 0x00000008
#define UNDERLINE      0x00000001
#define REVERSE_VIDEO  0x00000070

unsigned char *crtc_ctl = 0xfa0769;          /* 0xfa0000 + (2 * 0x3b4) + 1 */
unsigned char *crtc_dat = 0xfa076b;          /* 0xfa0000 + (2 * 0x3b5) + 1 */
unsigned int  *scr_base = 0xd60000;          /* 0xc00000 + (2 * 0xb0000) */

extern int window_level;
extern int window_array[];

#include <stdio.h>

unsigned char get_crtc_reg(reg_number)
int reg_number;
{
    *crtc_ctl = reg_number;
    return(*crtc_dat);
}

put_crtc_reg(reg_number,c)
int reg_number;
unsigned char c;
{
    *crtc_ctl = reg_number;
    *crtc_dat = c;
}

mk_scr_word(c, attrib)
unsigned char c;
{
    return(c << 16 | attrib);
}

wr_scrn(row, col, c, attrib)
int row, col;
unsigned char c;
int attrib;
{
    int *scr_ptr;

    scr_ptr = scr_base + get_crtc_reg(12) * 256 + get_crtc_reg(13);
    *(scr_ptr + row * 80 + col) = mk_scr_word(c, attrib);
}

clr_scrn()
{
    int i, j;

    for (i = 0; i < 25; i++)
        for (j = 0; j < 80; j++)
            wr_scrn(i, j, ' ', NORMAL);
}

rd_scrn(row, col)
int row, col;
{
    int *scr_ptr;

    scr_ptr = scr_base + get_crtc_reg(12) * 256 + get_crtc_reg(13);
    return(*(scr_ptr + row * 80 + col));
}

wr_str(row, col, str, attrib)
int row, col;
unsigned char *str;
int attrib;
{
    while (*str)
        wr_scrn(row, col++, *str++, attrib);
}

/*
 *  Open a window
 *
 *      reads the currents contents of the window into a dynamically
 *      allocated buffer. Updates the window array buffer by placing
 *      the address of this newly allocated buffer in the next slot.
 *      Then return the array number of the open window after clear-
 *      it to spaces.
 */

open_window(row, col, width, depth)
int row, col, width, depth;
{
    int *window_ptr, *line_ptr, *scr_ptr;
    int i, j;
    unsigned char *row_ptr, *col_ptr;

    row_ptr = 0xff0c80;
    col_ptr = 0xff0c81;

    scr_ptr = scr_base + get_crtc_reg(12) * 256 + get_crtc_reg(13);
    window_ptr = malloc((width * depth + (depth * 2) + 5) * 4);
    window_array[window_level] = window_ptr;
    *window_ptr++ = get_crtc_reg(14);
    *window_ptr++ = get_crtc_reg(15);
    *window_ptr++ = *row_ptr;
    *window_ptr++ = *col_ptr;
    *window_ptr++ = depth;

    for (i = 0; i < depth; i++)
    {
        line_ptr = scr_ptr + row * 80 + col;
        *window_ptr++ = line_ptr;
        *window_ptr++ = width;
        for (j = 0; j < width; j++)
        {
            *window_ptr++ = rd_scrn(row, col++);
        }
        col -= width;
        row++;
    }
    row -= depth;

    for (i = 1; i <= depth; i++)
    {
        for (j = 0; j < width; j++)
            wr_scrn(row, col++, ' ', NORMAL);
        col -= width;
        row++;
    }
    row -= depth;

        /* do top line */

    wr_scrn(row, col++, 0xc9, NORMAL);
    for (i = 0; i < width - 2; i++)
        wr_scrn(row, col++, 0xcd, NORMAL);
    wr_scrn(row, col++, 0xbb, NORMAL);
    col -= width;

        /* do bottom line */

    wr_scrn(row + depth - 1, col++, 0xc8, NORMAL);
    for (i = 0; i < width - 2; i++)
        wr_scrn(row + depth - 1, col++, 0xcd, NORMAL);
    wr_scrn(row + depth - 1, col++, 0xbc, NORMAL);
    col -= width;

        /* do sides */

    for (i = 1; i < depth - 1; i++)
    {
        wr_scrn(row + i, col, 0xba, NORMAL);
        wr_scrn(row + i, col + width - 1, 0xba, NORMAL);
    }

    return(window_level++);
}

/*
 *  Close a window 
 *
 *          closes windows in reverse order that they were opened
 *          and restores window contents to previous data.
 *
 */

close_window()
{
    int *window_ptr, *line_ptr;
    int i, j, width, depth;
    unsigned char *row_ptr, *col_ptr;

    if (window_level == 0)
        return();

    row_ptr = 0xff0c80;
    col_ptr = 0xff0c81;

    window_ptr = window_array[--window_level];
    put_crtc_reg(14, *window_ptr++);
    put_crtc_reg(15, *window_ptr++);
    *row_ptr = *window_ptr++;
    *col_ptr = *window_ptr++;
    depth = *window_ptr++;
    for (i = 0; i < depth; i++)
    {
        line_ptr = *window_ptr++;
        width = *window_ptr++;
        for (j = 0; j < width; j++)
            *line_ptr++ = *window_ptr++;
    }
    window_ptr = window_array[window_level];
    putc(0x1b,stderr);
    putc('=', stderr);
    putc(((*row_ptr) + 32) & 0x0ff, stderr);
    putc(((*col_ptr) + 32) & 0x0ff, stderr);
    free(window_ptr);
}

