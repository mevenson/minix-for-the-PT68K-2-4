recv_screen()
{
    open_window(PROTOCOL - 1, SCROFFSET - 1, 32, 9);
    gotorc(PROTOCOL, SCROFFSET);
    fprintf(stderr, "PROTOCOL:");
    gotorc(FNAME, SCROFFSET);
    fprintf(stderr, "FILENAME:");
    gotorc(BLOCKS, SCROFFSET);
    fprintf(stderr, "BLOCKS RECV:");
    gotorc(BYTESREAD, SCROFFSET);
    fprintf(stderr, "BYTES:");
    gotorc(ERRCNTROW, SCROFFSET);
    fprintf(stderr, "ERROR COUNT:");
    gotorc(WHYROW, SCROFFSET);
    fprintf(stderr, "LAST ERROR:");
    gotorc(STATUSROW, SCROFFSET);
    fprintf(stderr, "STATUS:");
}

