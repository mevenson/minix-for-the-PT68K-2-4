#include <stdio.h>
#include "ezm.h"

dump_phone()
{
    int i, j, k;

    dial_start = (dial_start > 41 ? 41 : dial_start);
    for (i = 0, j = dial_start - 1, k = 4; i < 10; i++, j++, k++)
    {
        gotorc(k, 3);
        fprintf(stderr, "%2d-",         dial_start + i);
        fprintf(stderr, " %s",          name[j]);
        fprintf(stderr, "   %s",        phone_number[j]);
        fprintf(stderr, "  %s",         baud[j]);
        fprintf(stderr, "          %s", cmd_file[j]);
    }
}

