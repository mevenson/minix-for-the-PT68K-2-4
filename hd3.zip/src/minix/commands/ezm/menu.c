menu()
{
    int b_size, b_avail, b_used;
    int c;

    b_size = memend - buf_base;
    b_avail = memend - buf_ptr;
    b_used = buf_ptr - buf_base;
    getime(&now);
    open_window(0,0,80,24);
    gotorc(2,20);
    fprintf(stderr, "EZMPlus 68000 Modem Program Version %s", VERSION);
    gotorc(3,20);
    fprintf(stderr, "current date and time: %02d/%02d/%02d %02d:%02d:%02d",
                                   now.t_month,
                                   now.t_day,
                                   now.t_year,
                                   now.t_hour,
                                   now.t_minute,
                                   now.t_second);
    gotorc(5,9);
    fprintf(stderr, "F1    = Auto Dialer");
    gotorc(6,9);
    fprintf(stderr, "F2    = Baud rate select      [%d]", baud_rate * 100);
    gotorc(7,9);
    fprintf(stderr, "F3    = Capture buffer toggle %s",capture?"[ON] ":"[OFF]");
    fprintf(stderr, " %d/%d", b_used, b_avail);
    gotorc(8,9);
    fprintf(stderr, "F4    = Disk Directory");
    gotorc(9,9);
    fprintf(stderr, "F5    = File mode select      [%s]", fm_str[file_mode]);
    gotorc(10,9);
    fprintf(stderr, "F6    = Block size toggle     ");
    if (recv_size == 1024)
        fprintf(stderr, "[1024]");
    else
        fprintf(stderr, "[128]");
    gotorc(11,9);
    fprintf(stderr, "F7    = Receive mode toggle   ");
    if (recv_mode == CRC)
        fprintf(stderr, "[CRC]");
    else
        fprintf(stderr, "[CHECKSUM]");
    gotorc(12,9);
    fprintf(stderr, "F8    = Name new device       [%s]", device_name);
    gotorc(13,9);
    fprintf(stderr, "F9    = Option file edit");
    gotorc(14,9);
    fprintf(stderr, "F10   = View capture buffer");
    gotorc(15,9);
    fprintf(stderr, "Pg Dn = Recieve file");
    gotorc(16,9);
    fprintf(stderr, "Pg Up = Send file");
    gotorc(17,9);
    fprintf(stderr, "ALT-X = Quit to DOS");
    gotorc(18,9);
    fprintf(stderr, "ALT-C = Clear screen");
    gotorc(19,9);
    fprintf(stderr, "ALT-H = Help screen (you're lookin at it)");
    gotorc(21,9);
    fprintf(stderr, "Enter command: ");
    c = rawget();
    close_window();
    hot_key(c & 0x00ff0000);
}

