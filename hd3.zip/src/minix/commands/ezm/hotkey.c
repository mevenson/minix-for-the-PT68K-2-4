hot_key(which_key)
int which_key;
{
    char drive, c;
    char temp[32];
    int  d_row, i, j, k;

    baud_rate = uvtable->device[modem_dev].ttyinfo.baudrt;
    switch (which_key)
    {
        case f1_key:
            auto_dial();
            break;
        case f2_key:
            baud_select();
            break;
        case f3_key:
            if (capture)
            {
                if (buf_ptr != buf_base)
                    save_buf();
                capture = 0;
            }
            else
                capture = 1;
            break;
        case f4_key:
            open_window(GFN - 1, 9, 50, 3);
            gotorc(GFN, 10);
            prompt("Enter filespec: ", mask, 32);
            if (mask[0] == '\0')
                return();
            close_window();
            j = 1;
            k = 0;
            open_window(0,0,80,24);
            d_row = 1;
            gotorc(d_row++, 1);
            if (search_first(mask, filename))
            {
                fprintf(stderr, "%-13s", filename);
                while (search_next(mask, filename))
                {
                    if (!(j++ % 5))
                    {
                        k++;
                        if (k == 21)
                        {
                            more(d_row);
                            k = 0;
                            d_row = 1;
                            for (i = 1; i < 23; i++)
                                clr_line(i, 1, 78);
                        }
                        gotorc(d_row++, 1);
                    }
                    else
                        fprintf(stderr, "| ");
                    fprintf(stderr, "%-13s", filename);
                }
                close(dir_fd);
            }
            last_page(d_row);
            close_window();
            break;
        case f5_key:
            set_file();
            break;
        case f6_key:
            if (recv_size == 1024)
               recv_size = 128;
            else
            {
               recv_mode = CRC;
               recv_size = 1024;
            }
            break;
       case f7_key:
            if (recv_mode == CRC)
            {
                recv_size = 128;
                recv_mode = NAK;
            }
            else
                recv_mode = CRC;
            break;
       case f8_key:
            name_device();
            break;
       case f9_key:
           edit_options();
           break;
       case f10_key:
           view();
           break;
       case x_key:
           open_window(2,2,13,4);
           gotorc(3,3);
           fprintf(stderr, "EXIT TO DOS");
           gotorc(4,3);
           fprintf(stderr, " [Y or N?] ");
           c = rawget();
           if (toupper(c) == 'Y')
           {
               uvtable->device[0].ttyinfo.pauseb = pause_flag;
               clrscrn();
               exit(0);
           }
           close_window();
           break;
       case pg_dn:
           if (pro_select())
               recvfile();
           break;
       case pg_up:
           if (pro_select())
           {
               if (protocol == YMODEMBATCH)
               {
                   open_window(GFN - 1, 9, 50, 3);
                   gotorc(GFN, 10);
                   prompt("Enter filespec: ", mask, 32);
                   close_window();
                   if (strlen(mask))
                   {
                       send_screen();
                       if (drive = search_first(mask, temp))
                       {
                           strcpy(filename, temp);
                           sendhdr();
                           sprintf(filename, "%c.", drive);
                           strcat(filename, temp);
                           sendfile(0);
                           while (search_next(mask, temp))
                           {
                               strcpy(filename, temp);
                               sendhdr();
                               sprintf(filename, "%c.", drive);
                               strcat(filename, temp);
                               sendfile(0);
                           }
                           close(dir_fd);
                       }
                       strcpy(filename, "");
                       sendhdr();
                   }
                   else
                   {
                       sendchar(CAN);
                       sendchar(CAN);
                   }
               }
               else
                   sendfile(0);
           }
           break;
       case a_key:
           speed_select();
           break;
       case b_key:
           test_speed();
           break;
       case c_key:
           clrscrn();
           break;
       case h_key:
           menu();
           break;
       default:
           fprintf(stderr, "\7\7");
           break;
       }
}

