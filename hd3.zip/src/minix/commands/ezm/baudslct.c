#include <stdio.h>
#include "windows.h"
#include "ezm.h"

baud_select()
{
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter baud rate: ", ascii_br, 20);
    close_window();
    if (ascii_br[0] == '\0')
        return;
    baud_rate =  atoi(ascii_br) / 100;
/*    uvtable->device[modem_dev].ttyinfo.baudrt = baud_rate; */
    dvr_init(modem_dev);
}

