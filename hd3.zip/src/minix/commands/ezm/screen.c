prompt(p,a,n)
char *p, *a;
int n;
{
    fprintf(stderr, "%s",p);
    getstr(a,n);
    p = a;
    while(*p & (*p == ' ' | *p == 9))
        p++;
    while(*a++ = *p++);
}

clreol()
{
    putc(0x1b,stderr);
    putc('T',stderr);
}

gotorc(row, col)
int row, col;
{
    putc(0x1b,stderr);
    putc('=',stderr);
    putc((row+32) & 0x0ff, stderr);
    putc((col+32) & 0x0ff, stderr);
}

clr_line(row, col, count)
int row, col, count;
{
    int i;

    gotorc(row, col);
    for (i = 0; i < count; i++)
        fprintf(stderr, " ");
    gotorc(row, col);
}

