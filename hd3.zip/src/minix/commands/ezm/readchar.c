/*
 * timed read of the modem port
 */

readchar(seconds)
int seconds;
{
    char data;
    char status;

    seconds = seconds * speed_adj;
    while (1)
    {
        status = dvr_istat(modem_dev);
        if (status | (seconds == 0))
            break;
        seconds--;
    }
    if (seconds == 0)
        return(TIMEOUT);
    return(dvr_gcne(modem_dev) & 0x0ff);
}

