test_speed()
{
    struct sgtbuf s_time;
    struct sgtbuf e_time;

    open_window(10,10, 60, 3);
    gotorc(11, 11);
    fprintf(stderr, "This should take 30 second - please wait");

    getime(&s_time);
    readchar(30);
    getime(&e_time);

    x = (unsigned int)e_time.t_hour * 3600 +
        (unsigned int)e_time.t_minute * 60 +
        (unsigned int)e_time.t_second;

    y = (unsigned int)s_time.t_hour * 3600 +
        (unsigned int)s_time.t_minute * 60 +
        (unsigned int)s_time.t_second;

    clr_line(11,11,58);
    fprintf(stderr, "For a value of %d 30 seconds took %d seconds",
        speed_adj, (x - y));
    close_window();
    getanykey();
}    

