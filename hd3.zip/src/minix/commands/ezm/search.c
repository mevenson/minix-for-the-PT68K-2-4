search_next(mask, buffer)
unsigned char *mask;
unsigned char buffer[];
{
    int  dir_status;

    while ((dir_status = dirread(dir_fd, buffer)) != 0)
        if (mask_compare(buffer, mask) != 0)
            return(dir_status);
    return(0);
}

unsigned char search_first(mask, buffer)
unsigned char *mask;
unsigned char buffer[];
{
    static unsigned char drive;

    if (drive = diropen(mask))
    {
        if (search_next(mask, buffer))
            return(drive);
        else
            return(0);
    }
    else
        fprintf(stderr, "directory open error");
    return(0);
}

