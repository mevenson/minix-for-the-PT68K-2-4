usage()
{
    clrscrn();
    fprintf(stderr, "%s\n",instruct1);
    fprintf(stderr, "%s\n",instruct2);
    fprintf(stderr, "%s\n",instruct3);
    fprintf(stderr, "%s\n",instruct4);
    fprintf(stderr, "%s\n",instruct5);
    fprintf(stderr, "%s\n",instruct6);
    fprintf(stderr, "%s\n",instruct7);
    fprintf(stderr, "%s\n",instruct8);
    fprintf(stderr, "%s\n",instruct9);
    fprintf(stderr, "%s\n",instruct10);
    fprintf(stderr, "%s\n",instruct11);
    fprintf(stderr, "%s\n",instruct12);
    fprintf(stderr, "%s\n",instruct13);
    fprintf(stderr, "%s\n",instruct14);
    fprintf(stderr, "%s\n",instruct15);
    fprintf(stderr, "%s\n",instruct16);
    fprintf(stderr, "%s\n",instruct17);
    fprintf(stderr, "%s\n",instruct18);
    fprintf(stderr, "%s\n",instruct19);
    fprintf(stderr, "%s",instruct20);
}

