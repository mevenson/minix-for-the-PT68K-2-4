terminal(flag)
int flag;
{
    int c, b_size, b_avail, b_used;
    char *cp;

    b_size = memend - buf_base;
    b_avail = memend - buf_ptr;
    b_used = buf_ptr - buf_base;

    ESC_Seq_State = 0;

    protocol = COMPUSERVE;
    proto_string = cis_b_protocol;

    getime(&now);
    if (flag)
    {
        clrscrn();
        fprintf(stderr,
                "EZMPlus 68000 Modem Program Ver %s date: %02d/%02d/%02d",
                VERSION,
                now.t_month,
                now.t_day,
                now.t_year);
         
        fprintf(stderr, " time: %02d:%02d:%02d\n",
                now.t_hour, now.t_minute, now.t_second);
        fprintf(stderr, "Buffer size = %d Available = %d Used = %d\n",
                b_size,b_avail,b_used);
        fprintf(stderr, "Use ALT-H for help screen\n\n");
        menu();
    }
    while (1)
    {
        if (rdy())
        {
            c = rawget();
            if (((c & alt_key) == alt_key) || (( c & 0x000000ff) == 0))
            {
                hot_key(c & 0x00ff0000);
                while (window_level)
                    close_window();
            }
            else
                dvr_putc(modem_dev,c & 0x007f);
        }
        if (dvr_istat(modem_dev))
        {
            c = dvr_gcne(modem_dev) & 127;
            if (protocol == COMPUSERVE)
            {
                switch(ESC_Seq_State)
                {
                    case 0:
                        switch (c)
                        {
                            case ESC:
                                ESC_Seq_State = 1;
                                break;
                            case ENQ:
                                Write_Modem(DLE);
                                Write_Modem('0');
                                break;
                            case DLE:
                                ESC_Seq_State = 2;
                                break;
                            default:
                                rawput(c);
                                if ((capture) & (buf_ptr < memend))
                                    *buf_ptr++ = c;
                        }
                        break;
                    case 1:
                        switch (c)
                        {
                            case 'I':
                                cp = VIDTEX_Response;
                                while (*cp != 0)
                                    rawput(*cp++);
                                ESC_Seq_State = 0;
                                break;
                            default:
                                rawput(ESC);
                                rawput(c);
                                ESC_Seq_State = 0;
                                break;
                        }
                        break;
                    case 2:
                        if (c == 'B')
                        {
                            if (!Transfer_File())
                            {
                                clr_line(STATUSROW, ERRORCOL, 16);
                                fprintf(stderr, "Aborted\7\7");
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Failed\7");
                                while (window_level)
                                    close_window();
                            }
                            else
                            {
                                clr_line(STATUSROW, ERRORCOL, 16);
                                fprintf(stderr, "Completed\7\7");
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Successfull\7");
                                while (window_level)
                                    close_window();
                            }
                        }
                        else
                        {
                            rawput(ESC);
                            rawput(c);
                        }
                        ESC_Seq_State = 0;
                        break;
                }
            }
            else
            {
                rawput(c);
                if ((capture) & (buf_ptr < memend))
                    *buf_ptr++ = c;
            }
        }
    }
    if (buf_ptr != buf_base)
        save_buf();
}

