
char *getstr(s, n)
char *s;
int n;
{
    register c;
    register char *cs;

    cs = s;
    while (n-- > 0 && (c = getc(stdin)) >= 0)
    {
        *cs++ = c;
        if ((c != 0x0d) && (c != 0x0a))
        {
            rawput(c & 0x7f);
            if (c == 0x08)
            {
                --cs;
                ++n;
                *cs = '\0';
                rawput(' ');
                if (cs != s)
                {
                    --cs;
                    ++n;
                    *cs = '\0';
                    rawput(0x08);
                }
                else
                    return(-1);
            }
        }
        else
        {
            --cs;
            *cs = '\0';
            c == 0x0a;
            break;
        }
    }

    if (c < 0 || cs==s)
        return(NULL);
    *cs++ = '\0';
    return(s);
}

