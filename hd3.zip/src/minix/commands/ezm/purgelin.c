purgeline()
{
    int c;

    while (dvr_istat(modem_dev))
        c = dvr_gcne(modem_dev);
}

