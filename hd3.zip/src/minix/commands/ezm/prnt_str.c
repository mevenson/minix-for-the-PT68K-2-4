prnt_str(str)
char *str;
{
    while(*str)
        dvr_putc(print_dev, *str++);
}

