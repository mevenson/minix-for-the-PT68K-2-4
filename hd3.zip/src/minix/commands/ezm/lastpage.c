last_page(row)
int row;
{
    gotorc(row, 1);
    fprintf(stderr, "[Last page]");
    rawget();
}

