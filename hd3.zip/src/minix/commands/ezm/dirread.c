#include <stdio.h>
#include "ezm.h"

/*
*** Read A Directory Entry
*/

dirread(fd, filename)
int  fd;
unsigned char *filename;
{
    int  i, j;
    FCB  *ptr;
    unsigned char work[20];

    while ((ptr = dskread(fd)) != NULL) 
    {
        for (i = 0; i < 8; ++i)
            filename[i] = ptr->dir.fname[i];
        filename[8] = '\0';
        if (*filename && !((*filename) & 128)) 
        {
            strcat(filename, ".");
            j = strlen(filename);
            for ( i = 0; i < 3; i++)
                filename[j+i] = ptr->dir.fext[i];
            filename[j + 3] = '\0';
            return(1);
        }
    }
    return(0);
}

