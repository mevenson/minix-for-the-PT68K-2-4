/*

        ezmodem.c

                communications program for the 68000

    version 2:5.1   Added Auto Dial capability.
    version 2:6.0   Added Option file Capability.
    version 2:6.1   Made compatible with new compiler (fix to open)
    version 2:6.2   Recompiled with new C compiler and Assembler
    version 2:7.0   Added Compuserve 'B' protocol
    version 3:0.0   Converted to not menu driven. Uses HOT keys

*/

#define VERSION "3:0.0"

#include <stdio.h>
#include <skdos.h>
#include <skioctl.h>
#include <time.h>
#include <ctype.h>
#include <windows.h>
#include <keycodes.h>

#define TIMEOUT     -1

#define SOH         0x01    /* ^A -- start of sector 128 byte blocks*/
#define STX         0x02    /* ^B -- start of sector 1K blocks */
#define ETX         0x03    /* ^C -- End Of Text */
#define EOT         0x04    /* ^D -- end of transmission */
#define ENQ         0x05    /* ^E -- Enquire */
#define ACK         0x06    /* ^F -- successfull transfer */
#define DLE         0x10    /* ^P -- Data Link Escape */
#define XON         0x11    /* ^Q -- Tranfer ON */
#define XOFF        0x13    /* ^S -- Transfer OFF */
#define NAK         0x15    /* ^U -- Negative ACKnowledge */
#define CAN         0x18    /* ^X -- cancel transmission */
#define ESC         0x1b    /* ^[ -- ESCape character */

#define CRC         'C'
#define ERRORMAX    10      /* number of errors till abort */
#define RETRYMAX    10      /* number of retrys till abort */
#define ERROR       0
#define CPM         0
#define ASCII       1
#define BINARY      2
#define RA          "r"
#define RB          "rb"
#define WA          "w"
#define WB          "wb"

#define ON           1
#define OFF          0

#define XMODEM      0
#define YMODEM      1
#define YMODEMBATCH 2
#define COMPUSERVE  3

#define PROTOCOL    10
#define FNAME       11
#define BLOCKS      12
#define BYTESREAD   13
#define BYTESSENT   13
#define ERRCNTROW   14
#define WHYROW      15
#define STATUSROW   16

#define SCROFFSET   40
#define ERRORCOL    14+SCROFFSET
#define GFN         12

/* defines for compuserve B protocol */

#define True            1
#define False           0
#define Success         -1
#define Failure         0
#define Packet_Size     512
#define Max_Errors      10
#define Max_Time        10
#define WACK            ';'             /* wait acknowledge */

/* Sender actions */

#define S_Send_Packet   0
#define S_Get_DLE       1
#define S_Get_Num       2
#define S_Get_Seq       3
#define S_Get_Data      4
#define S_Get_Checksum  5
#define S_Timed_Out     6
#define S_Send_NAK      7

/* Receiver actions */

#define R_Get_DLE       0
#define R_Get_B         1
#define R_Get_Seq       2
#define R_Get_Data      3
#define R_Get_Checksum  4
#define R_Send_NAK      5
#define R_Send_ACK      6

static int
    Ch,
    Checksum,
    Seq_Num,
    R_Size,                             /* Size of receiver buffer */
    XOFF_Flag,
    Seen_ETX;

static char
    cis_failure[32],                    /* save failure for output */
    S_Buffer[Packet_Size],              /* Sender buffer */
    R_Buffer[Packet_Size];              /* Receiver buffer */

static char
    VIDTEX_Response[] = "#IB1,PB,DT015";

static int ESC_Seq_State;

char phone_list[] = "0.PHONELST.EZM";
char opt_file[]   = "0.DEFLTOPT.EZM";

char crlf_str[] = {
    0x0d, 0x0a, 0x00};
char nulls[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

char *fm_str[] = {
    "CP/M", "ASCII", "BINARY"};

char *instruct1 =
"EZMPLUS is designed to operate  on any SK*DOS system through an  installed";
char *instruct2 =
"device  driver.  If no device name is given on  the command  line when the";
char *instruct3 =
"program is invoked, it defaults to 'MODM'. If you want  to run the program";
char *instruct4 =
"without  the need  to enter  the device  name, have  your STARTUP.BAT file";
char *instruct5 =
"install the device driver at boot or do it manually before running EZMPLUS";
char *instruct6 =
"";
char *instruct7 =
"             dosparam 4 br=12";
char *instruct8 =
"             device 0.serial1.dvr as MODM at 4";
char *instruct9 =
"";
char *instruct10 =
"EZMPLUS will support baud rates from 300 baud to 19.2K baud. It currently";
char *instruct11 =
"supports XMODEM, YMODEM, YMODEM BATCH, and COMPUSERVE B protocols.";
char *instruct12 =
"";
char *instruct13 =
"If you like EZMODEM and would like to contribute to it's developement, all";
char *instruct14 =
"contributions are sincerly appreciated. Any contribution of $45.00 or more";
char *instruct15 =
"will provide the contributor one year of updates as they become available.";
char *instruct16 =
"";
char *instruct17 =
"          Michael Evenson";
char *instruct18 =
"          200 Ginger Ct.";
char *instruct19 =
"          Southlake Tx. 76092";
char *instruct20 =
"          BBS phone # 817-488-8398";

char *memend, *buf_ptr, *buf_base;

char x_protocol[]      = "XMODEM";
char y_protocol[]      = "YMODEM";
char ybatch_protocol[] = "YMODEM Batch";
char cis_b_protocol[]  = "COMPUSERVE B";

char device_name[5];
char mod_dial_str[21];
char ld_codes[5];
char dial_cmd_suff[15];
char connect_str[32];
char connect_wait[10];
char redial_pause[10];
char reply[32];
char minus[15];
char plus[15];
char atsign[15];
char pound[15];
char printer[2];

char *proto_string = x_protocol;

unsigned char recv_mode = CRC;
unsigned int  recv_size = 1024;
unsigned int  protocol  = XMODEM;

char name[50][25];
char phone_number[50][15];
char baud[50][6];
char cmd_file[50][9];

struct sgtbuf now;

char pause_flag, *r_str, *w_str;
struct uvarlst *uvtable;
unsigned char hdr_block[128];
unsigned char mask[32];
unsigned char filename[32];
unsigned char answer[20];
unsigned char ascii_br[20];
unsigned char ascii_sa[20];
int  ezmphone_changed = 0;
int  minus_flag, plus_flag, atsign_flag, pound_flag = 0;
int  modem_dev;
int  print_dev;
int  baud_rate;
int  capture;
int  file_mode;

unsigned int speed_adj, average, x, y, z, tot_bytes;

unsigned short  r_crcval;
unsigned short  crcval;             /* CRC check value */

int dir_fd, dial_fd, opt_fd;

SKTTYB data;

char *getstr(s, n)
char *s;
int n;
{
    register c;
    register char *cs;

    cs = s;
    while (n-- > 0 && (c = getc(stdin)) >= 0)
    {
        *cs++ = c;
        if ((c != 0x0d) && (c != 0x0a))
        {
            rawput(c & 0x7f);
            if (c == 0x08)
            {
                --cs;
                ++n;
                *cs = '\0';
                rawput(' ');
                if (cs != s)
                {
                    --cs;
                    ++n;
                    *cs = '\0';
                    rawput(0x08);
                }
                else
                    return(-1);
            }
        }
        else
        {
            --cs;
            *cs = '\0';
            c == 0x0a;
            break;
        }
    }

    if (c < 0 || cs==s)
        return(NULL);
    *cs++ = '\0';
    return(s);
}

/* set console to raw mode */

raw_mode(f)
FILE *f;
{
    f->_flag |= _IONBF;
}

/* set console back to buffered mode */

buf_mode(f)
FILE *f;
{
    f->_flag &= ~_IONBF;
}

/*
*** Convert String To Upper Case 
*/

str_upper(s)
unsigned char *s;
{
    while (*s = toupper(*s))
        ++s;
}


/*
*    compare a string against a mask
*
*    returns 1 if successfull
*            0 if fails
*
*    Mask can contain any of the following elements:
*
*    c          literal character
*    ?          any character match except endstring null
*    [..]       character class (all of these characters)
*    [^..]      negated character class (all but these characters)
*    ^c         negated character (all but this character)
*    *          zone (match zero or more occurences)
*
*    A character class consists of zero or more of the following
*    surrounded by [ and ]:
*
*    c1-c2      range of ASCII characters
*    c1-c2..c1-c3 multiple ranges
*
*
*/

mask_compare(string, m)
unsigned char *string, *m;
{
    int    k;
    unsigned char *sp, *sav, string2[128];

    strcpy(sp = string2, string);
    for (k = 0; k < 11; k++)
        if(string2[k] == ' ')
            string2[k] = '\0';
    str_upper(m);
    while (*m) 
    {
        if (*m == '*') 
        {
            sav = sp;
            if (!*++m)
                return(1);
            while (*sp && !mask_compare(sp, m))
                ++sp;
            if (*sp)
                continue;
            sp = sav;
        }
        else if (!(k = onecmp(*sp, m)))
            return(0);
        else
            m += k;
        if (*sp)
            ++sp;
    }
    return(!*sp);
}

/*
*** Compare Only One Character (for mask_compare)
*/

onecmp(s, m)
unsigned char s, *m;
{
    unsigned char    c, setfind, setflag;
    unsigned char    *mp;

    if ((c = *(mp = m)) == '?' && s)      /* okay as is */
        ;
    else if (c == '[') 
    {
        setfind = setflag = 0;
        if (*++mp == '^') 
        {
            setflag = 1;
            ++mp;
        }
        for (; (c = *mp) && c != ']'; ++mp)
            if (*mp=='-' && s>=*(mp - 1) && s<=*(mp+1) && *(mp-1)<=*(mp+1)) 
            {
                while ((c = *(mp + 1)) && c != ']')  /* skip to trailing ']'*/
                    ++mp;
                setfind = 1;
            }
        if (setfind == setflag)
            return(0);
        else
            return(mp - m + 1);
    }
    else if (c == '^' && *(mp + 1) != s)
        return(2);
    else if (c != s)
        return(0);
    return(1);
}

/*
*** Open Disk Directory
*/

unsigned char diropen(mask)
unsigned char *mask;
{
    static  D_drive;
    char    drv[3];

    drv[0] = NULL;
    drv[1] = NULL;
    drv[2] = NULL;

    D_drive = fndwrkdv();
    if (strlen(mask) == 1 && isdigit(*mask))
        strcat(mask, ".*");
    if ((mask[1] == '.') && isdigit(*mask))
    {
        D_drive = *mask - '0';
        strcpy(mask, mask + 2);
    }
    if (D_drive < 0 || D_drive > 9)
        return(0);
    sprintf(drv,"%ld",D_drive);
    if ((dir_fd = open(drv,7)) == -1)
        return(0);
    return(D_drive + '0');
}

/*
*** Read A Directory Entry
*/

dirread(fd, filename)
int  fd;
unsigned char *filename;
{
    int  i, j;
    FCB  *ptr;
    unsigned char work[20];

    while ((ptr = dskread(fd)) != NULL) 
    {
        for (i = 0; i < 8; ++i)
            filename[i] = ptr->dir.fname[i];
        filename[8] = '\0';
        if (*filename && !((*filename) & 128)) 
        {
            strcat(filename, ".");
            j = strlen(filename);
            for ( i = 0; i < 3; i++)
                filename[j+i] = ptr->dir.fext[i];
            filename[j + 3] = '\0';
            return(1);
        }
    }
    return(0);
}

search_next(mask, buffer)
unsigned char *mask;
unsigned char buffer[];
{
    int  dir_status;

    while ((dir_status = dirread(dir_fd, buffer)) != 0)
        if (mask_compare(buffer, mask) != 0)
            return(dir_status);
    return(0);
}

unsigned char search_first(mask, buffer)
unsigned char *mask;
unsigned char buffer[];
{
    static unsigned char drive;

    if (drive = diropen(mask))
    {
        if (search_next(mask, buffer))
            return(drive);
        else
            return(0);
    }
    else
        fprintf(stderr, "directory open error");
    return(0);
}

prompt(p,a,n)
char *p, *a;
int n;
{
    fprintf(stderr, "%s",p);
    getstr(a,n);
    p = a;
    while(*p & (*p == ' ' | *p == 9))
        p++;
    while(*a++ = *p++);
}

clreol()
{
    putc(0x1b,stderr);
    putc('T',stderr);
}

gotorc(row, col)
int row, col;
{
    putc(0x1b,stderr);
    putc('=',stderr);
    putc((row+32) & 0x0ff, stderr);
    putc((col+32) & 0x0ff, stderr);
}

clr_line(row, col, count)
int row, col, count;
{
    int i;

    gotorc(row, col);
    for (i = 0; i < count; i++)
        fprintf(stderr, " ");
    gotorc(row, col);
}

recv_screen()
{
    open_window(PROTOCOL - 1, SCROFFSET - 1, 32, 9);
    gotorc(PROTOCOL, SCROFFSET);
    fprintf(stderr, "PROTOCOL:");
    gotorc(FNAME, SCROFFSET);
    fprintf(stderr, "FILENAME:");
    gotorc(BLOCKS, SCROFFSET);
    fprintf(stderr, "BLOCKS RECV:");
    gotorc(BYTESREAD, SCROFFSET);
    fprintf(stderr, "BYTES:");
    gotorc(ERRCNTROW, SCROFFSET);
    fprintf(stderr, "ERROR COUNT:");
    gotorc(WHYROW, SCROFFSET);
    fprintf(stderr, "LAST ERROR:");
    gotorc(STATUSROW, SCROFFSET);
    fprintf(stderr, "STATUS:");
}

send_screen()
{
    open_window(PROTOCOL - 1, SCROFFSET - 1, 32, 9);
    gotorc(PROTOCOL, SCROFFSET);
    fprintf(stderr, "PROTOCOL:");
    gotorc(FNAME, SCROFFSET);
    fprintf(stderr, "FILENAME:");
    gotorc(BLOCKS, SCROFFSET);
    fprintf(stderr, "BLOCKS SENT:");
    gotorc(BYTESSENT, SCROFFSET);
    fprintf(stderr, "BYTES:");
    gotorc(ERRCNTROW, SCROFFSET);
    fprintf(stderr, "ERROR COUNT:");
    gotorc(WHYROW, SCROFFSET);
    fprintf(stderr, "LAST ERROR:");
    gotorc(STATUSROW, SCROFFSET);
    fprintf(stderr, "STATUS:");
}

last_page(row)
int row;
{
    gotorc(row, 1);
    fprintf(stderr, "[Last page]");
    rawget();
}

more(row)
int row;
{
    gotorc(row, 1);
    fprintf(stderr, "[More]");
    rawget();
}

/* Read_Modem and Write_Modem for COMPUSERVE B protocol */

Read_Modem()
{
    if (dvr_istat(modem_dev))
        return(dvr_gcne(modem_dev) & 0x0ff);
    else
        return (-1);
}

Write_Modem(data)
char data;
{
    while(1)
        if (dvr_ostat(modem_dev))
            break;
    dvr_putc(modem_dev, data);
}

/* see if operator wants to abort - return true if yes, false if no */

Wants_To_Abort()
{
    if (rdy())
    {
        if (rawget() == 0x1b)
            return(1);
    }
    return(0);
}

getanykey()
{
    open_window(19,26,27,3);
    gotorc(20, 27);
    fprintf(stderr, "Press any key to continue");
    rawget();
    close_window();
}

static Put_Msg(Text)
char *Text;
{
    while (*Text != 0) rawput(*Text++);
    rawput('\015');
    rawput('\012');
}

static Send_Byte(Ch)
int Ch;
{
    int TCh;

    /* Listen for XOFF from the network */

    do
    {
        while ((TCh = Read_Modem()) >= 0)
            if (TCh == XON) XOFF_Flag = False;
            else if (TCh == XOFF) XOFF_Flag = True;
    }
    while (XOFF_Flag);

    while (!Write_Modem(Ch));
}

static Send_Masked_Byte(Ch)
int Ch;
{
    /* Mask any protocol or flow characters */

    if(Ch==ETX||Ch==ENQ||Ch==DLE||Ch==NAK||Ch==XON||Ch==XOFF)
    {
        Send_Byte(DLE);
        Send_Byte(Ch + '@');
    }
    else Send_Byte(Ch);
}

static Send_ACK()
{
    Send_Byte(DLE);
    Send_Byte(Seq_Num + '0');
}

Read_Byte()
{
    char data;
    char status;
    int  seconds;

    seconds = Max_Time * speed_adj;
    while (1)
    {
        status = dvr_istat(modem_dev);
        if (status | (seconds == 0))
            break;
        seconds--;
    }
    if (seconds == 0)
        return(Failure);
    Ch = dvr_gcne(modem_dev) & 0x0ff;
    return(Success);
}

Delay(time)
int time;
{
    int  seconds;

    seconds = time * speed_adj / 250;
    while (1)
    {
        if (seconds <= 0)
            break;
        seconds--;
        seconds--;
        seconds--;
        seconds--;
    }
}

static Read_Masked_Byte()
{
    Seen_ETX = False;
    if (Read_Byte() == Failure) return Failure;

    if (Ch == DLE)
    {
        if (Read_Byte() == Failure) return Failure;
        Ch &= 0x1F;
    }
    else if (Ch == ETX) Seen_ETX = True;

    return Success;
}

static Do_Checksum(Ch)
int Ch;
{
    Checksum <<= 1;
    if (Checksum > 255)
        Checksum = (Checksum & 0xFF) + 1;
    Checksum += Ch;
    if (Checksum > 255)
        Checksum = (Checksum & 0xFF) + 1;
}

/*
 * Function: Receive a packet from the host.
 * Inputs:   Action -- the starting action
 * Outputs:  R_Buffer -- contains the packet just received
 *           R_Size -- length of the packet
 * Returns:  success/failure
 */

static int Read_Packet(Action)
int Action;
{
    int Errors;
    int Next_Seq;

    Errors = 0;
    Checksum = 0;

    while (Errors < Max_Errors)
        switch (Action)
        {
            case R_Get_DLE:
                if (Read_Byte() == Failure)
                {
                    strcpy(cis_failure, "R_Get_DLE");
                    Action = R_Send_NAK;
                }
                else if (Ch == DLE)
                    Action = R_Get_B;
                else if (Ch == ENQ)
                    Action = R_Send_ACK;
                break;

            case R_Get_B:
                if (Read_Byte() == Failure)
                {
                    strcpy(cis_failure, "R_Get_B");
                    Action = R_Send_NAK;
                }
                else if (Ch == 'B')
                    Action = R_Get_Seq;
                else
                    Action = R_Get_DLE;
                break;

            case R_Get_Seq:
                if (Read_Byte() == Failure)
                {
                    strcpy(cis_failure, "R_Get_Seq");
                    Action = R_Send_NAK;
                }
                else
                {
                    Checksum = 0;
                    Next_Seq = Ch - '0';
                    Do_Checksum(Ch);
                    R_Size = 0;
                    Action = R_Get_Data;
                }

                break;

            case R_Get_Data:
                if (Read_Masked_Byte() == Failure)
                {
                    strcpy(cis_failure, "R_Get_Data");
                    Action = R_Send_NAK;
                }
                else if (Seen_ETX)
                    Action = R_Get_Checksum;
                else if (R_Size == Packet_Size)
                {
                    strcpy(cis_failure, "missing ETX");
                    Action = R_Send_NAK;
                }
                else
                {
                    R_Buffer[R_Size++] = Ch;
                    Do_Checksum(Ch);
                }
                break;

            case R_Get_Checksum:
                Do_Checksum(ETX);
                if (Read_Masked_Byte() == Failure)
                {
                    strcpy(cis_failure, "no checksum byte");
                    Action = R_Send_NAK;
                }
                else if (Checksum != Ch)
                {
                    strcpy(cis_failure, "checksum error");
                    Action = R_Send_NAK;
                }
                else if (Next_Seq == Seq_Num)
                    Action = R_Send_ACK;        /* Ignore duplicate packet */
                else if (Next_Seq != (Seq_Num + 1) % 10)
                {
                    strcpy(cis_failure, "wrong sequence number");
                    Action = R_Send_NAK;
                }
                else
                {
                    Seq_Num = Next_Seq;
                    return Success;
                }

                break;

            case R_Send_NAK:
                Errors++;
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d\7", Errors);
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, cis_failure);
                Send_Byte(NAK);
                Action = R_Get_DLE;
                break;

            case R_Send_ACK:
                Send_ACK();
                Action = R_Get_DLE;
                break;
        }

    return Failure;
}

/*
 * Function: Send the specified packet to the host.
 * Inputs:   Size -- length of the packet
 *           S_Buffer -- the packet to send
 * Outputs:
 * Returns:  success/failure
 */
 
static int Send_Packet(Size)
int Size;                           /* size of packet to send */
{
    int Action;
    int Next_Seq;
    int RCV_Num;
    int I;
    int Errors;

    Next_Seq = (Seq_Num + 1) % 10;
    Errors = 0;
    Action = S_Send_Packet;

    while (Errors < Max_Errors)
        switch (Action)
        {
            case S_Send_Packet:
                Checksum = 0;
                Send_Byte(DLE);
                Send_Byte('B');
                Send_Byte(Next_Seq + '0');
                Do_Checksum(Next_Seq + '0');

                for (I = 0; I < Size; I++)
                {
                    Send_Masked_Byte(S_Buffer[I]);
                    Do_Checksum(S_Buffer[I]);
                }

                Send_Byte(ETX);
                Do_Checksum(ETX);
                Send_Masked_Byte(Checksum);
                Action = S_Get_DLE;
                break;

            case S_Get_DLE:
                if (Read_Byte() == Failure) Action = S_Timed_Out;
                else if (Ch == DLE) Action = S_Get_Num;
                else if (Ch == NAK)
                {
                    Errors++;
                    Action = S_Send_Packet;
                }

                break;

            case S_Get_Num:
                if (Read_Byte() == Failure) Action = S_Timed_Out;
                else if (Ch >= '0' && Ch <= '9')
                {
                    if (Ch == Seq_Num + '0')
                        Action = S_Get_DLE;     /* Ignore duplicate ACK */
                    else if (Ch == Next_Seq + '0')
                    {
                        /* Correct sequence number */

                        Seq_Num = Next_Seq;
                        return Success;
                    }
                    else if (Errors == 0) Action = S_Send_Packet;
                    else Action = S_Get_DLE;
                }
                else if (Ch == WACK)
                {
                    Delay(5000);        /* Sleep for 5 seconds */
                    Action = S_Get_DLE;
                }
                else if (Ch == 'B') Action = S_Get_Seq;
                else Action = S_Get_DLE;
                break;

            case S_Get_Seq:
                /**
                 * Start of a "B" protocol packet. The only packet that makes
                 * any sense here is a failure packet.
                 **/

                if (Read_Byte() == Failure) Action = S_Send_NAK;
                else
                {
                    Checksum = 0;
                    RCV_Num = Ch - '0';
                    Do_Checksum(Ch);
                    I = 0;
                    Action = S_Get_Data;
                }

                break;

            case S_Get_Data:
                if (Read_Masked_Byte() == Failure) Action = S_Send_NAK;
                else if (Seen_ETX) Action = S_Get_Checksum;
                else if (I == Packet_Size) Action = S_Send_NAK;
                else
                {
                    R_Buffer[I++] = Ch;
                    Do_Checksum(Ch);
                }

                break;

            case S_Get_Checksum:
                Do_Checksum(ETX);

                if (Read_Masked_Byte() == Failure) Action = S_Send_NAK;
                else if (Checksum != Ch) Action = S_Send_NAK;
                else if (RCV_Num != (Next_Seq + 1) % 10) Action = S_Send_NAK;
                else
                {
                    /**
                     * Assume the packet is failure packet. It makes no
                     * difference since any other type of packet would be
                     * invalid anyway. Return failure to caller.
                     **/

                    Errors = Max_Errors;
                }

                break;

            case S_Timed_Out:
                Errors++;
                Action = S_Get_DLE;
                break;

            case S_Send_NAK:
                rawput('-');
                Errors++;
                Send_Byte(NAK);
                Action = S_Get_DLE;
                break;
        }

    return Failure;
}

/*
 * Function: Send a failure packet to the host.
 * Inputs:   Code -- failure code
 * Outputs:
 * Returns:
 */

static Send_Failure(Code)
char Code;
{
    S_Buffer[0] = 'F';
    S_Buffer[1] = Code;
    Send_Packet(2);
}

/*
 * Function: Download the specified file from the host.
 * Inputs:   Name -- ptr to the file name string
 * Outputs:
 * Returns:  success/failure
 */

static int Receive_File(Name)
char *Name;
{
    int blocks, Data_File;

    tot_bytes = 0;
    blocks = 0;

    if ((Data_File = fopen(Name, "wb")) == 0)
    {
        Put_Msg("Cannot create file");
        Send_Failure('E');
        return Failure;
    }

    Send_ACK();

    for (;;)
        if (Read_Packet(R_Get_DLE) == Success)
            switch (R_Buffer[0])
            {
                case 'N':               /* Data packet */

            if (fwrite(&R_Buffer[1], 1, R_Size - 1, Data_File) != R_Size - 1)
                    {
                        /* Disk write error */

                        Put_Msg("Disk write error");
                        Send_Failure('E');
                        fclose(Data_File);
                        return Failure;
                    }

                    if (Wants_To_Abort())
                    {
                        /* The user wants to kill the transfer */

                        Send_Failure('A');
                        fclose(Data_File);
                        return Failure;
                    }

                    blocks++;
                    tot_bytes += R_Size - 1;
                    clr_line(BLOCKS, ERRORCOL, 16);
                    fprintf(stderr, "%d", blocks);
                    clr_line(BYTESREAD, ERRORCOL, 16);
                    fprintf(stderr, "%d", tot_bytes);
                    Send_ACK();
                    break;

                case 'T':               /* Transfer packet */

                    if (R_Buffer[1] == 'C') /* Close file */
                    {
                        Send_ACK();
                        fclose(Data_File);
                        return Success;
                    }
                    else
                    {
                        /**
                         * Unexpected "T" packet. Something is rotten on the
                         * other end. Send a failure packet to kill the
                         * transfer cleanly.
                         **/

                        Put_Msg("Unexpected packet type");
                        Send_Failure('E');
                        fclose(Data_File);
                        return Failure;
                    }

                case 'F':               /* Failure packet */
                    Send_ACK();
                    fclose(Data_File);
                    return Failure;
            }
        else
        {
            fclose(Data_File);
            return Failure;
        }
}

/*
 * Function: Send the specified file to the host.
 * Inputs:   Name -- ptr to the file name string
 * Outputs:
 * Returns:  success/failure
 */

static int Send_File(Name)
char *Name;
{
    int Data_File;
    int N;

    if ((Data_File = fopen(Name, "rb")) == 0)
    {
        Put_Msg("Cannot access that file");
        Send_Failure('E');
        return Failure;
    }

    do
    {
        S_Buffer[0] = 'N';
        N = fread(&S_Buffer[1], 1, Packet_Size - 1, Data_File);
        if (N > 0)
        {
            if (Send_Packet(N + 1) == Failure)
            {
                fclose(Data_File);
                return Failure;
            }

            if (Wants_To_Abort())
            {
                Send_Failure('A');
                fclose(Data_File);
                return Failure;
            }

            rawput('+');
        }
    } while (N > 0);

    if (N == 0)                         /* end of file */
    {
        fclose(Data_File);
        S_Buffer[0] = 'T';
        S_Buffer[1] = 'C';
        return Send_Packet(2);
    }
    else
    {
        Put_Msg("Disk read error");
        Send_Failure('E');
        return Failure;
    }
}

/*
 * Function: Transfer a file from/to the macro to/from the host.
 * Inputs:
 * Outputs:
 * Returns:  success/failure
 */

int Transfer_File()
{
    int I, N;
    char Name[64];

    XOFF_Flag = False;
    Seq_Num = 0;

    recv_screen();
    clr_line(PROTOCOL, ERRORCOL, 16);
    fprintf(stderr, proto_string);

    if (Read_Packet(R_Get_Seq) == Success)
    {
        if (R_Buffer[0] == 'T')         /* transfer packet */
        {
            /* Check the direction */

            if (R_Buffer[1] != 'D' && R_Buffer[1] != 'U')
            {
                Send_Failure('N');      /* not implemented */
                return Failure;
            }

            /* Check the file type */

            if (R_Buffer[2] != 'A' && R_Buffer[2] != 'B')
            {
                Send_Failure('N');
                return Failure;
            }

            /* Collect the file name */

            if (R_Size - 3 > 63) N = 63;
            else N = R_Size - 3;

            for (I = 0; I < N; I++)
                Name[I] = R_Buffer[I + 3];

            Name[I] = 0;
            clr_line(FNAME, ERRORCOL, 16);
            fprintf(stderr, Name);

            /* Do the transfer */

            if (R_Buffer[1] == 'U') return Send_File(Name);
            else return Receive_File(Name);
        }
        else
        {
            Send_Failure('E');          /* wrong type of packet */
            return Failure;
        }
    }
    else return Failure;
}

/*
 * read a file using the XMODEM, YMODEM or YMODEM Batch protocol
 */

recvfile()
{
    int r_char, curr_size, blocks, sectnum, sectcurr, sectcomp, errors;
    int checksum, r_checksum, errorflag, *fd, i, j;
    int recv_ok;
    char sector[1026];

    if ((protocol == XMODEM) || (protocol == YMODEM))
    {
        open_window(GFN - 1, 9, 50, 3);
        gotorc(GFN, 10);
        prompt("Enter filename: ",filename, 32);
        if (filename[0] == '\0')
            return;
        if ((fd = fopen(filename,w_str)) == ERROR)
        {
            clr_line(GFN, 10, 38);
            fprintf(stderr, "Can't open %s for write\7",filename);
            getanykey();
            return;
        }
    }
    recv_screen();
    clr_line(PROTOCOL, ERRORCOL, 16);
    fprintf(stderr, proto_string);
    if (protocol != YMODEMBATCH)
    {
        clr_line(FNAME, ERRORCOL, 16);
        fprintf(stderr, filename);
    }
    do
    {
        if (protocol == YMODEMBATCH)
        {
            clr_line(ERRCNTROW, ERRORCOL, 16);
            clr_line(WHYROW, ERRORCOL, 16);
            clr_line(BLOCKS, ERRORCOL, 16);
            clr_line(FNAME, ERRORCOL, 16);
            clr_line(BYTESREAD, ERRORCOL, 16);
            clr_line(STATUSROW, ERRORCOL, 16);
        }
        tot_bytes = 0;
        blocks = 0;
        sectnum = errors = 0;
        sendchar(recv_mode);
        do
        {
            errorflag = 0;
            do
            {
                r_char = readchar(10);
                switch (r_char)
                {
                    case STX:
                        curr_size = 1024;
                        errors = 0;
                        errorflag = 0;
                        break;
                    case SOH:
                        curr_size = 128;
                        errors = 0;
                        errorflag = 0;
                        break;
                    case EOT:
                        errors = 0;
                        errorflag = 0;
                        break;
                    case TIMEOUT:
                        errorflag = 1;
                        errors++;
                        clr_line(ERRCNTROW, ERRORCOL, 16);
                        fprintf(stderr, "%d\7", errors);
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "Timeout\7");
                        sendchar(NAK);
                        break;
                    default:
                        errorflag = 1;
                        errors++;
                        clr_line(ERRCNTROW, ERRORCOL, 16);
                        fprintf(stderr, "%d\7", errors);
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "Not SOH [%02x]\7", r_char & 0x0ff);
                        idle();
                        sendchar(NAK);
                        break;
                }
            } while ((errors < ERRORMAX) && (errorflag));
            switch (r_char)
            {
                case STX:
                case SOH:
                    sectcurr = readchar(1) & 255;
                    sectcomp = readchar(1) & 255;
                    if (sectcurr + sectcomp == 255)
                    {
                        if ((sectcurr == ((sectnum + 1) & 255)) || (sectcurr == 0))
                        {
                            for (j = 0, checksum = 0; j < curr_size; j++)
                            {
                                sector[j] = readchar(1);
                                checksum = checksum + sector[j];
                                checksum = checksum & 255;
                            }
                            if (recv_mode == NAK)
                            {
                                r_checksum = readchar(1) & 255;
                                if (checksum == r_checksum)
                                    recv_ok = 1;
                                else
                                    recv_ok = 0;
                            }
                            else
                            {
                                r_crcval = (readchar(1) & 255) << 8;
                                r_crcval = r_crcval + (readchar(1) & 255);
                                crcval = calc_crc(sector, curr_size);
                                if (crcval == r_crcval)
                                    recv_ok = 1;
                                else
                                    recv_ok = 0;
                            }
                            if (recv_ok)
                            {
                                if ((sectcurr == 0) && (sectnum == 0))
                                {
                                    if (sector[0] == 0)
                                    {
                                        sendchar(ACK);
                                        return();
                                    }
                                    strcpy(filename, sector);
                                    if ((fd = fopen(filename,w_str)) == ERROR)
                                    {
                                        gotorc(GFN, 10);
                                        fprintf(stderr, "Create error");
                                        sendchar(CAN);
                                        sendchar(CAN);
                                        getanykey();
                                        return;
                                    }
                                    clr_line(PROTOCOL, ERRORCOL, 16);
                                    fprintf(stderr, proto_string);
                                    clr_line(FNAME, ERRORCOL, 16);
                                    fprintf(stderr, filename);
                                    sendchar(ACK);
                                    idle();
                                    sendchar(CRC);
                                }
                                else
                                {
                                    sectnum++;
                                    if (fwrite(sector, 1, curr_size, fd) == 0)
                                    {
                                        clr_line(WHYROW, ERRORCOL, 16);
                                        fprintf(stderr, "write error\7");
                                        fclose(fd);
                                        return;
                                    }
                                    if (curr_size == 128)
                                        blocks++;
                                    else
                                        blocks += 8;
                                    tot_bytes += curr_size;
                                    clr_line(BLOCKS, ERRORCOL, 16);
                                    fprintf(stderr, "%d", blocks);
                                    clr_line(BYTESREAD, ERRORCOL, 16);
                                    fprintf(stderr, "%d", tot_bytes);
                                    sendchar(ACK);
                                }
                                errors = 0;
                            }
                            else
                            {
                                clr_line(WHYROW, ERRORCOL, 16);
                                if (recv_mode == NAK)
                                    fprintf(stderr, "checksum error\7");
                                else
                                    fprintf(stderr, "CRC error\7");
                                errorflag = 1;
                            }
                        }
                        else
                        {
                            if (sectcurr == (sectnum & 255))
                            {
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Dup Sect %d",sectnum);
                                idle();
                                sendchar(ACK);
                            }
                            else
                            {
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Sync error\7");
                                errorflag = 1;
                            }
                        }
                    }
                    else
                    {
                        clr_line(WHYROW, ERRORCOL, 16);
                        printf(stderr, "Sector number\7");
                        errorflag = 1;
                    }
                    if (errorflag)
                    {
                        errors++;
                        clr_line(ERRCNTROW, ERRORCOL, 16);
                        fprintf(stderr, "%d\7", errors);
                        while (readchar(1) != TIMEOUT);
                        sendchar(NAK);
                    }
                    if (errors >= ERRORMAX)
                    {
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "Too Many Errors\7");
                    }
                    break;

                case EOT:
                    if (errors < ERRORMAX)
                    {
                        sendchar(ACK);
                        fclose(fd);
                        clr_line(STATUSROW, ERRORCOL, 16);
                        fprintf(stderr, "Completed");
                    }
                    else
                    {
                        clr_line(STATUSROW, ERRORCOL, 16);
                        fprintf(stderr, "Aborting\7");
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "BAD [%02x]\7", r_char & 0x0ff);
                        errors = ERRORMAX;
                    }
                    break;

                default:
                    clr_line(STATUSROW, ERRORCOL, 16);
                    fprintf(stderr, "Aborting\7");
                    clr_line(WHYROW, ERRORCOL, 16);
                    fprintf(stderr, "BAD [%02x]\7", r_char & 0x00ff);
                    errors = ERRORMAX;
                    break;
            }
            if (errors >= ERRORMAX)
                break;
        } while (r_char != EOT);
    } while ((protocol == YMODEMBATCH) && (errors < ERRORMAX));
}

calc_crc(ptr, count)
char *ptr;
int count;
{
    int crc, i;
    crc = 0;
    while (--count >= 0)
    {
        crc = crc ^ (int)*ptr++ << 8;
        for (i = 0; i < 8; ++i)
            if (crc & 0x8000)
                crc = crc << 1 ^ 0x1021;
            else
                crc = crc << 1;
    }
    return (crc & 0xFFFF);
}

/*
 * prepare sector to send header for YMODEMBATCH
 */

sendhdr()
{
    int i;

    for (i = 0; i < 128; i++)
        hdr_block[i] = 0;
    strcpy(hdr_block, filename);
    sendfile(1);
}

/*
 * send a file using the XMODEM, YMODEM or YMODEM Batch protocol
 */

sendfile(hdr_flag)
int hdr_flag;
{
    int partial, blocks, sectnum, attempts, status, checksum, *fd, i, j;
    char sector[1026], r_char, chk_mode;
    unsigned int send_size;

    if (protocol != YMODEMBATCH)
    {
        open_window(GFN - 1, 9, 50, 3);
        gotorc(GFN, 10);
        prompt("Enter filename: ",filename, 32);
        if (filename[0] == '\0')
            return;
        close_window();
    }
    else
    {
        for (i = 0; i < 128; i++)
            sector[i] = hdr_block[i];
    }

    if (!hdr_flag)
    {
        if ((fd = fopen(filename,r_str)) == ERROR)
        {
            open_window(GFN - 1, 9, 50, 3);
            gotorc(GFN, 10);
            fprintf(stderr, "Can't open %s for read\7",filename);
            getanykey();
            close_window();
            return;
        }
        sectnum = 1;
    }
    else
        sectnum = 0;
    tot_bytes = 0;
    if (protocol != YMODEMBATCH)
        send_screen();
    clr_line(PROTOCOL, ERRORCOL, 16);
    fprintf(stderr, proto_string);
    clr_line(FNAME, ERRORCOL, 16);
    fprintf(stderr, filename);
    blocks = 0;
    attempts = 0;
    if (!hdr_flag)
    {
        clr_line(STATUSROW, ERRORCOL, 16);
        fprintf(stderr, "Awaiting NAK");
        if ((protocol == YMODEMBATCH) || (protocol == YMODEM))
            send_size = 1024;
        else
            send_size = 128;
    }
    chk_mode = 0;
    while ((attempts < RETRYMAX) && (chk_mode == 0))
    {
        switch (chk_mode = readchar(15))
        {
        case 'K':
            chk_mode = 0;
            send_size = 1024;
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "1K Blocks");
            break;
        case NAK:
        case CRC:
            break;
        default:
            chk_mode = 0;
            attempts++;
            break;
        }
    }
    if (attempts >= RETRYMAX)
    {
        clr_line(WHYROW, ERRORCOL, 16);
        fprintf(stderr, "Timed out");
        clr_line(STATUSROW, ERRORCOL, 16);
        fprintf(stderr, "Aborted\7\7");
        fclose(fd);
        return;
    }
    if ((chk_mode == CRC) && (protocol == XMODEM))
    {
        clr_line(PROTOCOL, ERRORCOL, 16);
        fprintf(stderr, "XMODEM CRC");
    }
    clr_line(STATUSROW, ERRORCOL, 16);
    attempts = 0;
    partial = 0;
    do
        {
        if (partial == 0)
        {
            if (!hdr_flag)
            {
                for (i = 0; i < 1024; i++)
                    sector[i] = '\0';
                status = fread(sector, 1, send_size, fd);
            }
            else
                status = send_size = 128;
            if ((send_size == 1024) && (status < 1024))
            {
                send_size = 128;
                partial = 1;
            }
        }
        if (status <= 0)
            break;
        attempts = 0;
        do
            {
            if (rdy())
            {
                if (rawget() == 0x1b)
                {
                    for (i = 0; i < 8; i++)
                        sendchar(CAN);
                    for (i = 0; i < 8; i++)
                        sendchar(0x08);
                    clr_line(WHYROW, ERRORCOL, 16);
                    fprintf(stderr, "Operator abort\7");
                    return();
                }
            }
            crcval = 0;
            crcval = calc_crc(sector, send_size);
            if (send_size == 128)
                sendchar(SOH);
            else
                sendchar(STX);
            sendchar(sectnum & 255);
            sendchar(255 - (sectnum & 255));
            for (j = 0, checksum = 0; j < send_size; j++)
            {
                sendchar(sector[j]);
                checksum = checksum + sector[j];
                checksum = checksum & 255;
            }
            if (chk_mode == NAK)
                sendchar(checksum);
            else
                {
                sendchar((crcval >> 8) & 0x00ff);
                sendchar(crcval & 0x00ff);
            }
            attempts++;
            purgeline();
            r_char = readchar(15);
            switch (r_char)
            {
            case NAK:
                clr_line(STATUSROW, ERRORCOL, 16);
                fprintf(stderr, "Retransmitting");
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "Received NAK\7");
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                break;
            case TIMEOUT:
                clr_line(STATUSROW, ERRORCOL, 16);
                fprintf(stderr, "Retransmitting");
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "Timed out\7");
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                break;
            case ACK:
                if (hdr_flag)
                    return;
                if (send_size == 128)
                    blocks++;
                else
                    blocks += 8;
                tot_bytes += send_size;
                clr_line(BYTESSENT, ERRORCOL, 16);
                fprintf(stderr, "%d", tot_bytes);
                clr_line(BLOCKS, ERRORCOL, 16);
                fprintf(stderr, "%d", blocks);
                clr_line(ERRCNTROW, ERRORCOL, 16);
                sectnum++;
                if (partial)
                {
                    status -= 128;
                    for (i = 0, j = 128; i < 896; i++, j++)
                        sector[i] = sector[j];
                }
                break;
            default:
                clr_line(STATUSROW, ERRORCOL, 16);
                fprintf(stderr, "Retransmitting");
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "BAD [%02x]\7", r_char & 0x00ff);
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                break;
            }
        } 
        while ((r_char != ACK) && (attempts < RETRYMAX));
    } 
    while ((attempts < RETRYMAX) && (status != 0));

    if (attempts >= RETRYMAX)
    {
        clr_line(STATUSROW, ERRORCOL, 16);
        fprintf(stderr, "Aborted");
        clr_line(WHYROW, ERRORCOL, 16);
        fprintf(stderr, "Too Many Errors\7\7");
    }
    else
        {
        attempts = 0;
        while(1)
        {
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "Sending EOT");
            sendchar(EOT);
            purgeline();
            attempts++;
            if ((r_char = readchar(5)) == ACK | attempts >= RETRYMAX)
                break;
            else
            {
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "BAD [%02x]", r_char & 0x0ff);
            }
        }
        if (attempts >= RETRYMAX)
        {
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "Aborted\7\7");
            clr_line(WHYROW, ERRORCOL, 16);
            fprintf(stderr, "No ACK to EOT\7");
        }
        else
        {
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "Complete\7");
        }
    }
    fclose(fd);
}

/*
 * timed read of the modem port
 */

readchar(seconds)
int seconds;
{
    char data;
    char status;

    seconds = seconds * speed_adj;
    while (1)
    {
        status = dvr_istat(modem_dev);
        if (status | (seconds == 0))
            break;
        seconds--;
    }
    if (seconds == 0)
        return(TIMEOUT);
    return(dvr_gcne(modem_dev) & 0x0ff);
}

/*
 * send a character
 */

sendchar(data)
char data;
{
    while(1)
        if (dvr_ostat(modem_dev))
            break;
    dvr_putc(modem_dev, data);
}

/*
 * wait for an idle line
 */

idle()
{
    while (readchar(1) != TIMEOUT);
}

/*
 * set up the file characteristics
 * for Xmodem transfers
 */

set_file()
{
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter file mode [Ascii/Binary/Cpm]",answer, 20);
    close_window();
    answer[0] = tolower(answer[0]);
    if (answer[0] == 'b')
    {
        file_mode = BINARY;
        r_str = RB;
        w_str = WB;
    }
    else if (answer[0] == 'c')
    {
        file_mode = CPM;
        r_str = RA;
        w_str = WB;
    }
    else
        {
        file_mode = ASCII;
        r_str = RA;
        w_str = WA;
    }
}

purgeline()
{
    int c;

    while (dvr_istat(modem_dev))
        c = dvr_gcne(modem_dev);
}

clrscrn()
{
    putc(27, stderr);
    putc('*', stderr);
}

menu()
{
    int b_size, b_avail, b_used;
    int c;

    b_size = memend - buf_base;
    b_avail = memend - buf_ptr;
    b_used = buf_ptr - buf_base;
    getime(&now);
    open_window(0,0,80,24);
    gotorc(2,20);
    fprintf(stderr, "EZMPlus 68000 Modem Program Version %s", VERSION);
    gotorc(3,20);
    fprintf(stderr, "current date and time: %02d/%02d/%02d %02d:%02d:%02d",
                                   now.t_month,
                                   now.t_day,
                                   now.t_year,
                                   now.t_hour,
                                   now.t_minute,
                                   now.t_second);
    gotorc(5,9);
    fprintf(stderr, "F1    = Auto Dialer");
    gotorc(6,9);
    fprintf(stderr, "F2    = Baud rate select      [%d]", baud_rate * 100);
    gotorc(7,9);
    fprintf(stderr, "F3    = Capture buffer toggle %s",capture?"[ON] ":"[OFF]");
    fprintf(stderr, " %d/%d", b_used, b_avail);
    gotorc(8,9);
    fprintf(stderr, "F4    = Disk Directory");
    gotorc(9,9);
    fprintf(stderr, "F5    = File mode select      [%s]", fm_str[file_mode]);
    gotorc(10,9);
    fprintf(stderr, "F6    = Block size toggle     ");
    if (recv_size == 1024)
        fprintf(stderr, "[1024]");
    else
        fprintf(stderr, "[128]");
    gotorc(11,9);
    fprintf(stderr, "F7    = Receive mode toggle   ");
    if (recv_mode == CRC)
        fprintf(stderr, "[CRC]");
    else
        fprintf(stderr, "[CHECKSUM]");
    gotorc(12,9);
    fprintf(stderr, "F8    = Name new device       [%s]", device_name);
    gotorc(13,9);
    fprintf(stderr, "F9    = Option file edit");
    gotorc(14,9);
    fprintf(stderr, "F10   = View capture buffer");
    gotorc(15,9);
    fprintf(stderr, "Pg Dn = Recieve file");
    gotorc(16,9);
    fprintf(stderr, "Pg Up = Send file");
    gotorc(17,9);
    fprintf(stderr, "ALT-X = Quit to DOS");
    gotorc(18,9);
    fprintf(stderr, "ALT-C = Clear screen");
    gotorc(19,9);
    fprintf(stderr, "ALT-H = Help screen (you're lookin at it)");
    gotorc(21,9);
    fprintf(stderr, "Enter command: ");
    c = rawget();
    close_window();
    hot_key(c & 0x00ff0000);
}

terminal(flag)
int flag;
{
    int c, b_size, b_avail, b_used;
    char *cp;

    b_size = memend - buf_base;
    b_avail = memend - buf_ptr;
    b_used = buf_ptr - buf_base;

    ESC_Seq_State = 0;

    protocol = COMPUSERVE;
    proto_string = cis_b_protocol;

    getime(&now);
    if (flag)
    {
        clrscrn();
        fprintf(stderr,
                "EZMPlus 68000 Modem Program Ver %s date: %02d/%02d/%02d",
                VERSION,
                now.t_month,
                now.t_day,
                now.t_year);
         
        fprintf(stderr, " time: %02d:%02d:%02d\n",
                now.t_hour, now.t_minute, now.t_second);
        fprintf(stderr, "Buffer size = %d Available = %d Used = %d\n",
                b_size,b_avail,b_used);
        fprintf(stderr, "Use ALT-H for help screen\n\n");
        menu();
    }
    while (1)
    {
        if (rdy())
        {
            c = rawget();
            if (((c & alt_key) == alt_key) || (( c & 0x000000ff) == 0))
            {
                hot_key(c & 0x00ff0000);
                while (window_level)
                    close_window();
            }
            else
                dvr_putc(modem_dev,c & 0x007f);
        }
        if (dvr_istat(modem_dev))
        {
            c = dvr_gcne(modem_dev) & 127;
            if (protocol == COMPUSERVE)
            {
                switch(ESC_Seq_State)
                {
                    case 0:
                        switch (c)
                        {
                            case ESC:
                                ESC_Seq_State = 1;
                                break;
                            case ENQ:
                                Write_Modem(DLE);
                                Write_Modem('0');
                                break;
                            case DLE:
                                ESC_Seq_State = 2;
                                break;
                            default:
                                rawput(c);
                                if ((capture) & (buf_ptr < memend))
                                    *buf_ptr++ = c;
                        }
                        break;
                    case 1:
                        switch (c)
                        {
                            case 'I':
                                cp = VIDTEX_Response;
                                while (*cp != 0)
                                    rawput(*cp++);
                                ESC_Seq_State = 0;
                                break;
                            default:
                                rawput(ESC);
                                rawput(c);
                                ESC_Seq_State = 0;
                                break;
                        }
                        break;
                    case 2:
                        if (c == 'B')
                        {
                            if (!Transfer_File())
                            {
                                clr_line(STATUSROW, ERRORCOL, 16);
                                fprintf(stderr, "Aborted\7\7");
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Failed\7");
                                while (window_level)
                                    close_window();
                            }
                            else
                            {
                                clr_line(STATUSROW, ERRORCOL, 16);
                                fprintf(stderr, "Completed\7\7");
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Successfull\7");
                                while (window_level)
                                    close_window();
                            }
                        }
                        else
                        {
                            rawput(ESC);
                            rawput(c);
                        }
                        ESC_Seq_State = 0;
                        break;
                }
            }
            else
            {
                rawput(c);
                if ((capture) & (buf_ptr < memend))
                    *buf_ptr++ = c;
            }
        }
    }
    if (buf_ptr != buf_base)
        save_buf();
}

pro_select()
{
    char c;

    open_window(PROTOCOL - 1, SCROFFSET - 1, 20, 14);
    gotorc(PROTOCOL, SCROFFSET);
    fprintf(stderr, "1)   XMODEM");
    gotorc(PROTOCOL+1, SCROFFSET);
    fprintf(stderr, "2)   YMODEM");
    gotorc(PROTOCOL+2, SCROFFSET);
    fprintf(stderr, "3)   YMODEM Batch");
    gotorc(PROTOCOL+3, SCROFFSET);
    fprintf(stderr, "4)   Kermit");
    gotorc(PROTOCOL+4, SCROFFSET);
    fprintf(stderr, "5)   Telink");
    gotorc(PROTOCOL+5, SCROFFSET);
    fprintf(stderr, "6)   MODEM7");
    gotorc(PROTOCOL+6, SCROFFSET);
    fprintf(stderr, "7)   ASCII");
    gotorc(PROTOCOL+7, SCROFFSET);
    fprintf(stderr, "8)   COMPUSERVE B");
    gotorc(PROTOCOL+8, SCROFFSET);
    fprintf(stderr, "9)   WXMODEM");
    gotorc(PROTOCOL+9, SCROFFSET);
    fprintf(stderr, "ESC  Cancel");
    gotorc(PROTOCOL+11, SCROFFSET);
    fprintf(stderr, "Protocol: ");
    c = rawget();
    close_window();
    switch (c)
    {
        case '1':
            protocol = XMODEM;
            proto_string = x_protocol;
            break;
        case '2':
            protocol = YMODEM;
            proto_string = y_protocol;
            recv_size = 1024;
            recv_mode = CRC; 
            break;
        case '3':
            protocol = YMODEMBATCH;
            proto_string = ybatch_protocol;
            recv_size = 1024;
            recv_mode = CRC;
            break;
        case '8':
            protocol = COMPUSERVE;
            proto_string = cis_b_protocol;
            break;
        case '4':
        case '5':
        case '6':
        case '7':
        case '9':
            gotorc(PROTOCOL+11, SCROFFSET);
            fprintf(stderr, "\7\7Not yet implemented");
            getanykey();
            break;
        default:
            return(0);
            break;
    }
    return(1);
}

baud_select()
{
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter baud rate: ", ascii_br, 20);
    close_window();
    if (ascii_br[0] == '\0')
        return();
    baud_rate =  atoi(ascii_br) / 100;
    uvtable->device[modem_dev].ttyinfo.baudrt = baud_rate;
    dvr_init(modem_dev);
}

speed_select()
{
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter speed factor: ", ascii_sa, 20);
    close_window();
    if (ascii_sa[0] == '\0')
        return();
    speed_adj = atoi(ascii_sa);
}

view()
{
    char *i;

    i = buf_base;
    while(i < buf_ptr)
        putc(*i++, stderr);
}

save_buf()
{
    char *i, answer[20];
    int *fd;

    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Save capture buffer? ", answer, 20);
    close_window();
    if ((toupper(answer[0]) == 'N') || (answer[0] == '\0'))
        return;
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter filename: ",filename, 32);
    close_window();
    if (filename[0] == '\0')
        return;

    /* try to open the save file */

    if ((fd = fopen(filename,"w")) == ERROR)
    {
        fprintf(stderr, "Can't open %s for write\n\7",filename);
        return;
    }
    i = buf_base;
    while (i < buf_ptr)
        fwrite(i++, 1, 1, fd);
    buf_ptr = buf_base;
    fclose(fd);
}

test_speed()
{
    struct sgtbuf s_time;
    struct sgtbuf e_time;

    open_window(10,10, 60, 3);
    gotorc(11, 11);
    fprintf(stderr, "This should take 30 second - please wait");

    getime(&s_time);
    readchar(30);
    getime(&e_time);

    x = (unsigned int)e_time.t_hour * 3600 +
        (unsigned int)e_time.t_minute * 60 +
        (unsigned int)e_time.t_second;

    y = (unsigned int)s_time.t_hour * 3600 +
        (unsigned int)s_time.t_minute * 60 +
        (unsigned int)s_time.t_second;

    clr_line(11,11,58);
    fprintf(stderr, "For a value of %d 30 seconds took %d seconds",
        speed_adj, (x - y));
    close_window();
    getanykey();
}    

name_device()
{
    char temp[32];
    int i;

    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter device name: ", temp, 32);
    close_window();
    if (temp[0] == '\0')
        return();
    str_upper(temp);
    temp[4] = '\0';

    for (i = 0; i < 8; i++)
    {
        if (strncmp(temp, uvtable->device[i].devnam, 4) == 0)
        {
            modem_dev = i;
            break;
        }
    }
    if (i != 8)
    {
        strcpy(device_name, temp);
        dvr_init(modem_dev);
    }
    else
    {
        open_window(GFN - 1, 9, 50, 3);
        gotorc(GFN, 10);
        fprintf(stderr, "Device not found - nothing changed");
        getanykey();
        close_window();
    }
}

usage()
{
    clrscrn();
    fprintf(stderr, "%s\n",instruct1);
    fprintf(stderr, "%s\n",instruct2);
    fprintf(stderr, "%s\n",instruct3);
    fprintf(stderr, "%s\n",instruct4);
    fprintf(stderr, "%s\n",instruct5);
    fprintf(stderr, "%s\n",instruct6);
    fprintf(stderr, "%s\n",instruct7);
    fprintf(stderr, "%s\n",instruct8);
    fprintf(stderr, "%s\n",instruct9);
    fprintf(stderr, "%s\n",instruct10);
    fprintf(stderr, "%s\n",instruct11);
    fprintf(stderr, "%s\n",instruct12);
    fprintf(stderr, "%s\n",instruct13);
    fprintf(stderr, "%s\n",instruct14);
    fprintf(stderr, "%s\n",instruct15);
    fprintf(stderr, "%s\n",instruct16);
    fprintf(stderr, "%s\n",instruct17);
    fprintf(stderr, "%s\n",instruct18);
    fprintf(stderr, "%s\n",instruct19);
    fprintf(stderr, "%s",instruct20);
}

int dial_start =  1;

dump_phone()
{
    int i, j, k;

    dial_start = (dial_start > 41 ? 41 : dial_start);
    for (i = 0, j = dial_start - 1, k = 4; i < 10; i++, j++, k++)
    {
        gotorc(k, 3);
        fprintf(stderr, "%2d-",         dial_start + i);
        fprintf(stderr, " %s",          name[j]);
        fprintf(stderr, "   %s",        phone_number[j]);
        fprintf(stderr, "  %s",         baud[j]);
        fprintf(stderr, "          %s", cmd_file[j]);
    }
}

left_copystr(s1, s2, len)
char *s1, *s2;
int len;
{
    while ((*s1++ = *s2++) && --len);
    if (len)
    {
        --s1;
        while (len)
        {
            *s1++ = 0x20;
            len--;
        }
        *s1 = 0x00;
    }
}

right_copystr(s1, s2, len)
char *s1, *s2;
int len;
{
    int diff;

    diff = len > strlen(s2) ? len - strlen(s2) : 0;
    if (diff)
    {
        while (diff)
        {
            *s1++ = ' ';
            diff--;
        }
        while(*s1++ = *s2++);
    }
    else
        left_copystr(s1, s2, len);
}

wait_modem()
{
    int c, i, wait_amount;

    idle();
    wait_amount = atoi(connect_wait);
    i = 0;
    while ((c = readchar(1)) == TIMEOUT)
    {
        if (i++ == wait_amount)
        {
            gotorc(0,79);
            rawput('*');
            break;
        }
        if (rdy())
        {
            if (rawget() == 0x1b)
            {
                sendchar('\n');
                gotorc(0,78);
                rawput('+');
                return(0);
            }
        }
    }
    if (i < wait_amount)
    {
        i = 0;
        if (c >= 'A')
        {
            rawput(c);
            reply[i++] = c;
        }
        while ((c = readchar(5)) != -1)
        {
            if (rdy())
            {
                if (rawget() == 0x1b)
                {
                    sendchar('\n');
                    gotorc(0,77);
                    rawput('-');
                    return(0);
                }
            }
            if (i == 0)
            {
                if (c >= 'A')
                {
                    rawput(c);
                    reply[i++] = c;
                }
            }
            else
                {
                if ((c != 0x0d) && (c != 0x0a))
                {
                    rawput(c);
                    reply[i++] = c;
                }
                else
                    {
                    gotorc(0,76);
                    rawput('=');
                    reply[i++] = '\0';
                    break;
                }
            }
        }
        if (strncmp(reply, connect_str, strlen(connect_str)) == 0)
        {
            gotorc(0,75);
            rawput('|');
            return(1);
        }
        else
            {
            gotorc(0,74);
            rawput('?');
            return(0);
        }
    }
    else
        {
        gotorc(0,73);
        rawput('.');
        return(0);
    }
}

prnt_str(str)
char *str;
{
    while(*str)
        dvr_putc(print_dev, *str++);
}

auto_dial()
{
    char c;
    char rate[6], string[32];
    int  i, j, k, entry;

    ld_codes[0] = minus_flag ? '-' : ' ';
    ld_codes[1] = plus_flag  ? '+' : ' ';
    ld_codes[2] = atsign_flag? '@' : ' ';
    ld_codes[3] = pound_flag ? '#' : ' ';
    ld_codes[4] = '\0';

    open_window(0,0,80,24);
    gotorc(1, 22);
    fprintf(stderr,"D I A L I N G    D I R E C T O R Y");
    gotorc(2, 1);
    fprintf(stderr,"                Name                Number");
    fprintf(stderr,"        Baud            CMD File");
    dump_phone();
    gotorc(15, 1);
    fprintf(stderr," ==>            R Revise         M Manual Dialing      ");
    fprintf(stderr,"Entry to Dial");
    gotorc(16, 1);
    fprintf(stderr,"                P LD Codes       D Delete Entry        ");
    fprintf(stderr,"F Find");
    gotorc(17, 1);
    fprintf(stderr,"                ^C Page Down     L Print Entries       ");
    fprintf(stderr,"^X/^E Scroll");
    gotorc(18, 1);
    fprintf(stderr,"                ^R Page Up       ^Q Quick Page         ");
    fprintf(stderr,"ESC Exit");
    gotorc(20, 1);
    fprintf(stderr,"   Modem Dial Cmd: %-20s", mod_dial_str);
    fprintf(stderr,"      LD Codes Active: %-4s", ld_codes);
    gotorc(21, 1);
    fprintf(stderr,"  Dial Cmd Suffix: %-14s", dial_cmd_suff);
    fprintf(stderr," Device Driver Active: %-4s", device_name);
    do
    {
        clr_line(22,1,78);
        gotorc(22,34);
        fprintf(stderr,"AUTO DIALER");
        clr_line(15, 6, 11);
        c = toupper(rawget() & 0x000000ff);
        switch (c)
        {
        case 'R':                       /* Revise entry   */
            clr_line(22,1,78);
            fprintf(stderr, "Entry to revise:          (Number, #, -, +, @)");
            gotorc(22, 18);
            c = rawget();
            if (isdigit(c))
            {
                string[0] = c;
                rawput(c & 0x7f);
                if (getstr(&string[1], 32) == -1)
                    break;
                entry = atoi(string) != 0 ? atoi(string) - 1: 0;
                entry = entry > 50 ? 50 : entry;
                clr_line(22,1,78);
                prompt("Name: ", string, 32);
                if (strlen(string))
                {
                    ezmphone_changed = 1;
                    left_copystr(name[entry], string, 24);
                }
                clr_line(22,1,78);
                prompt("Phone Number: ", string, 32);
                if (strlen(string))
                {
                    ezmphone_changed = 1;
                    right_copystr(phone_number[entry], string, 14);
                }
                clr_line(22,1,78);
                prompt("Baud rate: ", string, 32);
                if (strlen(string))
                {
                    ezmphone_changed = 1;
                    right_copystr(baud[entry], string, 5);
                }
            }
            else
                {
                switch(c)
                {
                case '-':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '-': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(minus, string);
                    minus_flag = strlen(minus)?1:0;
                    break;
                case '+':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '+': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(plus, string);
                    plus_flag = strlen(plus)?1:0;
                    break;
                case '@':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '@': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(atsign, string);
                    atsign_flag = strlen(atsign)?1:0;
                    break;
                case '#':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '#': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(pound, string);
                    pound_flag = strlen(pound)?1:0;
                    break;
                default:
                    break;
                }
                ld_codes[0] = minus_flag ? '-' : ' ';
                ld_codes[1] = plus_flag  ? '+' : ' ';
                ld_codes[2] = atsign_flag? '@' : ' ';
                ld_codes[3] = pound_flag ? '#' : ' ';
                ld_codes[4] = '\0';
                gotorc(20, 1);
                fprintf(stderr, "   Modem Dial Cmd: %-20s", mod_dial_str);
                fprintf(stderr, "      LD Codes Active: %-4s", ld_codes);
            }

            if (ezmphone_changed)
            {
                clr_line(22,1,78);
                prompt("Save changes? ", string, 32);
                if (toupper(string[0]) == 'Y')
                {
                    ezmphone_changed = 0;
                    dial_fd = fopen(phone_list, "wb");
                    for (i = 0; i < 50; i++)
                    {
                        fwrite(name[i],         25, 1, dial_fd);
                        fwrite(phone_number[i], 15, 1, dial_fd);
                        fwrite(baud[i],          6, 1, dial_fd);
                        fwrite(cmd_file[i],      9, 1, dial_fd);
                    }
                    fwrite(minus, 15, 1, dial_fd);
                    fwrite(plus,  15, 1, dial_fd);
                    fwrite(atsign,15, 1, dial_fd);
                    fwrite(pound, 15, 1, dial_fd);
                    fclose(dial_fd);
                }
            }
            dump_phone();
            break;
        case 'M':                       /* Manual Dialing */
            clr_line(22,1,78);
            fprintf(stderr, "Enter phone number: ");
            if (getstr(string, 32) <= 0)
                break;
            clr_line(22,1,78);
            fprintf(stderr, "Dialing %s%s%s ",mod_dial_str,string,dial_cmd_suff);
            j = 0;
            while (mod_dial_str[j])
                sendchar(mod_dial_str[j++]);
            j = 0;
            while (string[j])
            {
                if (isdigit(string[j]))
                    sendchar(string[j++]);
                else
                    {
                    k = 0;
                    switch (string[j++])
                    {
                    case '-':
                        while(minus[k])
                            sendchar(minus[k++]);
                        break;
                    case '+':
                        while(plus[k])
                            sendchar(plus[k++]);
                        break;
                    case '@':
                        while(atsign[k])
                            sendchar(atsign[k++]);
                        break;
                    case '#':
                        while(pound[k])
                            sendchar(pound[k++]);
                        break;
                    default:
                        break;
                    }
                }
            }
            j = 0;
            while (dial_cmd_suff[j])
                sendchar(dial_cmd_suff[j++]);
            sendchar(0x0d);
            if (wait_modem())
            {
                if (window_level)
                    close_window();
                fprintf(stderr, "\n%s", reply);
                return();
            }
            break;
        case 'P':                       /* LD codes       */
            open_window(7,0,34,6);
            gotorc(8, 1);
            fprintf(stderr, "\t- = %s", minus);
            gotorc(9, 1);
            fprintf(stderr, "\t+ = %s", plus);
            gotorc(10, 1);
            fprintf(stderr, "\t@ = %s", atsign);
            gotorc(11, 1);
            fprintf(stderr, "\t# = %s", pound);
            gotorc(12, 1);
            rawget();
            close_window();
            dump_phone();
            break;
        case 'D':                       /* Delete entry   */
            clr_line(22,1,78);
            fprintf(stderr, "Entry to delete: ");
            c = rawget();
            if (isdigit(c))
            {
                string[0] = c;
                rawput(c & 0x7f);
                if (getstr(&string[1], 32) == -1)
                    break;
                entry = atoi(string) != 0 ? atoi(string) - 1: 0;
                entry = entry > 50 ? 50 : entry;
                strcpy(name[entry],"........................");
                strcpy(phone_number[entry],". ... ...-....");
                strcpy(baud[entry]," 1200");
                strcpy(cmd_file[entry],"        ");
                clr_line(22,1,78);
                prompt("Save changes? ", string, 32);
                if (toupper(string[0]) == 'Y')
                {
                    ezmphone_changed = 0;
                    dial_fd = fopen(phone_list, "wb");
                    for (i = 0; i < 50; i++)
                    {
                        fwrite(name[i],         25, 1, dial_fd);
                        fwrite(phone_number[i], 15, 1, dial_fd);
                        fwrite(baud[i],          6, 1, dial_fd);
                        fwrite(cmd_file[i],      9, 1, dial_fd);
                    }
                    fwrite(minus, 15, 1, dial_fd);
                    fwrite(plus,  15, 1, dial_fd);
                    fwrite(atsign,15, 1, dial_fd);
                    fwrite(pound, 15, 1, dial_fd);
                    fclose(dial_fd);
                }
            }
            dump_phone();
            break;
        case 'F':                       /* Find entry     */
            clr_line(22,1,78);
            fprintf(stderr, "Name to search for: ");
            if (getstr(string, 25) <= 0)
                break;
            for (i = 0; i < 50; i++)
                if (strncmp(string, name[i], strlen(string)) == 0)
                    break;
            if (i < 50)
            {
                dial_start = i + 1;
                dump_phone();
            }
            break;
        case 'L':                       /* Print entries  */
            prnt_str(crlf_str);
            for (i = 0; i < 50; i++)
            {
                sprintf(string, "   %2d-", i);
                prnt_str(string);
                sprintf(string, " %s", name[i]);
                prnt_str(string);
                sprintf(string, "   %s", phone_number[i]);
                prnt_str(string);
                sprintf(string, "  %s", baud[i]);
                prnt_str(string);
                sprintf(string, "          %s", cmd_file[i]);
                prnt_str(string);
                prnt_str(crlf_str);
            }
            break;
        case 0x03:                      /* ^C Page down   */
            dial_start += 10;
            dump_phone();
            break;
        case 0x12:                      /* ^R page up     */
            dial_start = (dial_start < 11 ? 1 : dial_start - 10);
            dump_phone();
            break;
        case 0x05:                      /* ^E scroll up   */
            dial_start = (dial_start > 1 ? --dial_start : 1);
            dump_phone();
            break;
        case 0x18:                      /* ^X scroll down */
            dial_start = (dial_start < 41 ? ++dial_start : 41);
            dump_phone();
            break;
        case 0x11:                      /* ^Q quick page  */
            switch (rawget() & 0x1f)
            {
            case 0x12:
                dial_start = 1;
                break;
            case 0x03:
                dial_start = 41;
                break;
            default:
                break;
            }
            dump_phone();
            break;
        case 0x1b:                      /* ESC - exit     */
            break;
        default:                        /* if numeric - Entry to dial */
            if (isdigit(c))
            {
                rawput(c & 0x7f);
                string[0] = c;
                if (getstr(&string[1], 32) == -1)
                    break;
                entry = atoi(string) != 0 ? atoi(string) - 1: 0;
                entry = entry > 50 ? 50 : entry;
                for (i = 0, j = 0; i < 14; i++)
                    if (isdigit(phone_number[entry][i]))
                        string[j++] = phone_number[entry][i];
                string[j] = '\0';
                left_copystr(rate, baud[entry], 5);
                baud_rate =  atoi(rate) / 100;
                uvtable->device[modem_dev].ttyinfo.baudrt = baud_rate;
                dvr_init(modem_dev);
                clr_line(22,1,78);
                fprintf(stderr, "Dialing %s%s%s ",mod_dial_str,string,dial_cmd_suff);
                j = 0;
                while (mod_dial_str[j])
                    sendchar(mod_dial_str[j++]);
                j = 0;
                while (phone_number[entry][j])
                {
                    if (isdigit(phone_number[entry][j]))
                        sendchar(phone_number[entry][j++]);
                    else
                        {
                        k = 0;
                        switch (phone_number[entry][j++])
                        {
                        case '-':
                            while(minus[k])
                                sendchar(minus[k++]);
                            break;
                        case '+':
                            while(plus[k])
                                sendchar(plus[k++]);
                            break;
                        case '@':
                            while(atsign[k])
                                sendchar(atsign[k++]);
                            break;
                        case '#':
                            while(pound[k])
                                sendchar(pound[k++]);
                            break;
                        default:
                            break;
                        }
                    }
                }
                j = 0;
                while (dial_cmd_suff[j])
                    sendchar(dial_cmd_suff[j++]);
                sendchar(0x0d);
                if (wait_modem())
                {
                    if (window_level)
                        close_window();
                    fprintf(stderr, "\n%s", reply);
                    return();
                }
            }
            break;
        }
    } 
    while (c != 0x1b);            
}

save_dflt()
{
    char string[32];

    clr_line(14,10,50);
    prompt("Save changes? ", string, 32);
    if (toupper(string[0]) == 'Y')
    {
        opt_fd = fopen(opt_file, "wb");
        fwrite(mod_dial_str, 21, 1, opt_fd);
        fwrite(ld_codes,      5, 1, opt_fd);   /* ld_codes */
        fwrite(dial_cmd_suff,15, 1, opt_fd);   /* dial_cmd_suff */
        fwrite(connect_str,  32, 1, opt_fd);
        fwrite(connect_wait, 10, 1, opt_fd);
        fwrite(redial_pause, 10, 1, opt_fd);
        fwrite(device_name,   5, 1, opt_fd);
        fwrite(printer,       2, 1, opt_fd);
        fclose(opt_fd);
    }
}

edit_options()
{
    char string[32];
    int dflt_changed;

    open_window(0, 8, 60, 16);
    gotorc(2,23);
    fprintf(stderr, "O P T I O N S   S E L E C T I O N");
    gotorc(6, 10);
    fprintf(stderr, "1. Modem Dial String:   %s", mod_dial_str);
    gotorc(7, 10);
    fprintf(stderr, "2. Dial Command Suffix: %s", dial_cmd_suff);
    gotorc(8, 10);
    fprintf(stderr, "3. Connect String:      %s", connect_str);
    gotorc(9, 10);
    fprintf(stderr, "4. Connect Wait Time:   %s", connect_wait);
    gotorc(10, 10);
    fprintf(stderr, "5. Redial Pause Time:   %s", redial_pause);
    gotorc(11, 10);
    fprintf(stderr, "6. Device Name:         %s", device_name);
    gotorc(12, 10);
    fprintf(stderr, "7. Printer Device:      %s", printer);
    dflt_changed = 0;
    while(1)
    {
        gotorc(14, 10);
        fprintf(stderr, "Enter option number to change (ESC to exit): ");
        if (getstr(string, 1) <= 0)
        {
            if (dflt_changed)
                save_dflt();
            return();
        }
        switch (string[0])
        {
        case '1':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter modem dial string: ");
            if (getstr(string, 20) <= 0)
                break;
            strcpy(mod_dial_str, string);
            dflt_changed = 1;
            clr_line(6, 10, 57);
            fprintf(stderr, "1. Modem Dial String:   %s", mod_dial_str);
            break;
        case '2':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter dial command suffix: ");
            if (getstr(string, 14) <= 0)
                break;
            strcpy(dial_cmd_suff, string);
            dflt_changed = 1;
            clr_line(7, 10, 57);
            fprintf(stderr, "2. Dial Command Suffix: %s", dial_cmd_suff);
            break;
        case '3':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter connect string: ");
            if (getstr(string, 31) <= 0)
                break;
            strcpy(connect_str, string);
            dflt_changed = 1;
            clr_line(8, 10, 57);
            fprintf(stderr, "3. Connect String:      %s", connect_str);
            break;
        case '4':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter connect wait time: ");
            if (getstr(string, 9) <= 0)
                break;
            strcpy(connect_wait, string);
            dflt_changed = 1;
            clr_line(9, 10, 57);
            fprintf(stderr, "4. Connect Wait Time:   %s", connect_wait);
            break;
        case '5':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter redial pause: ");
            if (getstr(string, 9) <= 0)
                break;
            strcpy(redial_pause, string);
            dflt_changed = 1;
            clr_line(10, 10, 57);
            fprintf(stderr, "5. Redial Pause Time:   %s", redial_pause);
            break;
        case '6':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter modem device name: ");
            if (getstr(string, 4) <= 0)
                break;
            strcpy(device_name, string);
            dflt_changed = 1;
            clr_line(11, 10, 57);
            fprintf(stderr, "6. Device Name:         %s", device_name);
            break;
        case '7':
            clr_line(14, 10, 57);
            fprintf(stderr, "Enter printer device number: ");
            if (getstr(string, 1) <= 0)
                break;
            strcpy(printer, string);
            print_dev = atoi(string);
            dflt_changed = 1;
            clr_line(12, 10, 57);
            fprintf(stderr, "7. Printer Device:      %s", printer);
            break;
        case 0x1b:
            if (dflt_changed)
                save_dflt();
            return();
            break;
        default:
            break;
        }
    }
}

hot_key(which_key)
int which_key;
{
    char drive, c;
    char temp[32];
    int  d_row, i, j, k;

    baud_rate = uvtable->device[modem_dev].ttyinfo.baudrt;
    switch (which_key)
    {
        case f1_key:
            auto_dial();
            break;
        case f2_key:
            baud_select();
            break;
        case f3_key:
            if (capture)
            {
                if (buf_ptr != buf_base)
                    save_buf();
                capture = 0;
            }
            else
                capture = 1;
            break;
        case f4_key:
            open_window(GFN - 1, 9, 50, 3);
            gotorc(GFN, 10);
            prompt("Enter filespec: ", mask, 32);
            if (mask[0] == '\0')
                return();
            close_window();
            j = 1;
            k = 0;
            open_window(0,0,80,24);
            d_row = 1;
            gotorc(d_row++, 1);
            if (search_first(mask, filename))
            {
                fprintf(stderr, "%-13s", filename);
                while (search_next(mask, filename))
                {
                    if (!(j++ % 5))
                    {
                        k++;
                        if (k == 21)
                        {
                            more(d_row);
                            k = 0;
                            d_row = 1;
                            for (i = 1; i < 23; i++)
                                clr_line(i, 1, 78);
                        }
                        gotorc(d_row++, 1);
                    }
                    else
                        fprintf(stderr, "| ");
                    fprintf(stderr, "%-13s", filename);
                }
                close(dir_fd);
            }
            last_page(d_row);
            close_window();
            break;
        case f5_key:
            set_file();
            break;
        case f6_key:
            if (recv_size == 1024)
               recv_size = 128;
            else
            {
               recv_mode = CRC;
               recv_size = 1024;
            }
            break;
       case f7_key:
            if (recv_mode == CRC)
            {
                recv_size = 128;
                recv_mode = NAK;
            }
            else
                recv_mode = CRC;
            break;
       case f8_key:
            name_device();
            break;
       case f9_key:
           edit_options();
           break;
       case f10_key:
           view();
           break;
       case x_key:
           open_window(2,2,13,4);
           gotorc(3,3);
           fprintf(stderr, "EXIT TO DOS");
           gotorc(4,3);
           fprintf(stderr, " [Y or N?] ");
           c = rawget();
           if (toupper(c) == 'Y')
           {
               uvtable->device[0].ttyinfo.pauseb = pause_flag;
               clrscrn();
               exit(0);
           }
           close_window();
           break;
       case pg_dn:
           if (pro_select())
               recvfile();
           break;
       case pg_up:
           if (pro_select())
           {
               if (protocol == YMODEMBATCH)
               {
                   open_window(GFN - 1, 9, 50, 3);
                   gotorc(GFN, 10);
                   prompt("Enter filespec: ", mask, 32);
                   close_window();
                   if (strlen(mask))
                   {
                       send_screen();
                       if (drive = search_first(mask, temp))
                       {
                           strcpy(filename, temp);
                           sendhdr();
                           sprintf(filename, "%c.", drive);
                           strcat(filename, temp);
                           sendfile(0);
                           while (search_next(mask, temp))
                           {
                               strcpy(filename, temp);
                               sendhdr();
                               sprintf(filename, "%c.", drive);
                               strcat(filename, temp);
                               sendfile(0);
                           }
                           close(dir_fd);
                       }
                       strcpy(filename, "");
                       sendhdr();
                   }
                   else
                   {
                       sendchar(CAN);
                       sendchar(CAN);
                   }
               }
               else
                   sendfile(0);
           }
           break;
       case a_key:
           speed_select();
           break;
       case b_key:
           test_speed();
           break;
       case c_key:
           clrscrn();
           break;
       case h_key:
           menu();
           break;
       default:
           fprintf(stderr, "\7\7");
           break;
       }
}

main(argc, argv)
int argc;
char *argv[];
{
    int  i;

    getty(0,&data);
    data.drv_echo  |= RAW;
    setty(0,&data);

    file_mode   = BINARY;
    raw_mode(stdin);
    if ((opt_fd = fopen(opt_file, "rb")) == 0)
    {
        opt_fd = fopen(opt_file, "wb");
        fwrite("ATDT",     5, 1, opt_fd);
        fwrite(nulls,     16, 1, opt_fd);   /* total = 21 for mod_dial_str */
        fwrite(nulls,      5, 1, opt_fd);   /* ld_codes */
        fwrite(nulls,     15, 1, opt_fd);   /* dial_cmd_suff */
        fwrite("CONNECT",  8, 1, opt_fd);
        fwrite(nulls,     24, 1, opt_fd);   /* total = 32 for connect_str */
        fwrite("30",       3, 1, opt_fd);
        fwrite(nulls,      7, 1, opt_fd);   /* total = 10 for connect_wait */
        fwrite("2",        2, 1, opt_fd);
        fwrite(nulls,      8, 1, opt_fd);   /* total = 10 for redial_pause */
        fwrite("MODM",     5, 1, opt_fd);
        fwrite("2",        2, 1, opt_fd);
        fclose(opt_fd);
    }
    opt_fd = fopen(opt_file, "rb");
    fread(mod_dial_str, 21, 1, opt_fd);
    fread(ld_codes,      5, 1, opt_fd);   /* ld_codes */
    fread(dial_cmd_suff,15, 1, opt_fd);   /* dial_cmd_suff */
    fread(connect_str,  32, 1, opt_fd);
    fread(connect_wait, 10, 1, opt_fd);
    fread(redial_pause, 10, 1, opt_fd);
    fread(device_name,   5, 1, opt_fd);
    fread(printer,       2, 1, opt_fd);
    fclose(opt_fd);

    r_str = RB;
    w_str = WB;

    print_dev = atoi(printer);
    uvtable  = vpoint();
    buf_ptr  = malloc(0x40000);
    buf_base = buf_ptr;
    memend   = uvtable->memend;

    speed_adj = 15000;
    capture = 0;
    if (argc != 1)
        strncpy(device_name, argv[1], 4);
    device_name[4] = '\0';
    str_upper(device_name);
    for (i = 0; i < 8; i++)
    {
        if (strncmp(device_name, uvtable->device[i].devnam, 4) == 0)
        {
            modem_dev = i;
            break;
        }
    }
    if (i != 8)
    {
        pause_flag = uvtable->device[0].ttyinfo.pauseb;
        uvtable->device[0].ttyinfo.pauseb = 0;
        if ((dial_fd = fopen(phone_list, "rb")) == 0)
        {
            dial_fd = fopen(phone_list, "wb");
            fwrite("Evenson Consulting      ", 25, 1, dial_fd);
            fwrite("1 817 488-8398", 15, 1, dial_fd);
            fwrite(" 1200", 6, 1, dial_fd);
            fwrite("        ", 9, 1, dial_fd);
            for (i = 1; i < 50; i++)
            {
                fwrite("........................", 25, 1, dial_fd);
                fwrite(". ... ...-....", 15, 1, dial_fd);
                fwrite(" 1200", 6, 1, dial_fd);
                fwrite("        ", 9, 1, dial_fd);
            }
            fwrite(minus, 15, 1, dial_fd);
            fwrite(plus,  15, 1, dial_fd);
            fwrite(atsign,15, 1, dial_fd);
            fwrite(pound, 15, 1, dial_fd);
            fclose(dial_fd);
            dial_fd = fopen(phone_list, "rb");
        }
        for (i = 0; i < 50; i++)
        {
            fread(name[i],         25, 1, dial_fd);
            fread(phone_number[i], 15, 1, dial_fd);
            fread(baud[i],          6, 1, dial_fd);
            fread(cmd_file[i],      9, 1, dial_fd);
        }
        fread(minus, 15, 1, dial_fd);
        fread(plus,  15, 1, dial_fd);
        fread(atsign,15, 1, dial_fd);
        fread(pound, 15, 1, dial_fd);
        fclose(dial_fd);
        baud_rate = uvtable->device[modem_dev].ttyinfo.baudrt;
        while(1)
        {
            terminal(1);
            break;
        }
    }
    else
        usage();
}
