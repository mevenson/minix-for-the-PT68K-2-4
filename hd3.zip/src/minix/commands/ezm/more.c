more(row)
int row;
{
    gotorc(row, 1);
    fprintf(stderr, "[More]");
    rawget();
}

