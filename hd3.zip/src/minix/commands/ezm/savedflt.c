save_dflt()
{
    char string[32];

    clr_line(14,10,50);
    prompt("Save changes? ", string, 32);
    if (toupper(string[0]) == 'Y')
    {
        opt_fd = fopen(opt_file, "wb");
        fwrite(mod_dial_str, 21, 1, opt_fd);
        fwrite(ld_codes,      5, 1, opt_fd);   /* ld_codes */
        fwrite(dial_cmd_suff,15, 1, opt_fd);   /* dial_cmd_suff */
        fwrite(connect_str,  32, 1, opt_fd);
        fwrite(connect_wait, 10, 1, opt_fd);
        fwrite(redial_pause, 10, 1, opt_fd);
        fwrite(device_name,   5, 1, opt_fd);
        fwrite(printer,       2, 1, opt_fd);
        fclose(opt_fd);
    }
}

