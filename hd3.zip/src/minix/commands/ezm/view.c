view()
{
    char *i;

    i = buf_base;
    while(i < buf_ptr)
        putc(*i++, stderr);
}

