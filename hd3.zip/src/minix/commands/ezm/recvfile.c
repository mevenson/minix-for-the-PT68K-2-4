/*
 * read a file using the XMODEM, YMODEM or YMODEM Batch protocol
 */

recvfile()
{
    int r_char, curr_size, blocks, sectnum, sectcurr, sectcomp, errors;
    int checksum, r_checksum, errorflag, *fd, i, j;
    int recv_ok;
    char sector[1026];

    if ((protocol == XMODEM) || (protocol == YMODEM))
    {
        open_window(GFN - 1, 9, 50, 3);
        gotorc(GFN, 10);
        prompt("Enter filename: ",filename, 32);
        if (filename[0] == '\0')
            return;
        if ((fd = fopen(filename,w_str)) == ERROR)
        {
            clr_line(GFN, 10, 38);
            fprintf(stderr, "Can't open %s for write\7",filename);
            getanykey();
            return;
        }
    }
    recv_screen();
    clr_line(PROTOCOL, ERRORCOL, 16);
    fprintf(stderr, proto_string);
    if (protocol != YMODEMBATCH)
    {
        clr_line(FNAME, ERRORCOL, 16);
        fprintf(stderr, filename);
    }
    do
    {
        if (protocol == YMODEMBATCH)
        {
            clr_line(ERRCNTROW, ERRORCOL, 16);
            clr_line(WHYROW, ERRORCOL, 16);
            clr_line(BLOCKS, ERRORCOL, 16);
            clr_line(FNAME, ERRORCOL, 16);
            clr_line(BYTESREAD, ERRORCOL, 16);
            clr_line(STATUSROW, ERRORCOL, 16);
        }
        tot_bytes = 0;
        blocks = 0;
        sectnum = errors = 0;
        sendchar(recv_mode);
        do
        {
            errorflag = 0;
            do
            {
                r_char = readchar(10);
                switch (r_char)
                {
                    case STX:
                        curr_size = 1024;
                        errors = 0;
                        errorflag = 0;
                        break;
                    case SOH:
                        curr_size = 128;
                        errors = 0;
                        errorflag = 0;
                        break;
                    case EOT:
                        errors = 0;
                        errorflag = 0;
                        break;
                    case TIMEOUT:
                        errorflag = 1;
                        errors++;
                        clr_line(ERRCNTROW, ERRORCOL, 16);
                        fprintf(stderr, "%d\7", errors);
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "Timeout\7");
                        sendchar(NAK);
                        break;
                    default:
                        errorflag = 1;
                        errors++;
                        clr_line(ERRCNTROW, ERRORCOL, 16);
                        fprintf(stderr, "%d\7", errors);
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "Not SOH [%02x]\7", r_char & 0x0ff);
                        idle();
                        sendchar(NAK);
                        break;
                }
            } while ((errors < ERRORMAX) && (errorflag));
            switch (r_char)
            {
                case STX:
                case SOH:
                    sectcurr = readchar(1) & 255;
                    sectcomp = readchar(1) & 255;
                    if (sectcurr + sectcomp == 255)
                    {
                        if ((sectcurr == ((sectnum + 1) & 255)) || (sectcurr == 0))
                        {
                            for (j = 0, checksum = 0; j < curr_size; j++)
                            {
                                sector[j] = readchar(1);
                                checksum = checksum + sector[j];
                                checksum = checksum & 255;
                            }
                            if (recv_mode == NAK)
                            {
                                r_checksum = readchar(1) & 255;
                                if (checksum == r_checksum)
                                    recv_ok = 1;
                                else
                                    recv_ok = 0;
                            }
                            else
                            {
                                r_crcval = (readchar(1) & 255) << 8;
                                r_crcval = r_crcval + (readchar(1) & 255);
                                crcval = calc_crc(sector, curr_size);
                                if (crcval == r_crcval)
                                    recv_ok = 1;
                                else
                                    recv_ok = 0;
                            }
                            if (recv_ok)
                            {
                                if ((sectcurr == 0) && (sectnum == 0))
                                {
                                    if (sector[0] == 0)
                                    {
                                        sendchar(ACK);
                                        return();
                                    }
                                    strcpy(filename, sector);
                                    if ((fd = fopen(filename,w_str)) == ERROR)
                                    {
                                        gotorc(GFN, 10);
                                        fprintf(stderr, "Create error");
                                        sendchar(CAN);
                                        sendchar(CAN);
                                        getanykey();
                                        return;
                                    }
                                    clr_line(PROTOCOL, ERRORCOL, 16);
                                    fprintf(stderr, proto_string);
                                    clr_line(FNAME, ERRORCOL, 16);
                                    fprintf(stderr, filename);
                                    sendchar(ACK);
                                    idle();
                                    sendchar(CRC);
                                }
                                else
                                {
                                    sectnum++;
                                    if (fwrite(sector, 1, curr_size, fd) == 0)
                                    {
                                        clr_line(WHYROW, ERRORCOL, 16);
                                        fprintf(stderr, "write error\7");
                                        fclose(fd);
                                        return;
                                    }
                                    if (curr_size == 128)
                                        blocks++;
                                    else
                                        blocks += 8;
                                    tot_bytes += curr_size;
                                    clr_line(BLOCKS, ERRORCOL, 16);
                                    fprintf(stderr, "%d", blocks);
                                    clr_line(BYTESREAD, ERRORCOL, 16);
                                    fprintf(stderr, "%d", tot_bytes);
                                    sendchar(ACK);
                                }
                                errors = 0;
                            }
                            else
                            {
                                clr_line(WHYROW, ERRORCOL, 16);
                                if (recv_mode == NAK)
                                    fprintf(stderr, "checksum error\7");
                                else
                                    fprintf(stderr, "CRC error\7");
                                errorflag = 1;
                            }
                        }
                        else
                        {
                            if (sectcurr == (sectnum & 255))
                            {
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Dup Sect %d",sectnum);
                                idle();
                                sendchar(ACK);
                            }
                            else
                            {
                                clr_line(WHYROW, ERRORCOL, 16);
                                fprintf(stderr, "Sync error\7");
                                errorflag = 1;
                            }
                        }
                    }
                    else
                    {
                        clr_line(WHYROW, ERRORCOL, 16);
                        printf(stderr, "Sector number\7");
                        errorflag = 1;
                    }
                    if (errorflag)
                    {
                        errors++;
                        clr_line(ERRCNTROW, ERRORCOL, 16);
                        fprintf(stderr, "%d\7", errors);
                        while (readchar(1) != TIMEOUT);
                        sendchar(NAK);
                    }
                    if (errors >= ERRORMAX)
                    {
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "Too Many Errors\7");
                    }
                    break;

                case EOT:
                    if (errors < ERRORMAX)
                    {
                        sendchar(ACK);
                        fclose(fd);
                        clr_line(STATUSROW, ERRORCOL, 16);
                        fprintf(stderr, "Completed");
                    }
                    else
                    {
                        clr_line(STATUSROW, ERRORCOL, 16);
                        fprintf(stderr, "Aborting\7");
                        clr_line(WHYROW, ERRORCOL, 16);
                        fprintf(stderr, "BAD [%02x]\7", r_char & 0x0ff);
                        errors = ERRORMAX;
                    }
                    break;

                default:
                    clr_line(STATUSROW, ERRORCOL, 16);
                    fprintf(stderr, "Aborting\7");
                    clr_line(WHYROW, ERRORCOL, 16);
                    fprintf(stderr, "BAD [%02x]\7", r_char & 0x00ff);
                    errors = ERRORMAX;
                    break;
            }
            if (errors >= ERRORMAX)
                break;
        } while (r_char != EOT);
    } while ((protocol == YMODEMBATCH) && (errors < ERRORMAX));
}

