#include <stdio.h>
#include "windows.h"
#include "ezm.h"

void auto_dial()
{
    char c;
    char rate[6], string[32];
    int  i, j, k, entry;

    ld_codes[0] = minus_flag ? '-' : ' ';
    ld_codes[1] = plus_flag  ? '+' : ' ';
    ld_codes[2] = atsign_flag? '@' : ' ';
    ld_codes[3] = pound_flag ? '#' : ' ';
    ld_codes[4] = '\0';

    open_window(0,0,80,24);
    gotorc(1, 22);
    fprintf(stderr,"D I A L I N G    D I R E C T O R Y");
    gotorc(2, 1);
    fprintf(stderr,"                Name                Number");
    fprintf(stderr,"        Baud            CMD File");
    dump_phone();
    gotorc(15, 1);
    fprintf(stderr," ==>            R Revise         M Manual Dialing      ");
    fprintf(stderr,"Entry to Dial");
    gotorc(16, 1);
    fprintf(stderr,"                P LD Codes       D Delete Entry        ");
    fprintf(stderr,"F Find");
    gotorc(17, 1);
    fprintf(stderr,"                ^C Page Down     L Print Entries       ");
    fprintf(stderr,"^X/^E Scroll");
    gotorc(18, 1);
    fprintf(stderr,"                ^R Page Up       ^Q Quick Page         ");
    fprintf(stderr,"ESC Exit");
    gotorc(20, 1);
    fprintf(stderr,"   Modem Dial Cmd: %-20s", mod_dial_str);
    fprintf(stderr,"      LD Codes Active: %-4s", ld_codes);
    gotorc(21, 1);
    fprintf(stderr,"  Dial Cmd Suffix: %-14s", dial_cmd_suff);
    fprintf(stderr," Device Driver Active: %-4s", device_name);
    do
    {
        clr_line(22,1,78);
        gotorc(22,34);
        fprintf(stderr,"AUTO DIALER");
        clr_line(15, 6, 11);
        c = toupper(rawget() & 0x000000ff);
        switch (c)
        {
        case 'R':                       /* Revise entry   */
            clr_line(22,1,78);
            fprintf(stderr, "Entry to revise:          (Number, #, -, +, @)");
            gotorc(22, 18);
            c = rawget();
            if (isdigit(c))
            {
                string[0] = c;
                rawput(c & 0x7f);
                if (getstr(&string[1], 32) == -1)
                    break;
                entry = atoi(string) != 0 ? atoi(string) - 1: 0;
                entry = entry > 50 ? 50 : entry;
                clr_line(22,1,78);
                prompt("Name: ", string, 32);
                if (strlen(string))
                {
                    ezmphone_changed = 1;
                    left_copystr(name[entry], string, 24);
                }
                clr_line(22,1,78);
                prompt("Phone Number: ", string, 32);
                if (strlen(string))
                {
                    ezmphone_changed = 1;
                    right_copystr(phone_number[entry], string, 14);
                }
                clr_line(22,1,78);
                prompt("Baud rate: ", string, 32);
                if (strlen(string))
                {
                    ezmphone_changed = 1;
                    right_copystr(baud[entry], string, 5);
                }
            }
            else
                {
                switch(c)
                {
                case '-':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '-': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(minus, string);
                    minus_flag = strlen(minus)?1:0;
                    break;
                case '+':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '+': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(plus, string);
                    plus_flag = strlen(plus)?1:0;
                    break;
                case '@':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '@': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(atsign, string);
                    atsign_flag = strlen(atsign)?1:0;
                    break;
                case '#':
                    clr_line(22,1,78);
                    fprintf(stderr, "Enter Long Distance code for '#': ");
                    if (getstr(string, 14) <= 0)
                        break;
                    strcpy(pound, string);
                    pound_flag = strlen(pound)?1:0;
                    break;
                default:
                    break;
                }
                ld_codes[0] = minus_flag ? '-' : ' ';
                ld_codes[1] = plus_flag  ? '+' : ' ';
                ld_codes[2] = atsign_flag? '@' : ' ';
                ld_codes[3] = pound_flag ? '#' : ' ';
                ld_codes[4] = '\0';
                gotorc(20, 1);
                fprintf(stderr, "   Modem Dial Cmd: %-20s", mod_dial_str);
                fprintf(stderr, "      LD Codes Active: %-4s", ld_codes);
            }

            if (ezmphone_changed)
            {
                clr_line(22,1,78);
                prompt("Save changes? ", string, 32);
                if (toupper(string[0]) == 'Y')
                {
                    ezmphone_changed = 0;
                    dial_fd = fopen(phone_list, "wb");
                    for (i = 0; i < 50; i++)
                    {
                        fwrite(name[i],         25, 1, dial_fd);
                        fwrite(phone_number[i], 15, 1, dial_fd);
                        fwrite(baud[i],          6, 1, dial_fd);
                        fwrite(cmd_file[i],      9, 1, dial_fd);
                    }
                    fwrite(minus, 15, 1, dial_fd);
                    fwrite(plus,  15, 1, dial_fd);
                    fwrite(atsign,15, 1, dial_fd);
                    fwrite(pound, 15, 1, dial_fd);
                    fclose(dial_fd);
                }
            }
            dump_phone();
            break;
        case 'M':                       /* Manual Dialing */
            clr_line(22,1,78);
            fprintf(stderr, "Enter phone number: ");
            if (getstr(string, 32) <= 0)
                break;
            clr_line(22,1,78);
            fprintf(stderr, "Dialing %s%s%s ",mod_dial_str,string,dial_cmd_suff);
            j = 0;
            while (mod_dial_str[j])
                sendchar(mod_dial_str[j++]);
            j = 0;
            while (string[j])
            {
                if (isdigit(string[j]))
                    sendchar(string[j++]);
                else
                    {
                    k = 0;
                    switch (string[j++])
                    {
                    case '-':
                        while(minus[k])
                            sendchar(minus[k++]);
                        break;
                    case '+':
                        while(plus[k])
                            sendchar(plus[k++]);
                        break;
                    case '@':
                        while(atsign[k])
                            sendchar(atsign[k++]);
                        break;
                    case '#':
                        while(pound[k])
                            sendchar(pound[k++]);
                        break;
                    default:
                        break;
                    }
                }
            }
            j = 0;
            while (dial_cmd_suff[j])
                sendchar(dial_cmd_suff[j++]);
            sendchar(0x0d);
            if (wait_modem())
            {
                if (window_level)
                    close_window();
                fprintf(stderr, "\n%s", reply);
                return;
            }
            break;
        case 'P':                       /* LD codes       */
            open_window(7,0,34,6);
            gotorc(8, 1);
            fprintf(stderr, "\t- = %s", minus);
            gotorc(9, 1);
            fprintf(stderr, "\t+ = %s", plus);
            gotorc(10, 1);
            fprintf(stderr, "\t@ = %s", atsign);
            gotorc(11, 1);
            fprintf(stderr, "\t# = %s", pound);
            gotorc(12, 1);
            rawget();
            close_window();
            dump_phone();
            break;
        case 'D':                       /* Delete entry   */
            clr_line(22,1,78);
            fprintf(stderr, "Entry to delete: ");
            c = rawget();
            if (isdigit(c))
            {
                string[0] = c;
                rawput(c & 0x7f);
                if (getstr(&string[1], 32) == -1)
                    break;
                entry = atoi(string) != 0 ? atoi(string) - 1: 0;
                entry = entry > 50 ? 50 : entry;
                strcpy(name[entry],"........................");
                strcpy(phone_number[entry],". ... ...-....");
                strcpy(baud[entry]," 1200");
                strcpy(cmd_file[entry],"        ");
                clr_line(22,1,78);
                prompt("Save changes? ", string, 32);
                if (toupper(string[0]) == 'Y')
                {
                    ezmphone_changed = 0;
                    dial_fd = fopen(phone_list, "wb");
                    for (i = 0; i < 50; i++)
                    {
                        fwrite(name[i],         25, 1, dial_fd);
                        fwrite(phone_number[i], 15, 1, dial_fd);
                        fwrite(baud[i],          6, 1, dial_fd);
                        fwrite(cmd_file[i],      9, 1, dial_fd);
                    }
                    fwrite(minus, 15, 1, dial_fd);
                    fwrite(plus,  15, 1, dial_fd);
                    fwrite(atsign,15, 1, dial_fd);
                    fwrite(pound, 15, 1, dial_fd);
                    fclose(dial_fd);
                }
            }
            dump_phone();
            break;
        case 'F':                       /* Find entry     */
            clr_line(22,1,78);
            fprintf(stderr, "Name to search for: ");
            if (getstr(string, 25) <= 0)
                break;
            for (i = 0; i < 50; i++)
                if (strncmp(string, name[i], strlen(string)) == 0)
                    break;
            if (i < 50)
            {
                dial_start = i + 1;
                dump_phone();
            }
            break;
        case 'L':                       /* Print entries  */
            prnt_str(crlf_str);
            for (i = 0; i < 50; i++)
            {
                sprintf(string, "   %2d-", i);
                prnt_str(string);
                sprintf(string, " %s", name[i]);
                prnt_str(string);
                sprintf(string, "   %s", phone_number[i]);
                prnt_str(string);
                sprintf(string, "  %s", baud[i]);
                prnt_str(string);
                sprintf(string, "          %s", cmd_file[i]);
                prnt_str(string);
                prnt_str(crlf_str);
            }
            break;
        case 0x03:                      /* ^C Page down   */
            dial_start += 10;
            dump_phone();
            break;
        case 0x12:                      /* ^R page up     */
            dial_start = (dial_start < 11 ? 1 : dial_start - 10);
            dump_phone();
            break;
        case 0x05:                      /* ^E scroll up   */
            dial_start = (dial_start > 1 ? --dial_start : 1);
            dump_phone();
            break;
        case 0x18:                      /* ^X scroll down */
            dial_start = (dial_start < 41 ? ++dial_start : 41);
            dump_phone();
            break;
        case 0x11:                      /* ^Q quick page  */
            switch (rawget() & 0x1f)
            {
            case 0x12:
                dial_start = 1;
                break;
            case 0x03:
                dial_start = 41;
                break;
            default:
                break;
            }
            dump_phone();
            break;
        case 0x1b:                      /* ESC - exit     */
            break;
        default:                        /* if numeric - Entry to dial */
            if (isdigit(c))
            {
                rawput(c & 0x7f);
                string[0] = c;
                if (getstr(&string[1], 32) == -1)
                    break;
                entry = atoi(string) != 0 ? atoi(string) - 1: 0;
                entry = entry > 50 ? 50 : entry;
                for (i = 0, j = 0; i < 14; i++)
                    if (isdigit(phone_number[entry][i]))
                        string[j++] = phone_number[entry][i];
                string[j] = '\0';
                left_copystr(rate, baud[entry], 5);
                baud_rate =  atoi(rate) / 100;
/*                uvtable->device[modem_dev].ttyinfo.baudrt = baud_rate; */
                dvr_init(modem_dev);
                clr_line(22,1,78);
                fprintf(stderr, "Dialing %s%s%s ",mod_dial_str,string,dial_cmd_suff);
                j = 0;
                while (mod_dial_str[j])
                    sendchar(mod_dial_str[j++]);
                j = 0;
                while (phone_number[entry][j])
                {
                    if (isdigit(phone_number[entry][j]))
                        sendchar(phone_number[entry][j++]);
                    else
                        {
                        k = 0;
                        switch (phone_number[entry][j++])
                        {
                        case '-':
                            while(minus[k])
                                sendchar(minus[k++]);
                            break;
                        case '+':
                            while(plus[k])
                                sendchar(plus[k++]);
                            break;
                        case '@':
                            while(atsign[k])
                                sendchar(atsign[k++]);
                            break;
                        case '#':
                            while(pound[k])
                                sendchar(pound[k++]);
                            break;
                        default:
                            break;
                        }
                    }
                }
                j = 0;
                while (dial_cmd_suff[j])
                    sendchar(dial_cmd_suff[j++]);
                sendchar(0x0d);
                if (wait_modem())
                {
                    if (window_level)
                        close_window();
                    fprintf(stderr, "\n%s", reply);
                    return;
                }
            }
            break;
        }
    } 
    while (c != 0x1b);            
}

