/*
 * send a character
 */

sendchar(data)
char data;
{
    while(1)
        if (dvr_ostat(modem_dev))
            break;
    dvr_putc(modem_dev, data);
}

