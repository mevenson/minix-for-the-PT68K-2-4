/*
*** Convert String To Upper Case 
*/

str_upper(s)
unsigned char *s;
{
    while (*s = toupper(*s))
        ++s;
}


