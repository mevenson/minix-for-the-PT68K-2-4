/*
 * set up the file characteristics
 * for Xmodem transfers
 */

set_file()
{
    open_window(GFN - 1, 9, 50, 3);
    gotorc(GFN, 10);
    prompt("Enter file mode [Ascii/Binary/Cpm]",answer, 20);
    close_window();
    answer[0] = tolower(answer[0]);
    if (answer[0] == 'b')
    {
        file_mode = BINARY;
        r_str = RB;
        w_str = WB;
    }
    else if (answer[0] == 'c')
    {
        file_mode = CPM;
        r_str = RA;
        w_str = WB;
    }
    else
        {
        file_mode = ASCII;
        r_str = RA;
        w_str = WA;
    }
}

