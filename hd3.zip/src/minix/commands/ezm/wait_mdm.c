wait_modem()
{
    int c, i, wait_amount;

    idle();
    wait_amount = atoi(connect_wait);
    i = 0;
    while ((c = readchar(1)) == TIMEOUT)
    {
        if (i++ == wait_amount)
        {
            gotorc(0,79);
            rawput('*');
            break;
        }
        if (rdy())
        {
            if (rawget() == 0x1b)
            {
                sendchar('\n');
                gotorc(0,78);
                rawput('+');
                return(0);
            }
        }
    }
    if (i < wait_amount)
    {
        i = 0;
        if (c >= 'A')
        {
            rawput(c);
            reply[i++] = c;
        }
        while ((c = readchar(5)) != -1)
        {
            if (rdy())
            {
                if (rawget() == 0x1b)
                {
                    sendchar('\n');
                    gotorc(0,77);
                    rawput('-');
                    return(0);
                }
            }
            if (i == 0)
            {
                if (c >= 'A')
                {
                    rawput(c);
                    reply[i++] = c;
                }
            }
            else
                {
                if ((c != 0x0d) && (c != 0x0a))
                {
                    rawput(c);
                    reply[i++] = c;
                }
                else
                    {
                    gotorc(0,76);
                    rawput('=');
                    reply[i++] = '\0';
                    break;
                }
            }
        }
        if (strncmp(reply, connect_str, strlen(connect_str)) == 0)
        {
            gotorc(0,75);
            rawput('|');
            return(1);
        }
        else
            {
            gotorc(0,74);
            rawput('?');
            return(0);
        }
    }
    else
        {
        gotorc(0,73);
        rawput('.');
        return(0);
    }
}

