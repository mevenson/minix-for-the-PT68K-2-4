/*
 * send a file using the XMODEM, YMODEM or YMODEM Batch protocol
 */

sendfile(hdr_flag)
int hdr_flag;
{
    int partial, blocks, sectnum, attempts, status, checksum, *fd, i, j;
    char sector[1026], r_char, chk_mode;
    unsigned int send_size;

    if (protocol != YMODEMBATCH)
    {
        open_window(GFN - 1, 9, 50, 3);
        gotorc(GFN, 10);
        prompt("Enter filename: ",filename, 32);
        if (filename[0] == '\0')
            return;
        close_window();
    }
    else
    {
        for (i = 0; i < 128; i++)
            sector[i] = hdr_block[i];
    }

    if (!hdr_flag)
    {
        if ((fd = fopen(filename,r_str)) == ERROR)
        {
            open_window(GFN - 1, 9, 50, 3);
            gotorc(GFN, 10);
            fprintf(stderr, "Can't open %s for read\7",filename);
            getanykey();
            close_window();
            return;
        }
        sectnum = 1;
    }
    else
        sectnum = 0;
    tot_bytes = 0;
    if (protocol != YMODEMBATCH)
        send_screen();
    clr_line(PROTOCOL, ERRORCOL, 16);
    fprintf(stderr, proto_string);
    clr_line(FNAME, ERRORCOL, 16);
    fprintf(stderr, filename);
    blocks = 0;
    attempts = 0;
    if (!hdr_flag)
    {
        clr_line(STATUSROW, ERRORCOL, 16);
        fprintf(stderr, "Awaiting NAK");
        if ((protocol == YMODEMBATCH) || (protocol == YMODEM))
            send_size = 1024;
        else
            send_size = 128;
    }
    chk_mode = 0;
    while ((attempts < RETRYMAX) && (chk_mode == 0))
    {
        switch (chk_mode = readchar(15))
        {
        case 'K':
            chk_mode = 0;
            send_size = 1024;
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "1K Blocks");
            break;
        case NAK:
        case CRC:
            break;
        default:
            chk_mode = 0;
            attempts++;
            break;
        }
    }
    if (attempts >= RETRYMAX)
    {
        clr_line(WHYROW, ERRORCOL, 16);
        fprintf(stderr, "Timed out");
        clr_line(STATUSROW, ERRORCOL, 16);
        fprintf(stderr, "Aborted\7\7");
        fclose(fd);
        return;
    }
    if ((chk_mode == CRC) && (protocol == XMODEM))
    {
        clr_line(PROTOCOL, ERRORCOL, 16);
        fprintf(stderr, "XMODEM CRC");
    }
    clr_line(STATUSROW, ERRORCOL, 16);
    attempts = 0;
    partial = 0;
    do
        {
        if (partial == 0)
        {
            if (!hdr_flag)
            {
                for (i = 0; i < 1024; i++)
                    sector[i] = '\0';
                status = fread(sector, 1, send_size, fd);
            }
            else
                status = send_size = 128;
            if ((send_size == 1024) && (status < 1024))
            {
                send_size = 128;
                partial = 1;
            }
        }
        if (status <= 0)
            break;
        attempts = 0;
        do
            {
            if (rdy())
            {
                if (rawget() == 0x1b)
                {
                    for (i = 0; i < 8; i++)
                        sendchar(CAN);
                    for (i = 0; i < 8; i++)
                        sendchar(0x08);
                    clr_line(WHYROW, ERRORCOL, 16);
                    fprintf(stderr, "Operator abort\7");
                    return();
                }
            }
            crcval = 0;
            crcval = calc_crc(sector, send_size);
            if (send_size == 128)
                sendchar(SOH);
            else
                sendchar(STX);
            sendchar(sectnum & 255);
            sendchar(255 - (sectnum & 255));
            for (j = 0, checksum = 0; j < send_size; j++)
            {
                sendchar(sector[j]);
                checksum = checksum + sector[j];
                checksum = checksum & 255;
            }
            if (chk_mode == NAK)
                sendchar(checksum);
            else
                {
                sendchar((crcval >> 8) & 0x00ff);
                sendchar(crcval & 0x00ff);
            }
            attempts++;
            purgeline();
            r_char = readchar(15);
            switch (r_char)
            {
            case NAK:
                clr_line(STATUSROW, ERRORCOL, 16);
                fprintf(stderr, "Retransmitting");
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "Received NAK\7");
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                break;
            case TIMEOUT:
                clr_line(STATUSROW, ERRORCOL, 16);
                fprintf(stderr, "Retransmitting");
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "Timed out\7");
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                break;
            case ACK:
                if (hdr_flag)
                    return;
                if (send_size == 128)
                    blocks++;
                else
                    blocks += 8;
                tot_bytes += send_size;
                clr_line(BYTESSENT, ERRORCOL, 16);
                fprintf(stderr, "%d", tot_bytes);
                clr_line(BLOCKS, ERRORCOL, 16);
                fprintf(stderr, "%d", blocks);
                clr_line(ERRCNTROW, ERRORCOL, 16);
                sectnum++;
                if (partial)
                {
                    status -= 128;
                    for (i = 0, j = 128; i < 896; i++, j++)
                        sector[i] = sector[j];
                }
                break;
            default:
                clr_line(STATUSROW, ERRORCOL, 16);
                fprintf(stderr, "Retransmitting");
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "BAD [%02x]\7", r_char & 0x00ff);
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                break;
            }
        } 
        while ((r_char != ACK) && (attempts < RETRYMAX));
    } 
    while ((attempts < RETRYMAX) && (status != 0));

    if (attempts >= RETRYMAX)
    {
        clr_line(STATUSROW, ERRORCOL, 16);
        fprintf(stderr, "Aborted");
        clr_line(WHYROW, ERRORCOL, 16);
        fprintf(stderr, "Too Many Errors\7\7");
    }
    else
        {
        attempts = 0;
        while(1)
        {
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "Sending EOT");
            sendchar(EOT);
            purgeline();
            attempts++;
            if ((r_char = readchar(5)) == ACK | attempts >= RETRYMAX)
                break;
            else
            {
                clr_line(ERRCNTROW, ERRORCOL, 16);
                fprintf(stderr, "%d", attempts);
                clr_line(WHYROW, ERRORCOL, 16);
                fprintf(stderr, "BAD [%02x]", r_char & 0x0ff);
            }
        }
        if (attempts >= RETRYMAX)
        {
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "Aborted\7\7");
            clr_line(WHYROW, ERRORCOL, 16);
            fprintf(stderr, "No ACK to EOT\7");
        }
        else
        {
            clr_line(STATUSROW, ERRORCOL, 16);
            fprintf(stderr, "Complete\7");
        }
    }
    fclose(fd);
}

