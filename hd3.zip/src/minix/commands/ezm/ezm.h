#define TIMEOUT     -1

#define SOH         0x01    /* ^A -- start of sector 128 byte blocks*/
#define STX         0x02    /* ^B -- start of sector 1K blocks */
#define ETX         0x03    /* ^C -- End Of Text */
#define EOT         0x04    /* ^D -- end of transmission */
#define ENQ         0x05    /* ^E -- Enquire */
#define ACK         0x06    /* ^F -- successfull transfer */
#define DLE         0x10    /* ^P -- Data Link Escape */
#define XON         0x11    /* ^Q -- Tranfer ON */
#define XOFF        0x13    /* ^S -- Transfer OFF */
#define NAK         0x15    /* ^U -- Negative ACKnowledge */
#define CAN         0x18    /* ^X -- cancel transmission */
#define ESC         0x1b    /* ^[ -- ESCape character */

#define CRC         'C'
#define ERRORMAX    10      /* number of errors till abort */
#define RETRYMAX    10      /* number of retrys till abort */
#define ERROR       0
#define CPM         0
#define ASCII       1
#define BINARY      2
#define RA          "r"
#define RB          "rb"
#define WA          "w"
#define WB          "wb"

#define ON           1
#define OFF          0

#define XMODEM      0
#define YMODEM      1
#define YMODEMBATCH 2
#define COMPUSERVE  3

#define PROTOCOL    10
#define FNAME       11
#define BLOCKS      12
#define BYTESREAD   13
#define BYTESSENT   13
#define ERRCNTROW   14
#define WHYROW      15
#define STATUSROW   16

#define SCROFFSET   40
#define ERRORCOL    14+SCROFFSET
#define GFN         12

/* defines for compuserve B protocol */

#define True            1
#define False           0
#define Success         -1
#define Failure         0
#define Packet_Size     512
#define Max_Errors      10
#define Max_Time        10
#define WACK            ';'             /* wait acknowledge */

/* Sender actions */

#define S_Send_Packet   0
#define S_Get_DLE       1
#define S_Get_Num       2
#define S_Get_Seq       3
#define S_Get_Data      4
#define S_Get_Checksum  5
#define S_Timed_Out     6
#define S_Send_NAK      7

/* Receiver actions */

#define R_Get_DLE       0
#define R_Get_B         1
#define R_Get_Seq       2
#define R_Get_Data      3
#define R_Get_Checksum  4
#define R_Send_NAK      5
#define R_Send_ACK      6

static int
    Ch,
    Checksum,
    Seq_Num,
    R_Size,                             /* Size of receiver buffer */
    XOFF_Flag,
    Seen_ETX;

static char
    cis_failure[32],                    /* save failure for output */
    S_Buffer[Packet_Size],              /* Sender buffer */
    R_Buffer[Packet_Size];              /* Receiver buffer */

static char
    VIDTEX_Response[] = "#IB1,PB,DT015";

static int ESC_Seq_State;

char phone_list[] = "0.PHONELST.EZM";
char opt_file[]   = "0.DEFLTOPT.EZM";

char crlf_str[] = {
    0x0d, 0x0a, 0x00};
char nulls[] = {
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
    0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};

char *fm_str[] = {
    "CP/M", "ASCII", "BINARY"};

char *instruct1 =
"EZMPLUS is designed to operate  on any SK*DOS system through an  installed";
char *instruct2 =
"device  driver.  If no device name is given on  the command  line when the";
char *instruct3 =
"program is invoked, it defaults to 'MODM'. If you want  to run the program";
char *instruct4 =
"without  the need  to enter  the device  name, have  your STARTUP.BAT file";
char *instruct5 =
"install the device driver at boot or do it manually before running EZMPLUS";
char *instruct6 =
"";
char *instruct7 =
"             dosparam 4 br=12";
char *instruct8 =
"             device 0.serial1.dvr as MODM at 4";
char *instruct9 =
"";
char *instruct10 =
"EZMPLUS will support baud rates from 300 baud to 19.2K baud. It currently";
char *instruct11 =
"supports XMODEM, YMODEM, YMODEM BATCH, and COMPUSERVE B protocols.";
char *instruct12 =
"";
char *instruct13 =
"If you like EZMODEM and would like to contribute to it's developement, all";
char *instruct14 =
"contributions are sincerly appreciated. Any contribution of $45.00 or more";
char *instruct15 =
"will provide the contributor one year of updates as they become available.";
char *instruct16 =
"";
char *instruct17 =
"          Michael Evenson";
char *instruct18 =
"          200 Ginger Ct.";
char *instruct19 =
"          Southlake Tx. 76092";
char *instruct20 =
"          BBS phone # 817-488-8398";

char *memend, *buf_ptr, *buf_base;

char x_protocol[]      = "XMODEM";
char y_protocol[]      = "YMODEM";
char ybatch_protocol[] = "YMODEM Batch";
char cis_b_protocol[]  = "COMPUSERVE B";

char device_name[5];
char mod_dial_str[21];
char ld_codes[5];
char dial_cmd_suff[15];
char connect_str[32];
char connect_wait[10];
char redial_pause[10];
char reply[32];
char minus[15];
char plus[15];
char atsign[15];
char pound[15];
char printer[2];

char *proto_string = x_protocol;

unsigned char recv_mode = CRC;
unsigned int  recv_size = 1024;
unsigned int  protocol  = XMODEM;

char name[50][25];
char phone_number[50][15];
char baud[50][6];
char cmd_file[50][9];

char pause_flag, *r_str, *w_str;
struct uvarlst *uvtable;
unsigned char hdr_block[128];
unsigned char mask[32];
unsigned char filename[32];
unsigned char answer[20];
unsigned char ascii_br[20];
unsigned char ascii_sa[20];
int  ezmphone_changed = 0;
int  minus_flag, plus_flag, atsign_flag, pound_flag = 0;
int  modem_dev;
int  print_dev;
int  baud_rate;
int  capture;
int  file_mode;
int  dial_start = 1;
unsigned int speed_adj, average, x, y, z, tot_bytes;

unsigned short  r_crcval;
unsigned short  crcval;             /* CRC check value */

FILE *dial_fd, *opt_fd;
int dir_fd;

