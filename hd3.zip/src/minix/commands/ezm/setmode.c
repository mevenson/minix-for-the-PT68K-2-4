/* set console to raw mode */

raw_mode(f)
FILE *f;
{
    f->_flag |= _IONBF;
}

/* set console back to buffered mode */

buf_mode(f)
FILE *f;
{
    f->_flag &= ~_IONBF;
}

