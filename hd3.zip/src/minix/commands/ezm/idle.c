/*
 * wait for an idle line
 */

idle()
{
    while (readchar(1) != TIMEOUT);
}

