/*

        ezmodem.c

                communications program for the 68000

    version 2:5.1   Added Auto Dial capability.
    version 2:6.0   Added Option file Capability.
    version 2:6.1   Made compatible with new compiler (fix to open)
    version 2:6.2   Recompiled with new C compiler and Assembler
    version 2:7.0   Added Compuserve 'B' protocol
    version 3:0.0   Converted to not menu driven. Uses HOT keys

*/

#define VERSION "3:0.0"

#include <stdio.h>
#include <time.h>
#include <ctype.h>

#include "ezm.h"

main(argc, argv)
int argc;
char *argv[];
{
    int  i;

    getty(0,&data);
    data.drv_echo  |= RAW;
    setty(0,&data);

    file_mode   = BINARY;
    raw_mode(stdin);
    if ((opt_fd = fopen(opt_file, "rb")) == 0)
    {
        opt_fd = fopen(opt_file, "wb");
        fwrite("ATDT",     5, 1, opt_fd);
        fwrite(nulls,     16, 1, opt_fd);   /* total = 21 for mod_dial_str */
        fwrite(nulls,      5, 1, opt_fd);   /* ld_codes */
        fwrite(nulls,     15, 1, opt_fd);   /* dial_cmd_suff */
        fwrite("CONNECT",  8, 1, opt_fd);
        fwrite(nulls,     24, 1, opt_fd);   /* total = 32 for connect_str */
        fwrite("30",       3, 1, opt_fd);
        fwrite(nulls,      7, 1, opt_fd);   /* total = 10 for connect_wait */
        fwrite("2",        2, 1, opt_fd);
        fwrite(nulls,      8, 1, opt_fd);   /* total = 10 for redial_pause */
        fwrite("MODM",     5, 1, opt_fd);
        fwrite("2",        2, 1, opt_fd);
        fclose(opt_fd);
    }
    opt_fd = fopen(opt_file, "rb");
    fread(mod_dial_str, 21, 1, opt_fd);
    fread(ld_codes,      5, 1, opt_fd);   /* ld_codes */
    fread(dial_cmd_suff,15, 1, opt_fd);   /* dial_cmd_suff */
    fread(connect_str,  32, 1, opt_fd);
    fread(connect_wait, 10, 1, opt_fd);
    fread(redial_pause, 10, 1, opt_fd);
    fread(device_name,   5, 1, opt_fd);
    fread(printer,       2, 1, opt_fd);
    fclose(opt_fd);

    r_str = RB;
    w_str = WB;

    print_dev = atoi(printer);
    uvtable  = vpoint();
    buf_ptr  = malloc(0x40000);
    buf_base = buf_ptr;
    memend   = uvtable->memend;

    speed_adj = 15000;
    capture = 0;
    if (argc != 1)
        strncpy(device_name, argv[1], 4);
    device_name[4] = '\0';
    str_upper(device_name);
    for (i = 0; i < 8; i++)
    {
        if (strncmp(device_name, uvtable->device[i].devnam, 4) == 0)
        {
            modem_dev = i;
            break;
        }
    }
    if (i != 8)
    {
        pause_flag = uvtable->device[0].ttyinfo.pauseb;
        uvtable->device[0].ttyinfo.pauseb = 0;
        if ((dial_fd = fopen(phone_list, "rb")) == 0)
        {
            dial_fd = fopen(phone_list, "wb");
            fwrite("Evenson Consulting      ", 25, 1, dial_fd);
            fwrite("1 817 488-8398", 15, 1, dial_fd);
            fwrite(" 1200", 6, 1, dial_fd);
            fwrite("        ", 9, 1, dial_fd);
            for (i = 1; i < 50; i++)
            {
                fwrite("........................", 25, 1, dial_fd);
                fwrite(". ... ...-....", 15, 1, dial_fd);
                fwrite(" 1200", 6, 1, dial_fd);
                fwrite("        ", 9, 1, dial_fd);
            }
            fwrite(minus, 15, 1, dial_fd);
            fwrite(plus,  15, 1, dial_fd);
            fwrite(atsign,15, 1, dial_fd);
            fwrite(pound, 15, 1, dial_fd);
            fclose(dial_fd);
            dial_fd = fopen(phone_list, "rb");
        }
        for (i = 0; i < 50; i++)
        {
            fread(name[i],         25, 1, dial_fd);
            fread(phone_number[i], 15, 1, dial_fd);
            fread(baud[i],          6, 1, dial_fd);
            fread(cmd_file[i],      9, 1, dial_fd);
        }
        fread(minus, 15, 1, dial_fd);
        fread(plus,  15, 1, dial_fd);
        fread(atsign,15, 1, dial_fd);
        fread(pound, 15, 1, dial_fd);
        fclose(dial_fd);
        baud_rate = uvtable->device[modem_dev].ttyinfo.baudrt;
        while(1)
        {
            terminal(1);
            break;
        }
    }
    else
        usage();
}
