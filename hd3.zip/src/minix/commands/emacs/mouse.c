/*	MOUSE.C:	Mouse functionality commands
			for MicroEMACS 3.9
			originally written by Dave G. Conroy
			modified by Jeff Lomicka and Daniel Lawrence
*/

#include	<stdio.h>
#include	"estruct.h"
#include	"etype.h"
#include        "edef.h"

#define	MNONE	0			/* Mouse commands.		*/
#define	MMOVE	1
#define	MKILL	2
#define	MYANK	3

#if	MOUSE
noshare int	lastypos = HUGE;	/* Last mouse event row.	*/
noshare int	lastxpos = HUGE;	/* Last mouse event column.	*/
noshare int	lastmcmd = MNONE;	/* Last mouse command.		*/

/*
 * Move mouse button, down. The window that the
 * mouse is in is always selected (this lets you select a
 * window by clicking anyplace in it, even off the end
 * of the text). If the mouse points at text then dot is
 * moved to that location.
 */
PASCAL NEAR movemd(f, n)
{
	register WINDOW	*wp;
	register LINE	*lp;

	if (lastmcmd!=MMOVE || lastypos!=ypos || lastxpos!=xpos)
		nclicks = 0;
	++nclicks;
	lastypos = ypos;
	lastxpos = xpos;
	lastmcmd = MMOVE;
	if ((wp=mousewindow(ypos)) == NULL)
		return(FALSE);
	curwp = wp;
	curbp = wp->w_bufp;
	if ((lp=mouseline(wp, ypos)) != NULL) {
		curwp->w_dotp = lp;
		curwp->w_doto = mouseoffset(lp, xpos);
	}
	return(TRUE);
}

/*
 * Move mouse button, up. The up click must be
 * in the text region of a window. If the old click was in a
 * mode line then the mode line moves to the row of the
 * up click. If the old click is not in a mode line then the
 * window scrolls. The code in this function is just
 * too complex!
 */
PASCAL NEAR movemu(f, n)
{
	register WINDOW	*lastwp;
	register WINDOW	*wp;
	register int	lastmodeline;
	register int	delta;

	if (lastypos==ypos && lastxpos==xpos)
		return(FALSE);
	if ((lastwp=mousewindow(lastypos)) == NULL)
		return(FALSE);
	lastmodeline = ismodeline(lastwp, lastypos);
	if ((wp=mousewindow(ypos)) == NULL)
		return(FALSE);
	if (ismodeline(wp, ypos) != FALSE)
		return(FALSE);
	delta = lastypos-ypos;
	lastypos = ypos;
	lastxpos = xpos;
	if (lastmodeline != FALSE) {
		if (lastwp->w_wndp == NULL)	/* The last modline is	*/
			return(FALSE);		/* tied down.		*/
		if (delta > 0) {
			if (lastwp != wp)
				return(FALSE);
			curwp = wp;
			curbp = wp->w_bufp;
			return(shrinkwind(TRUE, delta));
		}
		if (wp != lastwp->w_wndp)
			return(FALSE);
		curwp = lastwp;
		curbp = lastwp->w_bufp;
		return(enlargewind(TRUE, -delta));
	}
	if (lastwp != wp)
		return(FALSE);
	return(mvdnwind(TRUE, delta));
}

/*
 * Kill mouse button, down. The first down
 * click at this position copies the text between dot and
 * mouse to the kill buffer. The second down click deletes the
 * text between dot and mouse. Two clicks do a kill. The
 * kill flags are manipulated so that multiple double mouse
 * clicks append kills. Additional clicks do nothing.
 */
PASCAL NEAR killmd(f, n)
{
	register WINDOW	*wp;
	register LINE	*lp;
	register int	s;
	REGION		region;

	if (lastmcmd!=MKILL || lastypos!=ypos || lastxpos!=xpos)
		nclicks = 0;
	++nclicks;
	lastypos = ypos;
	lastxpos = xpos;
	lastmcmd = MKILL;
	if ((wp=mousewindow(ypos)) == NULL)
		return(FALSE);
	if ((lp=mouseline(wp, ypos)) == NULL)
		return(FALSE);
	if (nclicks == 1) {
		curwp->w_markp = lp;
		curwp->w_marko = mouseoffset(lp, xpos);
		return(copyregion(FALSE, 0));
	}
	if (nclicks == 2) {
		curwp->w_markp = lp;
		curwp->w_marko = mouseoffset(lp, xpos);
		if ((s=getregion(&region)) != TRUE)
			return(s);
		thisflag |= CFKILL;
		curwp->w_dotp = region.r_linep;
		curwp->w_doto = region.r_offset;
		return(ldelete(region.r_size, FALSE));
	}
	return(FALSE);
}

/*
 * Kill mouse button, up.
 * All this does is perform last mouse position
 * tracking. No editing function.
 */
PASCAL NEAR killmu(f, n)
{
	lastypos = ypos;
	lastxpos = xpos;
	return(TRUE);
}

/*
 * Yank mouse button, down. A double
 * click yanks back text. If the double click is in
 * the mode line then dot isn't moved. If the double click
 * in in the text part of the window, but it is not at a
 * good place in the text, the command does nothing. The
 * yank is done on any even click number, so you can
 * yank back again by clicking twice again.
 */
PASCAL NEAR yankmd(f, n)
{
	register WINDOW	*wp;
	register LINE	*lp;

	if (lastmcmd!=MYANK || lastypos!=ypos || lastxpos!=xpos)
		nclicks = 0;
	++nclicks;
	lastypos = ypos;
	lastxpos = xpos;
	lastmcmd = MYANK;
	if ((wp=mousewindow(ypos)) == NULL)
		return(FALSE);
	if ((nclicks&0x01) != 0)		/* TRUE, so that any	*/
		return(TRUE);			/* macro keeps running.	*/
	if (ismodeline(wp, ypos) != FALSE) {
		curwp = wp;
		curbp = wp->w_bufp;
		return(yank(FALSE, 1));
	}
	if ((lp=mouseline(wp, ypos)) != NULL) {
		curwp = wp;
		curbp = wp->w_bufp;
		curwp->w_dotp = lp;
		curwp->w_doto = mouseoffset(lp, xpos);
		return(yank(FALSE, 1));
	}
	return(FALSE);
}

/*
 * Yank mouse button, up.
 * All this does is perform last mouse position
 * tracking. No editing function.
 */
PASCAL NEAR yankmu(f, n)
{
	lastypos = ypos;
	lastxpos = xpos;
	return(TRUE);
}

/*
 * Return a pointer to the WINDOW structure
 * for the window in which "row" is located, or NULL
 * if "row" isn't in any window. The mode line is
 * considered to be part of the window.
 */

WINDOW *PASCAL NEAR mousewindow(row)

register int	row;

{
	register WINDOW	*wp;

	wp = wheadp;
	while (wp != NULL) {
		if (row < wp->w_ntrows+1)
			return(wp);
		row -= wp->w_ntrows+1;
		wp = wp->w_wndp;
	}
	return(NULL);
}

/*
 * The row "row" is a row within the window
 * whose WINDOW structure is pointed to by the "wp"
 * argument. Find the associated line, and return a pointer
 * to it. Return NULL if the mouse is on the mode line,
 * or if the mouse is pointed off the end of the
 * text in the buffer.
 */

LINE *PASCAL NEAR mouseline(wp, row)

register WINDOW	*wp;
register int	row;

{
	register LINE	*lp;

	row -= wp->w_toprow;
	if (row >= wp->w_ntrows)
		return(NULL);
	lp = wp->w_linep;
	while (row--) {
		if (lp == wp->w_bufp->b_linep)	/* Hit the end.		*/
			return(NULL);
		lp = lforw(lp);
	}
	return(lp);
}

/*
 * Return the best character offset to use
 * to describe column "col", as viewed from the line whose
 * LINE structure is pointed to by "lp".
 */

PASCAL NEAR mouseoffset(lp, col)

register LINE	*lp;
register int	col;

{
	register int	c;
	register int	offset;
	register int	curcol;
	register int	newcol;

	offset = 0;
	curcol = 0;
	while (offset != llength(lp)) {
		newcol = curcol;
		if ((c=lgetc(lp, offset)) == '\t')
			newcol += -(newcol % tabsize) + (tabsize - 1);
		else if (c<32)	/* ISCTRL */
			++newcol;
		++newcol;
		if (newcol > col)
			break;
		curcol = newcol;
		++offset;
	}
	return(offset);
}

PASCAL NEAR ismodeline(wp, row)
WINDOW	*wp;
{
	if (row == wp->w_toprow+wp->w_ntrows)
		return(TRUE);
	return(FALSE);
}

/* The mouse has been used to resize the physical window. Now we need to
   let emacs know about the newsize, and have him force a re-draw
*/

PASCAL NEAR resizm(f, n)

int f, n;	/* these are ignored... we get the new size info from
		   the mouse driver */
{
	newwidth(TRUE, xpos);
	newsize(TRUE, ypos);
	return(TRUE);
}

#else
mousehello()
{
}
#endif
