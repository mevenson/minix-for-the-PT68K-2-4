/*	EBIND:		Initial default key to function bindings for
			MicroEMACS 3.7
*/

#define PT68K 1

/*
 * Command table.
 * This table  is *roughly* in ASCII order, left to right across the
 * characters of the command. This explains the funny location of the
 * control-X commands.
 */
noshare KEYTAB  keytab[NBINDS] = {
	{CTRL|'A',	gotobol},			/* in basic.c  */
	{CTRL|'B',	backchar},			/* in basic.c  */
	{CTRL|'C',	insspace},			/* in line.c   */
	{CTRL|'D',	forwdel},			/* in random.c */
	{CTRL|'E',	gotoeol},			/* in basic.c  */
	{CTRL|'F',	forwchar},			/* in basic.c  */
	{CTRL|'G',	ctrlg},				/* in main.c   */
	{CTRL|'H',	backdel},			/* in random.c */
	{CTRL|'I',	tab},				/* in random.c */
	{CTRL|'J',	indent},			/* in random.c */
	{CTRL|'K',	killtext},			/* in random.c */
	{CTRL|'L',	refresh},			/* in window.c */
	{CTRL|'M',	newline},			/* in random.c */
	{CTRL|'N',	forwline},			/* in basic.c  */
	{CTRL|'O',	openline},			/* in random.c */
	{CTRL|'P',	backline},			/* in basic.c  */
	{CTRL|'Q',	quote},				/* in random.c */
	{CTRL|'R',	backsearch},		/* in search.c */
	{CTRL|'S',	forwsearch},		/* in search.c */
	{CTRL|'T',	twiddle},			/* in random.c */
	{CTRL|'U',	unarg},				/* in main.c   */
	{CTRL|'V',	forwpage},			/* in basic.c  */
	{CTRL|'W',	killregion},		/* in region.c */
	{CTRL|'X',	cex},				/* in main.c   */
	{CTRL|'Y',	yank},				/* in line.c   */
	{CTRL|'Z',	backpage},			/* in basic.c  */
	{CTRL|'[',	meta},				/* in main.c   */

	{CTLX|CTRL|'B',	listbuffers},	/* in buffer.c 			*/
	{CTLX|CTRL|'C',	quit},          /* in main.c Hard quit. */
#if	AEDIT
	{CTLX|CTRL|'D',	detab},			/* in random.c */
	{CTLX|CTRL|'E',	entab},			/* in random.c */
#endif
	{CTLX|CTRL|'F',	filefind},		/* in file.c   */
	{CTLX|CTRL|'I',	insfile},		/* in file.c   */
	{CTLX|CTRL|'L',	lowerregion},	/* in region.c */
	{CTLX|CTRL|'M',	delmode},		/* in random.c */
	{CTLX|CTRL|'N',	mvdnwind},		/* in window.c */
	{CTLX|CTRL|'O',	deblank},		/* in random.c */
	{CTLX|CTRL|'P',	mvupwind},		/* in window.c */
	{CTLX|CTRL|'R',	fileread},		/* in file.c   */
	{CTLX|CTRL|'S',	filesave},		/* in file.c   */
#if	AEDIT
	{CTLX|CTRL|'T',	trim},			/* in random.c */
#endif
	{CTLX|CTRL|'U',	upperregion},	/* in region.c */
	{CTLX|CTRL|'V',	viewfile},		/* in file.c   */
	{CTLX|CTRL|'W',	filewrite},		/* in file.c   */
	{CTLX|CTRL|'X',	swapmark},		/* in basic.c  */
	{CTLX|CTRL|'Z',	shrinkwind},	/* in window.c */
	{CTLX|'?',	deskey},			/* in bind.c   */
	{CTLX|'!',	spawn},				/* in msdos.c  */
	{CTLX|'@',	pipecmd},			/* in msdos.c  */
	{CTLX|'#',	filter},			/* in msdos.c  */
	{CTLX|'$',	execprg},			/* in msdos.c  */
	{CTLX|'=',	showcpos},			/* in random.c */
	{CTLX|'(',	ctlxlp},			/* in main.c   */
	{CTLX|')',	ctlxrp},			/* in main.c   */
	{CTLX|'<',	narrow},			/* in region.c */
	{CTLX|'>',	widen},				/* in region.c */
	{CTLX|'^',	enlargewind},		/* in window.c */
	{CTLX|' ',	remmark},			/* in basic.c  */
	{CTLX|'0',	delwind},			/* in window.c */
	{CTLX|'1',	onlywind},			/* in window.c */
	{CTLX|'2',	splitwind},			/* in window.c */
	{CTLX|'A',	setvar},			/* in eval.c   */
	{CTLX|'B',	usebuffer},			/* in buffer.c */
	{CTLX|'C',	spawncli},			/* in msdos.c  */
	{CTLX|'E',	ctlxe},				/* in main.c   */
	{CTLX|'F',	setfillcol},		/* in random.c */
#if	DEBUGM
	{CTLX|'G',	dispvar},			/* in eval.c   */
#endif
	{CTLX|'K',	killbuffer},		/* in buffer.c */
	{CTLX|'M',	setmod},			/* in random.c */
	{CTLX|'N',	filename},			/* in file.c   */
	{CTLX|'O',	nextwind},			/* in window.c */
	{CTLX|'P',	prevwind},			/* in window.c */
#if	ISRCH
	{CTLX|'R',	risearch},			/* in isearch.c */
	{CTLX|'S',	fisearch},			/* in isearch.c */
#endif
	{CTLX|'W',	resize},			/* in window.c */
	{CTLX|'X',	nextbuffer},		/* in buffer.c */
	{CTLX|'Z',	enlargewind},		/* in window.c */
#if	PROC
	{META|CTRL|'E',	execproc},		/* in exec.c   */
#endif
#if	CFENCE
	{META|CTRL|'F',	getfence},		/* in random.c */
#endif
	{META|CTRL|'H',	delbword},		/* in word.c   */
	{META|CTRL|'K',	unbindkey},		/* in bind.c   */
	{META|CTRL|'L',	reposition},	/* in window.c */
	{META|CTRL|'M',	delgmode},		/* in random.c */
	{META|CTRL|'N',	namebuffer},	/* in buffer.c */
	{META|CTRL|'R',	qreplace},		/* in search.c */
	{META|CTRL|'V',	scrnextdw},		/* in window.c */
	{META|CTRL|'Z',	scrnextup},		/* in window.c */
	{META|' ',	setmark},			/* in basic.c  */
	{META|'?',	help},				/* in bind.c   */
	{META|'!',	reposition},		/* in window.c */
	{META|'.',	setmark},			/* in basic.c  */
	{META|'>',	gotoeob},			/* in basic.c  */
	{META|'<',	gotobob},			/* in basic.c  */
	{META|'~',	unmark},			/* in buffer.c */
#if	APROP
	{META|'A',	apro},				/* in bind.c   */
#endif
	{META|'B',	backword},			/* in word.c   */
	{META|'b',	backword},			/* in word.c   */
	{META|'C',	capword},			/* in word.c   */
	{META|'D',	delfword},			/* in word.c   */
#if	CRYPT
	{META|'E',	setkey},			/* in crypt.c  */
#endif
	{META|'F',	forwword},			/* in word.c   */
	{META|'f',	forwword},			/* in word.c   */
	{META|'G',	gotoline},			/* in basic.c  */
	{META|'g',	gotoline},			/* in basic.c  */
	{META|'K',	bindtokey},			/* in bind.c   */
	{META|'k',	bindtokey},			/* in bind.c   */
	{META|'L',	lowerword},			/* in word.c   */
	{META|'l',	lowerword},			/* in word.c   */
	{META|'M',	setgmode},			/* in random.c */
	{META|'m',	setgmode},			/* in random.c */
	{META|'R',	sreplace},			/* in search.c */
	{META|'r',	sreplace},			/* in search.c */
	{META|'U',	upperword},			/* in word.c   */
	{META|'u',	upperword},			/* in word.c   */
	{META|'V',	backpage},			/* in basic.c  */
	{META|'v',	backpage},			/* in basic.c  */
	{META|'W',	copyregion},		/* in region.c */
	{META|'w',	copyregion},		/* in region.c */
	{META|'X',	namedcmd},			/* in exec.c   */
	{META|'x',	namedcmd},			/* in exec.c   */
	{META|'Z',	quickexit},			/* in main.c   */
	{META|'z',	quickexit},			/* in main.c   */
	{META|0x7F, delbword},			/* in word.c   */

        /* These are the cursor control keys    */
        /*  left, right, up and down arrow keys */
        /*  page up, page down, home and end    */

	{SPEC|'A',	backline},	/* up arrow     	   	in basic.c  */
	{SPEC|'a',	markdragu},	/* shift - up arrow    	in basic.c  */
	{SPEC|'B',	forwline},	/* down arrow   	   	in basic.c  */
	{SPEC|'b',	markdragd},	/* shift - down arrow  	in basic.c  */
	{SPEC|'C',	forwchar},  /* right arrow  	   	in basic.c  */
	{SPEC|'c',	markdragf}, /* shift - right arrow 	in basic.c  */
	{SPEC|'D',	backchar},	/* left arrow   		in basic.c  */
	{SPEC|'d',	markdragb},	/* shift - left arrow   in basic.c  */
	{SPEC|'E',	backpage},	/* page up      		in basic.c  */
	{SPEC|'F',	forwpage},	/* page down    		in basic.c  */
	{SPEC|'G',	gotoeol},	/* End key      		in basic.c  */
	{SPEC|'H',	gotobol},	/* Home key     		in basic.c  */
	{SPEC|'K',  gotobob},	/* ctrl Home    		in basic.c  */
	{SPEC|'L',  gotoeob},   /* ctrl End     		in basic.c  */
	{SPEC|'O',	yank},		/* shift Insert 		in line.c   */
	{SPEC|'P',	copyregion},/* ctrl Insert  		in region.c */
	
	{SPEC|CTRL|'C', forwword}, /* ctrl right arrow 	in word.c   */
	{SPEC|CTRL|'D', backword}, /* ctrl left arrow  	in word.c   */
	
	{0x7F,		forwdel},	/* in random.c */
	{0,			NULL}
};

