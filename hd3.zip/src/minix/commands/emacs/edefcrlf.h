/*	EDEF:		Global variable definitions for
			MicroEMACS 3.9

			written by Dave G. Conroy
			modified by Steve Wilhite, George Jones
			greatly modified by Daniel Lawrence
*/

#ifdef	maindef

/* for MAIN.C */

/* initialized global definitions */

noshare int DNEAR fillcol = 72;		/* Current fill column		*/
noshare short	kbdm[NKBDM];		/* Macro			*/
noshare char	*execstr = NULL;	/* pointer to string to execute */
noshare char	golabel[NPAT] = "";	/* current line to go to	*/
noshare int DNEAR execlevel = 0;	/* execution IF level		*/
noshare int DNEAR eolexist = TRUE;	/* does clear to EOL exist	*/
noshare int DNEAR revexist = FALSE;	/* does reverse video exist?	*/
noshare int DNEAR flickcode = TRUE;	/* do flicker supression?	*/
noshare char	*modename[] = { 	/* name of modes		*/
	"WRAP", "CMODE", "SPELL", "EXACT", "VIEW", "OVER",
	"MAGIC", "CRYPT", "ASAVE"};
noshare char	modecode[] = "WCSEVOMYA";/* letters to represent modes	*/
noshare int DNEAR numfunc = NFUNCS;	/* number of bindable functions */
noshare int DNEAR gmode = 0;		/* global editor mode		*/
noshare int DNEAR gflags = GFREAD;	/* global control flag		*/
noshare int DNEAR gfcolor = 7;		/* global forgrnd color (white) */
noshare int DNEAR gbcolor = 0;		/* global backgrnd color (black)*/
noshare int DNEAR gasave = 256;		/* global ASAVE size		*/
noshare int DNEAR gacount = 256;	/* count until next ASAVE	*/
noshare int DNEAR sgarbf	= TRUE; /* TRUE if screen is garbage	*/
noshare int DNEAR mpresf	= FALSE;/* TRUE if message in last line */
noshare int DNEAR clexec	= FALSE;/* command line execution flag	*/
noshare int DNEAR mstore	= FALSE;/* storing text to macro flag	*/
noshare int DNEAR discmd	= TRUE; /* display command flag 	*/
noshare int DNEAR disinp	= TRUE; /* display input characters	*/
noshare int DNEAR modeflag = TRUE;	/* display modelines flag	*/
noshare int DNEAR sscroll = FALSE;	/* smooth scrolling enabled flag*/
noshare	int DNEAR hscroll = TRUE;	/* horizontal scrolling flag	*/
noshare int DNEAR hjump = 1;		/* horizontal jump size		*/
noshare int DNEAR ssave = TRUE;		/* safe save flag		*/
noshare struct	BUFFER *bstore = NULL;	/* buffer to store macro text to*/
noshare int DNEAR vtrow	= 0;		/* Row location of SW cursor */
noshare int DNEAR vtcol	= 0;		/* Column location of SW cursor */
noshare int DNEAR ttrow	= HUGE; 	/* Row location of HW cursor */
noshare int DNEAR ttcol	= HUGE; 	/* Column location of HW cursor */
noshare int DNEAR lbound = 0;		/* leftmost column of current line
					   being displayed */
noshare int DNEAR taboff = 0;		/* tab offset for display	*/
noshare int DNEAR tabsize = 8;		/* current hard tab size	*/
noshare int DNEAR reptc = CTRL | 'U';	/* current universal repeat char */
noshare int DNEAR abortc = CTRL | 'G';	/* current abort command char	*/
noshare int DNEAR sterm = CTRL | '[';	/* search terminating character */
noshare int DNEAR tttermc = -1;		/* Flag used by getstring to
					   communicate the desired terminator
					   to the terminal driver. */

noshare int DNEAR prefix = 0;		/* currently pending prefix bits */
noshare int DNEAR prenum = 0;		/*     "       "     numeric arg */
noshare int DNEAR predef = TRUE;	/*     "       "     default flag */

noshare int DNEAR quotec = 0x11;	/* quote char during mlreply() */
noshare char	*cname[] = {		/* names of colors		*/
	"BLACK", "RED", "GREEN", "YELLOW", "BLUE",
	"MAGENTA", "CYAN", "WHITE"};
noshare KILL *kbufp  = NULL;		/* current kill buffer chunk pointer*/
noshare KILL *kbufh  = NULL;		/* kill buffer header pointer	*/
noshare int kused = KBLOCK;		/* # of bytes used in kill buffer*/
noshare WINDOW *swindow = NULL; 	/* saved window pointer 	*/
noshare int cryptflag = FALSE;		/* currently encrypting?	*/
noshare short	*kbdptr;		/* current position in keyboard buf */
noshare short	*kbdend = &kbdm[0];	/* ptr to end of the keyboard */
noshare int DNEAR kbdmode = STOP; 	/* current keyboard macro mode	*/
noshare int DNEAR kbdrep = 0;		/* number of repetitions	*/
noshare int DNEAR restflag = FALSE;	/* restricted use?		*/
noshare int DNEAR lastkey = 0;		/* last keystoke		*/
noshare int DNEAR seed = 0;		/* random number seed		*/
noshare long	envram = 0l;		/* # of bytes current in use by malloc */
noshare int DNEAR macbug = FALSE; 	/* macro debuging flag		*/
noshare char	errorm[] = "ERROR";	/* error literal		*/
noshare char	truem[] = "TRUE";	/* true literal 		*/
noshare char	falsem[] = "FALSE";	/* false litereal		*/
noshare int DNEAR cmdstatus = TRUE;	/* last command status		*/
noshare char	palstr[49] = "";	/* palette string		*/
noshare char	lastmesg[NSTRING] = ""; /* last message posted		*/
noshare char	*lastptr = NULL;	/* ptr to lastmesg[]		*/
noshare int DNEAR saveflag = 0;		/* Flags, saved with the $target var */
noshare char	*fline = NULL;		/* dynamic return line */
noshare int DNEAR flen = 0;		/* current length of fline */
noshare int DNEAR rval = 0;		/* return value of a subprocess */
noshare int DNEAR eexitflag = FALSE;	/* EMACS exit flag */
noshare int DNEAR eexitval = 0;		/* and the exit return value */
noshare int xpos = 0;		/* current column mouse is positioned to */
noshare int ypos = 0;		/* current screen row	     "		 */
noshare int nclicks = 0;	/* cleared on any non-mouse event */

/* uninitialized global definitions */

noshare int DNEAR currow; 	/* Cursor row			*/
noshare int DNEAR curcol; 	/* Cursor column		*/
noshare int DNEAR thisflag;	/* Flags, this command		*/
noshare int DNEAR lastflag;	/* Flags, last command		*/
noshare int DNEAR curgoal;	/* Goal for C-P, C-N		*/
noshare WINDOW	*curwp; 	/* Current window		*/
noshare BUFFER	*curbp; 	/* Current buffer		*/
noshare WINDOW	*wheadp;	/* Head of list of windows	*/
noshare BUFFER	*bheadp;	/* Head of list of buffers	*/
noshare BUFFER	*blistp;	/* Buffer for C-X C-B		*/

noshare char	sres[NBUFN];	/* current screen resolution	*/

noshare char	pat[NPAT];	/* Search pattern		*/
noshare char	tap[NPAT];	/* Reversed pattern array.	*/
noshare char	rpat[NPAT];	/* replacement pattern		*/

/*	Various "Hook" execution variables	*/

noshare int (PASCAL NEAR *readhook)(); /* executed on all file reads */
noshare int (PASCAL NEAR *wraphook)(); /* executed when wrapping text */
noshare int (PASCAL NEAR *cmdhook)();  /* executed before looking for a command */

/* The variable matchlen holds the length of the matched
 * string - used by the replace functions.
 * The variable patmatch holds the string that satisfies
 * the search command.
 * The variables matchline and matchoff hold the line and
 * offset position of the *start* of match.
 */
noshare unsigned int DNEAR matchlen = 0;
noshare unsigned int DNEAR mlenold  = 0;
noshare char		*patmatch = NULL;
noshare LINE		*matchline = NULL;
noshare int DNEAR 	matchoff = 0;

#if	MAGIC
/*
 * The variables magical and rmagical determine if there
 * were actual metacharacters in the search and replace strings -
 * if not, then we don't have to use the slower MAGIC mode
 * search functions.
 */
noshare short int DNEAR magical = FALSE;
noshare short int DNEAR rmagical = FALSE;
noshare MC mcpat[NPAT];		/* the magic pattern		*/
noshare MC tapcm[NPAT];		/* the reversed magic pattern	*/
noshare RMC rmcpat[NPAT];	/* the replacement magic array	*/

#endif

/* directive name table:
	This holds the names of all the directives....	*/

noshare char *dname[] = {
	"if", "else", "endif",
	"goto", "return", "endm",
	"while", "endwhile", "break",
	"force"
};

#if	DEBUGM
/*	vars needed for macro debugging output	*/
noshare char outline[NSTRING];	/* global string to hold debug line text */
#endif

#else

/* for all the other .C files */

/* initialized global external declarations */

noshare extern	int DNEAR fillcol;	/* Fill column			*/
noshare extern	short	kbdm[]; 	/* Holds kayboard macro data	*/
noshare extern	char	*execstr;	/* pointer to string to execute */
noshare extern	char	golabel[];	/* current line to go to	*/
noshare extern	int DNEAR execlevel;	/* execution IF level		*/
noshare extern	int DNEAR eolexist;	/* does clear to EOL exist?	*/
noshare extern	int DNEAR revexist;	/* does reverse video exist?	*/
noshare extern	int DNEAR flickcode;	/* do flicker supression?	*/
noshare extern	char *modename[];	/* text names of modes		*/
noshare extern	char	modecode[];	/* letters to represent modes	*/
noshare extern	int DNEAR numfunc;	/* number of bindable functions */
noshare extern	KEYTAB keytab[];	/* key bind to functions table	*/
noshare extern	NBIND names[];		/* name to function table	*/
noshare extern	int DNEAR gmode;	/* global editor mode		*/
noshare extern	int DNEAR gflags; 	/* global control flag		*/
noshare extern	int DNEAR gfcolor;	/* global forgrnd color (white) */
noshare extern	int DNEAR gbcolor;	/* global backgrnd color (black)*/
noshare extern	int DNEAR gasave; 	/* global ASAVE size		*/
noshare extern	int DNEAR gacount;	/* count until next ASAVE	*/
noshare extern	int DNEAR sgarbf; 	/* State of screen unknown	*/
noshare extern	int DNEAR mpresf; 	/* Stuff in message line	*/
noshare extern	int DNEAR clexec; 	/* command line execution flag	*/
noshare extern	int DNEAR mstore; 	/* storing text to macro flag	*/
noshare extern	int DNEAR discmd; 	/* display command flag 	*/
noshare extern	int DNEAR disinp; 	/* display input characters	*/
noshare extern	int DNEAR modeflag;	/* display modelines flag	*/
noshare extern	int DNEAR sscroll;	/* smooth scrolling enabled flag*/
noshare	extern	int DNEAR hscroll;	/* horizontal scrolling flag	*/
noshare extern	int DNEAR hjump;	/* horizontal jump size		*/
noshare extern	int DNEAR ssave;	/* safe save flag		*/
noshare extern	struct	BUFFER *bstore; /* buffer to store macro text to*/
noshare extern	int DNEAR vtrow;	/* Row location of SW cursor */
noshare extern	int DNEAR vtcol;	/* Column location of SW cursor */
noshare extern	int DNEAR ttrow;	/* Row location of HW cursor */
noshare extern	int DNEAR ttcol;	/* Column location of HW cursor */
noshare extern	int DNEAR lbound; 	/* leftmost column of current line
					   being displayed */
noshare extern	int DNEAR taboff; 	/* tab offset for display	*/
noshare extern	int DNEAR tabsize;	/* current hard tab size	*/
noshare extern	int DNEAR reptc;	/* current universal repeat char */
noshare extern	int DNEAR abortc; 	/* current abort command char	*/
noshare extern	int DNEAR sterm;	/* search terminating character */
noshare extern	int DNEAR tttermc;	/* getstring terminator for terminal
					   driver use */

noshare extern	int DNEAR prefix; 	/* currently pending prefix bits */
noshare extern	int DNEAR prenum; 	/*     "       "     numeric arg */
noshare extern	int DNEAR predef; 	/*     "       "     default flag */

noshare extern	int DNEAR quotec; 	/* quote char during mlreply() */
noshare extern	char	*cname[];	/* names of colors		*/
noshare extern KILL *kbufp;		/* current kill buffer chunk pointer */
noshare extern KILL *kbufh;		/* kill buffer header pointer	*/
noshare extern int kused;		/* # of bytes used in KB	*/
noshare extern WINDOW *swindow; 	/* saved window pointer 	*/
noshare extern int cryptflag;		/* currently encrypting?	*/
noshare extern	short	*kbdptr;	/* current position in keyboard buf */
noshare extern	short	*kbdend;	/* ptr to end of the keyboard */
noshare extern	int kbdmode;		/* current keyboard macro mode	*/
noshare extern	int kbdrep;		/* number of repetitions	*/
noshare extern	int restflag;		/* restricted use?		*/
noshare extern	int lastkey;		/* last keystoke		*/
noshare extern	int seed;		/* random number seed		*/
noshare extern	long envram;		/* # of bytes current in use by malloc */
noshare extern	int DNEAR macbug; 	/* macro debuging flag		*/
noshare extern	char	errorm[];	/* error literal		*/
noshare extern	char	truem[];	/* true literal 		*/
noshare extern	char	falsem[];	/* false litereal		*/
noshare extern	int DNEAR cmdstatus;	/* last command status		*/
noshare extern	char	palstr[];	/* palette string		*/
noshare extern	char	lastmesg[];	/* last message posted		*/
noshare extern	char	*lastptr;	/* ptr to lastmesg[]		*/
noshare extern	int DNEAR saveflag;	/* Flags, saved with the $target var */
noshare extern	char	*fline; 	/* dynamic return line */
noshare extern	int DNEAR flen;		/* current length of fline */
noshare extern	int DNEAR rval;		/* return value of a subprocess */
noshare extern	int DNEAR eexitflag;	/* EMACS exit flag */
noshare extern	int DNEAR eexitval;	/* and the exit return value */
noshare extern int xpos;	/* current column mouse is positioned to */
noshare extern int ypos;	/* current screen row	     "		 */
noshare extern int nclicks;	/* cleared on any non-mouse event */

/* uninitialized global external declarations */

noshare extern	int DNEAR currow; 	/* Cursor row			*/
noshare extern	int DNEAR curcol; 	/* Cursor column		*/
noshare extern	int DNEAR thisflag;	/* Flags, this command		*/
noshare extern	int DNEAR lastflag;	/* Flags, last command		*/
noshare extern	int DNEAR curgoal;	/* Goal for C-P, C-N		*/
noshare extern	WINDOW	*curwp; 	/* Current window		*/
noshare extern	BUFFER	*curbp; 	/* Current buffer		*/
noshare extern	WINDOW	*wheadp;	/* Head of list of windows	*/
noshare extern	BUFFER	*bheadp;	/* Head of list of buffers	*/
noshare extern	BUFFER	*blistp;	/* Buffer for C-X C-B		*/

noshare extern	char	sres[NBUFN];	/* current screen resolution	*/

noshare extern	char	pat[];		/* Search pattern		*/
noshare extern	char	tap[];		/* Reversed pattern array.	*/
noshare extern	char	rpat[]; 	/* replacement pattern		*/

/*	Various "Hook" execution variables	*/

noshare extern int (PASCAL NEAR *readhook)();	/* executed on all file reads */
noshare extern int (PASCAL NEAR *wraphook)();	/* executed when wrapping text */
noshare extern int (PASCAL NEAR *cmdhook)();	/* executed before looking for a cmd */

noshare extern unsigned int matchlen;
noshare extern unsigned int mlenold;
noshare extern char *patmatch;
noshare extern LINE *matchline;
noshare extern int matchoff;

#if	MAGIC
noshare extern short int magical;
noshare extern short int rmagical;
noshare extern MC mcpat[NPAT];		/* the magic pattern		*/
noshare extern MC tapcm[NPAT];		/* the reversed magic pattern	*/
noshare extern RMC rmcpat[NPAT];	/* the replacement magic array	*/
#endif

noshare extern char *dname[];		/* directive name table 	*/

#if	DEBUGM
/*	vars needed for macro debugging output	*/
noshare extern char outline[];	/* global string to hold debug line text */
#endif

#endif

/* terminal table defined only in TERM.C */

#ifndef termdef
noshare extern	TERM	term;		/* Terminal information.	*/
#endif
