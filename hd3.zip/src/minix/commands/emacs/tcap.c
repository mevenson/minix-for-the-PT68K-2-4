/*	tcap:	Unix V5, V7, MINIX and BS4.2 Termcap video driver
		for MicroEMACS
*/

#define	termdef	1			/* don't define "term" external */

#include <stdio.h>
#include "estruct.h"
#include "etype.h"
#include "edef.h"

#if TERMCAP

#define	MARGIN	8
#define	SCRSIZ	64
#define	NPAUSE	10			/* # times thru update to pause */
#define BEL     0x07
#define ESC     0x1B

extern int  ttopen();
extern int  ttgetc();
extern int  ttputc();
extern int	tgetnum();
extern int  ttflush();
extern int  ttclose();
extern int	tcapkopen();
extern int	tcapkclose();
extern int  tcapmove();
extern int  tcapeeol();
extern int  tcapeeop();
extern int  tcapbeep();
extern int	tcaprev();
extern int	tcapbold();
extern int	tcapcres();
extern int  tcapopen();
extern int	tcapclose();
extern int  tput();
extern char *tgoto();
#if	COLOR
extern	int	tcapfcol();
extern	int	tcapbcol();
#endif

#define TCAPSLEN 315
char tcapbuf[TCAPSLEN];
char *UP, PC, *CM, *CE, *CL, *SO, *SE, *MD, *ME, *IS, *KS, *KE;

TERM term = {
	NULL,	/* these four values are set dynamically at open time */
	NULL,
	NULL,
	NULL,
	MARGIN,
	SCRSIZ,
	NPAUSE,
    tcapopen,
    tcapclose,
    tcapkopen,
    tcapkclose,
    ttgetc,
    ttputc,
    ttflush,
    tcapmove,
    tcapeeol,
    tcapeeop,
    tcapbeep,
    tcaprev,
    tcapbold,
    tcapcres
#if	COLOR
	, tcapfcol,
	tcapbcol
#endif
};

tcapopen()
{
        char *getenv();
        char *t, *p, *tgetstr();
        char tcbuf[1024];
        char *tv_stype;
        char err_str[72];

        if ((tv_stype = getenv("TERM")) == NULL)
        {
                puts("Environment variable TERM not defined!");
                meexit(1);
        }

        if ((tgetent(tcbuf, tv_stype)) != 1)
        {
                sprintf(err_str, "Unknown terminal type %s!", tv_stype);
                puts(err_str);
                meexit(1);
        }

 
       if ((term.t_nrow=(short)tgetnum("li")-1) == -1){
               puts("termcap entry incomplete (lines)");
               meexit(1);
       }
	   term.t_mrow =  term.t_nrow;

       if ((term.t_ncol=(short)tgetnum("co")) == -1){
               puts("Termcap entry incomplete (columns)");
               meexit(1);
       }
	   term.t_mcol = term.t_ncol;

       p = tcapbuf;
       t = tgetstr("pc", &p);
       if(t)
           PC = *t;

       CL = tgetstr("cl", &p);
       CM = tgetstr("cm", &p);
       CE = tgetstr("ce", &p);
       UP = tgetstr("up", &p);
	   SE = tgetstr("se", &p);
	   SO = tgetstr("so", &p);
	   MD = tgetstr("md", &p);
	   ME = tgetstr("me", &p);
	   if (SO != NULL)
	       revexist = TRUE;

       if(CL == NULL || CM == NULL || UP == NULL)
       {
           puts("Incomplete termcap entry\n");
           meexit(1);
       }

	if (CE == NULL)		/* will we be able to use clear to EOL? */
		eolexist = FALSE;
		
 	IS = tgetstr("is", &p); /* extract init string */
 	KS = tgetstr("ks", &p); /* extract keypad transmit string */
 	KE = tgetstr("ke", &p); /* extract keypad transmit end string */
 		
        if (p >= &tcapbuf[TCAPSLEN])
        {
                puts("Terminal description too big!\n");
                meexit(1);
        }
        ttopen();

	/* send init strings if defined */
 	if(IS != NULL)
 		putpad(IS);
 
 	if(KS != NULL)
 		putpad(KS);
}
 
tcapclose()
{
 	/* send end-of-keypad-transmit string if defined */
 	if(KE != NULL)
 		putpad(KE);
 	
 	ttclose();
}

tcapkopen()
{
	strcpy(sres, "NORMAL");
}

tcapkclose()
{
}

tcapmove(row, col)
register int row, col;
{
        putpad(tgoto(CM, col, row));
}

tcapeeol()
{
        putpad(CE);
}

tcapeeop()
{
        putpad(CL);
}

tcaprev(state)	/* change reverse video status */
int state;		/* FALSE = normal video, TRUE = reverse video */
{
	static int revstate = FALSE;
	if (state)
	{
		if (SO != NULL)
			putpad(SO);
	}
	else if (SE != NULL)
		putpad(SE);
}

tcapbold(state)	/* change bold video status */
int state;		/* FALSE = normal video, TRUE = bold video */
{
	static int boldstate = FALSE;
	if (state)
	{
		if (MD != NULL)
			putpad(MD);
	}
	else if (ME != NULL)
		putpad(ME);
}

tcapcres()	/* change screen resolution */
{
	return(TRUE);
}

spal(dummy)	/* change palette string */
{
	/*	Does nothing here	*/
}

#if	COLOR
tcapfcol()	/* no colors here, ignore this */
{
}

tcapbcol()	/* no colors here, ignore this */
{
}
#endif

tcapbeep()
{
	ttputc(BEL);
}

putpad(str)
char    *str;
{
	tputs(str, 1, ttputc);
}

putnpad(str, n)
char    *str;
{
	tputs(str, n, ttputc);
}


#if	FLABEL
fnclabel(f, n)		/* label a function key */

int f,n;	/* default flag, numeric argument [unused] */

{
	/* on machines with no function keys...don't bother */
	return(TRUE);
}
#endif
#else

hello()
{
}

#endif
