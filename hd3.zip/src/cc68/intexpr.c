#include	"c.h"
#include	"expr.h"
#include	"gen.h"
#include	"cglbdec.h"

/*
 * 68000 C compiler
 * ================
 *
 * Copyright 1984, 1985, 1986 Matthew Brandt.
 * Copyright 1989, 1990       Christoph van Wullen.
 * all commercial rights reserved.
 *
 * This compiler is intended as an instructive tool for personal use. Any use
 * for profit without the written consent of the author is prohibited.
 *
 * This compiler may be distributed freely for non-commercial use as long as
 * this notice stays intact. Please forward any enhancements or questions to:
 *
 * Matthew Brandt
 * Box 920337
 * Norcross, Ga 30092
 *
 * This compiler has been enhanced and corrected at the end of 1989
 * by Christoph van Wullen, who generated this version.
 * Look at the file README.CVW for further comments.
 * A further major update took place in summer 1990.
 */

double
floatexpr()
/* simple floating point number */
{
    double          temp;
    int             sign = 0;
    if (lastst == minus) {
	sign = 1;
	getsym();
    }
    if (lastst != rconst && lastst != iconst)
	error(ERR_FPCON);
    if (lastst == iconst)
	temp = (double) ival;
    else
	temp = rval;
    getsym();
    if (sign)
	temp = -temp;
    return temp;
}

long
intexpr()
{
    struct enode   *ep;
    struct typ     *tp;

    tp = exprnc(&ep);
    if (tp == 0) {
	error(ERR_INTEXPR);
	return 0;
    }
    opt0(&ep);

    if (ep->nodetype != en_icon) {
	error(ERR_SYNTAX);
	return 0;
    }
    return ep->v.i;
}
