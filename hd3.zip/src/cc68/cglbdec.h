/*
 * 68000 C compiler
 *
 * Copyright 1984, 1985, 1986 Matthew Brandt. all commercial rights reserved.
 *
 * This compiler is intended as an instructive tool for personal use. Any use
 * for profit without the written consent of the author is prohibited.
 *
 * This compiler may be distributed freely for non-commercial use as long as
 * this notice stays intact. Please forward any enhancements or questions to:
 *
 * Matthew Brandt Box 920337 Norcross, Ga 30092
 *
 * This compiler has been enhanced and corrected at the end of 1989 by Christoph
 * van Wullen, who generated this version. Look at the file README.CVW for
 * further comments.
 */


extern FILE    *input, *list, *output;
#ifdef ICODE
extern FILE    *icode;
#endif
extern unsigned int nextlabel;
extern int      lastch;
extern enum e_sym lastst;
extern char     lastid[30];
extern char     laststr[MAX_STRLEN + 1];
extern int      lstrlen;
extern unsigned long ival;
extern double   rval;

extern TABLE    gsyms, lsyms, labsyms, gtags, ltags;

extern struct slit *strtab;
extern long     lc_auto;
extern long     max_scratch;
extern long     lc_bss;		/* local bss counter */
extern int      global_flag;
extern unsigned save_mask;	/* register save mask */

extern int      list_option;
extern int      short_option;
extern int      noreg_option;
extern int      trans_option;
extern int      nopeep_option;
#ifdef ICODE
extern int      icode_option;
#endif
extern TYP     *ret_type;

extern int      regptr;
extern long     reglst[REG_LIST];
extern int      autoptr;
extern long     autolst[AUTO_LIST];

extern struct enode *init_node;

#ifdef VERBOSE
extern struct tms tms_buf;
long            decl_time, parse_time, opt_time, gen_time, flush_time;
#endif				/* VERBOSE */

extern TYP      tp_void, tp_long, tp_ulong, tp_char, tp_uchar;
extern TYP      tp_short, tp_ushort, tp_float;
extern TYP      tp_econst, tp_string, tp_int, tp_uint, tp_func;

extern int      int_bits;

extern struct amode push, pop;

extern TYP     *head, *tail;

extern int      total_errors;
