float 
asfpadd(p, x)
    float          *p;
    float           x;
{
    return (*p = *p + x);
}
