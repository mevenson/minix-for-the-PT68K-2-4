#include	"c.h"
#include	"expr.h"
#include	"gen.h"

/*
 * 68000 C compiler
 * ================
 *
 * Copyright 1984, 1985, 1986 Matthew Brandt.
 * Copyright 1989, 1990       Christoph van Wullen.
 * all commercial rights reserved.
 *
 * This compiler is intended as an instructive tool for personal use. Any use
 * for profit without the written consent of the author is prohibited.
 *
 * This compiler may be distributed freely for non-commercial use as long as
 * this notice stays intact. Please forward any enhancements or questions to:
 *
 * Matthew Brandt
 * Box 920337
 * Norcross, Ga 30092
 *
 * This compiler has been enhanced and corrected at the end of 1989
 * by Christoph van Wullen, who generated this version.
 * Look at the file README.CVW for further comments.
 * A further major update took place in summer 1990.
 */

/* global definitions	 */

FILE           *input, *list, *output;
#ifdef ICODE
FILE           *icode;
#endif
unsigned int    nextlabel;
int             lastch;
enum e_sym      lastst;
char            lastid[MAX_ID_LEN];
char            laststr[MAX_STRLEN + 1];
int             lstrlen;
unsigned long   ival;
double          rval;

TABLE           gsyms, gtags, lsyms, labsyms, ltags;

struct slit    *strtab;
long            lc_auto;
long            max_scratch;
long            lc_bss;
int             global_flag;
unsigned int    save_mask;


/* These are the default options */

int             list_option = 0;
int             short_option = 1;
int             noreg_option = 0;
int             trans_option = 0;
int             nopeep_option = 0;
#ifdef ICODE
int             icode_option = 0;
#endif

TYP            *ret_type;
int             regptr;
long            reglst[REG_LIST];
int             autoptr;
long            autolst[AUTO_LIST];
struct enode   *init_node;
#ifdef VERBOSE
struct tms      tms_buf;
long            decl_time = 0, parse_time = 0, opt_time = 0, gen_time = 0, flush_time = 0;
#endif

TYP             tp_void = {{0, 0}, 0, 0, -1, bt_void, 0, 1};
TYP             tp_long = {{0, 0}, 0, 0, 4, bt_long, 0, 1};
TYP             tp_ulong = {{0, 0}, 0, 0, 4, bt_ulong, 0, 1};
TYP             tp_char = {{0, 0}, 0, 0, 1, bt_char, 0, 1};
TYP             tp_uchar = {{0, 0}, 0, 0, 1, bt_uchar, 0, 1};
TYP             tp_short = {{0, 0}, 0, 0, 2, bt_short, 0, 1};
TYP             tp_ushort = {{0, 0}, 0, 0, 2, bt_ushort, 0, 1};
TYP             tp_float = {{0, 0}, 0, 0, 4, bt_float, 0, 1};
TYP             tp_econst = {{0, 0}, 0, 0, 2, bt_enum, 1, 1};
TYP             tp_string = {{0, 0}, &tp_char, 0, 4, bt_pointer, 0, 1};
TYP             tp_int;
TYP             tp_uint;
TYP             tp_func = {{0, 0}, &tp_int, 0, 4, bt_func, 1, 1};

int             int_bits;

struct amode    push = {am_adec, 0, STACKPTR - 8, 0, 0, 0},
                pop = {am_ainc, 0, STACKPTR - 8, 0, 0, 0};

TYP            *head = 0, *tail = 0;

int             total_errors;
