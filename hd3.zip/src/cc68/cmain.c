#include	"c.h"
#include	"expr.h"
#include	"gen.h"
#include	"cglbdec.h"
#include	<signal.h>

/*
 * 68000 C compiler
 * ================
 *
 * Copyright 1984, 1985, 1986 Matthew Brandt.
 * Copyright 1989, 1990       Christoph van Wullen.
 * all commercial rights reserved.
 *
 * This compiler is intended as an instructive tool for personal use. Any use
 * for profit without the written consent of the author is prohibited.
 *
 * This compiler may be distributed freely for non-commercial use as long as
 * this notice stays intact. Please forward any enhancements or questions to:
 *
 * Matthew Brandt
 * Box 920337
 * Norcross, Ga 30092
 *
 * This compiler has been enhanced and corrected at the end of 1989
 * by Christoph van Wullen, who generated this version.
 * Look at the file README.CVW for further comments.
 * A further major update took place in summer 1990.
 */

static          openfiles();
static          closefiles();
static          summary();

static
exception(sig)
    int             sig;
{
    fprintf(stderr, "\n\nSIGNAL %d -- TERMINATING.\n", sig);
    fatal("EXCEPTION");
}

#ifndef _NSIG
#define _NSIG	NSIG
#endif

main(argc, argv)
    int             argc;
    char          **argv;
{
    int             i;

    for (i = 1; i < _NSIG; ++i)
	signal(i, exception);

    argc--;
    argv++;
    while ((argc > 0) && **argv == '-') {
	options(*argv++);
	argc--;
    }
    /*
     * set some global options
     */
    if (short_option) {
	tp_int = tp_short;
	tp_uint = tp_ushort;
	int_bits = 16;
    } else {
	tp_int = tp_long;
	tp_uint = tp_ulong;
	int_bits = 32;
    }


    openfiles(argc, argv);
    /* return means that all files have been opened */
    out_init();
    initsym();
    getch();
    getsym();
    compile();
    if (list_option)
	summary();
    else
	/* This emits all the global and external directives */
	list_table(&gsyms, 0);
#ifdef VERBOSE
    fprintf(stderr, "\n -- %d errors found.\n", total_errors);
#endif
    rel_global();
    closefiles();
#ifdef VERBOSE
    decl_time -= parse_time;
    parse_time -= gen_time + flush_time;
    gen_time -= opt_time;
    fprintf(stderr, "Times: %6ld + %6ld + %6ld + %6ld + %6ld\n",
	    decl_time, parse_time, opt_time, gen_time, flush_time);
#endif
    if (total_errors > 0)
	exit(1);
    else
	exit(0);
}

int
options(s)
    char           *s;
{
    ++s;
    if (!strcmp(s, "list")) {
	list_option = 1;
	return;
    }
    if (!strcmp(s, "noshort")) {
	short_option = 0;
	return;
    }
    if (!strcmp(s, "short")) {
	short_option = 1;
	return;
    }
    if (!strcmp(s, "noreg")) {
	noreg_option = 1;
	return;
    }
    if (!strcmp(s, "trans")) {
	trans_option = 1;
	return;
    }
    if (!strcmp(s, "nopeep")) {
	nopeep_option = 1;
	return;
    }
#ifdef ICODE
    if (!strcmp(s, "icode")) {
	icode_option = 1;
	return;
    }
#endif
    fprintf(stderr, "Unknown option %s ignored.\n", --s);
}

static int
openfiles(argc, argv)
    int             argc;
    char          **argv;
{
    if (argc < 2) {
	fprintf(stderr, "input and output filename required\n");
	exit(2);
    }
    if ((input = fopen(*argv++, "r")) == NULL) {
	fprintf(stderr, "cant open input file\n");
	exit(2);
    }
    if ((output = fopen(*argv++, "w")) == NULL) {
	fprintf(stderr, "cant open output file\n");
	exit(2);
    }
    if (list_option && (list = fopen("c68.list", "w")) == 0) {
	fprintf(stderr, " cant open listfile\n");
	exit(1);
    }
#ifdef ICODE
    if (icode_option && ((icode = fopen("c68.icode", "w")) == 0)) {
	fprintf(stderr, " cant open icode file\n");
	exit(1);
    }
#endif
}

static
summary()
{
    if (gsyms.head != NULL) {
	fprintf(list, "\f\n *** global scope symbol table ***\n\n");
	list_table(&gsyms, 0);
    }
    if (gtags.head != NULL) {
	fprintf(list, "\n *** structures and unions ***\n\n");
	list_table(&gtags, 0);
    }
}

static int
closefiles()
{
    if (list_option)
	fclose(list);
#ifdef ICODE
    if (icode_option)
	fclose(icode);
#endif
}

fatal(message)
    char           *message;
{
#ifdef VERBOSE
    static int      beenhere = 0;
#endif

    fprintf(stderr, "FATAL error encountered.\n");
    fprintf(stderr, "Message: %s\n", message);
    fprintf(stderr, "this may occur due to a syntax error,\n");
    fprintf(stderr, "a feature left out of the compiler,\n");
    fprintf(stderr, "or just a compiler error.\n");
#ifdef VERBOSE
    if (!beenhere) {
	beenhere = 1;
	flush_peep();
    }
#endif
    exit(16);
}
