#include <lib.h>
#include <stdlib.h>
int abs(i)
int i;
{
  return (i < 0 ? -i : i);
}
