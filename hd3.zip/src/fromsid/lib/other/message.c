#include <lib.h>

/* Some compilers require an initializer to force storage allocation */
message M = {0};
