/* _execve.c						POSIX 3.1.2 (underware)
 *	int __EXECVE(char *path, char *argv[], char *envp[]);
 *
 *	Executes a file.
 */

#include <lib.h>
#include <errno.h>
#include <limits.h>
#include <sys/types.h>
#include <unistd.h>
#include <minix/callnr.h>

#define	PTRSIZE	sizeof(char *)

_PRIVATE int count_pointers(p)
register char **p;
{
  register int n = 0;

  while (*p++ != (char *) NULL)
	++n;
  return n;
}

_PUBLIC int __EXECVE(path, argv, envp)
char *path;			/* pointer to name of file to be executed */
char *argv[];			/* pointer to argument array */
char *envp[];			/* pointer to environment */
{
  char stack[ARG_MAX];
  char **ap;
  register char *hp, *p;
  int nargs, nenvps, stackbytes;

  /* Count the argument pointers and environment pointers. */
  nargs = count_pointers(argv);
  nenvps = count_pointers(envp);

  /* Prepare to set up the initial stack. */
  hp = &stack[(nargs + nenvps + 3) * PTRSIZE];
  if (hp + nargs + nenvps >= &stack[ARG_MAX]) {
	errno = E2BIG;
	return -1;
  }
  ap = (char **) stack;
  *ap++ = (char *) nargs;

  /* Prepare the argument pointers and strings. */
  while (*argv != (char *) NULL) {
	*ap++ = (char *) (hp - stack);
	p = *argv++;
	while (*p) {
		*hp++ = *p++;
		if (hp >= &stack[ARG_MAX]) {
			errno = E2BIG;
			return -1;
		}
	}
	*hp++ = '\0';
  }
  *ap++ = (char *) NULL;

  /* Prepare the environment pointers and strings. */
  while (*envp != (char *) NULL) {
	*ap++ = (char *) (hp - stack);
	p = *envp++;
	while (*p) {
		*hp++ = *p++;
		if (hp >= &stack[ARG_MAX]) {
			errno = E2BIG;
			return -1;
		}
	}
	*hp++ = '\0';
  }
  *ap++ = (char *) NULL;
  stackbytes = (((int) (hp - stack) + PTRSIZE - 1) / PTRSIZE) * PTRSIZE;
  return __CALL1(_MM, EXEC, strlen(path) + 1, stackbytes, 0, path, stack, NULL);
}
