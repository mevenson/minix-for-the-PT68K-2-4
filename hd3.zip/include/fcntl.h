/* For fcntl(3)  */

#define     F_DUPFD	0
#define     F_GETFD	1		/*  reserved for future use  */
#define     F_SETFD	2		/*  reserved for future use  */
#define     F_GETFL	3		/*  reserved for future use  */
#define     F_SETFL	4		/*  reserved for future use  */

/* For open(2)  */

#define     O_RDONLY	0
#define     O_WRONLY	1
#define     O_RDWR	2
