char *memcpy();
char *memccpy();
char *memchr();
char *memset();
int   memcmp();
