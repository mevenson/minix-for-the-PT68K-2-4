/* sync - flush the file system buffers.  Author: Andy Tanenbaum */

main()
{
/* First prize in shortest useful program contest. */
  sync();
}
