#define STACKSIZE        8

char stack[STACKSIZE];
char *stackpt = &stack[STACKSIZE];

main()
{
	/* dummy */
}
