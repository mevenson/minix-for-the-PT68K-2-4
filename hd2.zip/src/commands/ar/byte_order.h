/*
 * (c) copyright 1988 by the Vrije Universiteit, Amsterdam, The Netherlands.
 * See the copyright notice in the file "../Copyright".
 */
#define BYTES_REVERSED 1
#define WORDS_REVERSED 1
#define CHAR_UNSIGNED 0
