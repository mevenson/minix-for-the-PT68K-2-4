/* For utime(2)  */

struct utimbuf {
	time_t	actime;
	time_t	modtime;
};
